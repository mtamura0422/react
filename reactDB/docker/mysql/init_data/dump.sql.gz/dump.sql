-- MySQL dump 10.13  Distrib 5.6.27, for osx10.11 (x86_64)
--
-- Host: localhost    Database: to_development
-- ------------------------------------------------------
-- Server version	5.6.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `kpi_abandon_paths`
--

DROP TABLE IF EXISTS `kpi_abandon_paths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_abandon_paths` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '離脱パスKPIID',
  `report_date` date NOT NULL COMMENT '記録日',
  `controller` varchar(64) NOT NULL COMMENT 'コントローラ名',
  `action` varchar(64) NOT NULL COMMENT 'アクション名',
  `extra_info` varchar(64) DEFAULT NULL COMMENT '追加情報',
  `player_num` int(11) NOT NULL COMMENT 'プレイヤー数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_abandon_paths_1` (`report_date`,`player_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='離脱パスKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_avatars`
--

DROP TABLE IF EXISTS `kpi_avatars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_avatars` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'アバターKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `avatar_id` int(11) NOT NULL COMMENT 'アバターID',
  `distribution` int(11) NOT NULL COMMENT '流通数',
  `active_num` int(11) NOT NULL COMMENT '使用中',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_avatars_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='アバターKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_boards`
--

DROP TABLE IF EXISTS `kpi_boards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_boards` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '伝言板KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `in_counter` int(11) NOT NULL COMMENT '自分の伝言板にアクセスした数',
  `visit_counter` int(11) NOT NULL COMMENT '誰かの掲示板を訪問した数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_boards_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='伝言板KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_cats`
--

DROP TABLE IF EXISTS `kpi_cats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_cats` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ねこKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `cat_id` int(11) NOT NULL,
  `visit_num` int(11) NOT NULL COMMENT '来訪数',
  `get_num` int(11) NOT NULL COMMENT '捕獲数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_cats_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ねこKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_collections`
--

DROP TABLE IF EXISTS `kpi_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '図鑑KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `reward_id` int(11) NOT NULL COMMENT '報酬ID',
  `loop_num` int(11) NOT NULL COMMENT 'ループ回数',
  `player_num` int(11) NOT NULL COMMENT 'プレイヤー数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_collections_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='図鑑KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_container_qualities`
--

DROP TABLE IF EXISTS `kpi_container_qualities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_container_qualities` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '什器クオリティKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `rarity_id` int(11) NOT NULL COMMENT 'レアリティ',
  `quality` int(11) NOT NULL COMMENT '什器クオリティ',
  `num` int(11) NOT NULL COMMENT '個数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_container_qualities_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='什器クオリティKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_container_quality_rewards`
--

DROP TABLE IF EXISTS `kpi_container_quality_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_container_quality_rewards` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '什器合成達成報酬KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `rarity_id` int(11) NOT NULL COMMENT 'レアリティ',
  `quality` int(11) NOT NULL COMMENT '什器クオリティ',
  `reward_num` int(11) NOT NULL COMMENT '報酬受け取り数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_container_quality_rewards_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='什器合成達成報酬KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_container_synth_costs`
--

DROP TABLE IF EXISTS `kpi_container_synth_costs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_container_synth_costs` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '什器合成コストKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `cost` bigint(20) NOT NULL COMMENT 'コスト',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_container_synth_costs_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='什器合成コストKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_container_synths`
--

DROP TABLE IF EXISTS `kpi_container_synths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_container_synths` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '什器合成KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `rarity_id` int(11) NOT NULL COMMENT 'レアリティ',
  `synth_num` int(11) NOT NULL COMMENT '合成回数',
  `synth_uu` int(11) NOT NULL COMMENT '合成UU',
  `material_num` int(11) NOT NULL COMMENT '素材UU',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_container_synths_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='什器合成KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_containers`
--

DROP TABLE IF EXISTS `kpi_containers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_containers` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '什器KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `container_id` bigint(20) NOT NULL COMMENT '什器ID',
  `distribution` int(11) NOT NULL COMMENT '流通数',
  `distribution_uu` int(11) NOT NULL DEFAULT '0' COMMENT '所持UU',
  `buy_num` int(11) NOT NULL COMMENT '購入数',
  `display_num` int(11) NOT NULL DEFAULT '0' COMMENT '設置数',
  `display_uu` int(11) NOT NULL DEFAULT '0' COMMENT '設置UU',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_containers_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='什器KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_deal_waits`
--

DROP TABLE IF EXISTS `kpi_deal_waits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_deal_waits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '仕入れ待ちKPIID',
  `report_date` date NOT NULL COMMENT '記録日',
  `report_hour` int(11) NOT NULL COMMENT '記録時間',
  `is_complete` tinyint(4) NOT NULL COMMENT '完了フラグ',
  `crud_kind` binary(1) DEFAULT NULL COMMENT 'CRUD種別',
  `class_id` varchar(40) DEFAULT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `dealer_id` int(11) NOT NULL COMMENT '問屋ID',
  `dealer_kind` int(11) NOT NULL COMMENT '問屋種別',
  `target_id` bigint(20) NOT NULL COMMENT '対象ID(問屋商品ID/問屋什器ID)',
  `set_num` int(11) NOT NULL COMMENT '設定数',
  `subject_id` bigint(20) NOT NULL COMMENT '対象物ID(商品ID/什器ID)',
  `num` int(11) NOT NULL COMMENT '個数',
  `buy_price` int(11) NOT NULL COMMENT '価格',
  `buy_store_point` int(11) NOT NULL COMMENT '必要ストアポイント',
  `buy_guest_point` int(11) NOT NULL COMMENT '必要ゲストポイント',
  `wait_time` int(11) NOT NULL COMMENT '仕入れ待ち時間',
  `count_value` int(11) NOT NULL COMMENT '回数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_deal_waits_1` (`report_date`,`report_hour`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='仕入れ待ちKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_dealers`
--

DROP TABLE IF EXISTS `kpi_dealers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_dealers` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '問屋KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `dealer_id` int(11) NOT NULL COMMENT '問屋ID',
  `buy_uu` int(11) NOT NULL COMMENT '利用人数UU',
  `buy_num` int(11) NOT NULL COMMENT '利用回数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_dealers_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='問屋KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_diaries`
--

DROP TABLE IF EXISTS `kpi_diaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_diaries` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '日記KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `write_uu` int(11) NOT NULL COMMENT '日記を書いたUU数',
  `like_recv_num` int(11) NOT NULL COMMENT 'いいねされた回数',
  `like_send_uu` int(11) NOT NULL COMMENT '日記を書いたUU数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kpi_diaries_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='日記KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_diary_content_like_rankings`
--

DROP TABLE IF EXISTS `kpi_diary_content_like_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_diary_content_like_rankings` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '日記内容いいねランキングKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `ranking` int(11) NOT NULL COMMENT '順位',
  `content_id` int(10) unsigned DEFAULT NULL COMMENT '日記内容ID',
  `content_spid` bigint(20) NOT NULL COMMENT '日記内容SPID',
  `like_recv_num` int(11) NOT NULL COMMENT 'いいねされた回数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kpi_diary_content_like_rankings_1` (`report_date`,`ranking`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='日記内容いいねランキングKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_edits`
--

DROP TABLE IF EXISTS `kpi_edits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_edits` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '編集KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `anything_uu` bigint(20) NOT NULL COMMENT '設置アバター編集UU',
  `product_uu` bigint(20) NOT NULL COMMENT '商品アバター編集UU',
  `container_uu` int(11) NOT NULL COMMENT '什器アバター編集UU',
  `accessory_uu` int(11) NOT NULL COMMENT '装飾アバター編集UU',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_edits_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='編集KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_event_useds`
--

DROP TABLE IF EXISTS `kpi_event_useds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_event_useds` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'イベントポイント使用KPIID',
  `report_date` date NOT NULL COMMENT '記録日',
  `report_hour` int(11) NOT NULL COMMENT '記録時間',
  `point_effect_id` int(11) NOT NULL COMMENT 'ポイント効果ID',
  `count_value` int(11) NOT NULL COMMENT '使用回数',
  `uu` int(11) NOT NULL COMMENT '使用UU',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_event_useds_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベントポイント使用KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_events`
--

DROP TABLE IF EXISTS `kpi_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'NPCKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `all_join_num` int(11) NOT NULL COMMENT '期間中参加者',
  `daily_join_num` int(11) NOT NULL COMMENT '当日参加者',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_events_1` (`report_date`,`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='NPCKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_favorites`
--

DROP TABLE IF EXISTS `kpi_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '店ログKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `request_num` int(11) NOT NULL COMMENT '申請数',
  `total_num` int(11) NOT NULL DEFAULT '0' COMMENT '総数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_favorites_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='店ログKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_friends`
--

DROP TABLE IF EXISTS `kpi_friends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_friends` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '店ともKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `request_num` int(11) NOT NULL COMMENT '申請数',
  `total_num` int(11) NOT NULL DEFAULT '0' COMMENT '総数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_friends_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='店ともKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_guild_donates`
--

DROP TABLE IF EXISTS `kpi_guild_donates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_guild_donates` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '組合レベル分布KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `product_id` bigint(20) NOT NULL COMMENT '寄付商品ID',
  `req_num` int(11) NOT NULL DEFAULT '0' COMMENT '要求個数',
  `num` int(11) NOT NULL COMMENT '寄付商品総数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kpi_kpi_guild_donates_1` (`report_date`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合レベル分布KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_guild_individs`
--

DROP TABLE IF EXISTS `kpi_guild_individs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_guild_individs` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '組合個別KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `guild_id` int(11) NOT NULL COMMENT '組合ID',
  `board_write_cnt` int(11) NOT NULL COMMENT '発言回数',
  `donate_num` int(11) NOT NULL COMMENT '寄付回数',
  `request_num` int(11) NOT NULL COMMENT 'リクエスト回数',
  `budge_set_num` int(11) NOT NULL COMMENT 'バッジ設定回数',
  `escape_num` int(11) NOT NULL COMMENT '組合脱退回数',
  `kick_num` int(11) NOT NULL COMMENT '組合キック回数',
  `join_num` int(11) NOT NULL COMMENT '組合加入回数',
  `join_req_num` int(11) NOT NULL COMMENT '組合加入申請回数',
  `accept_num` int(11) NOT NULL COMMENT '組合承認回数',
  `refuse_num` int(11) NOT NULL COMMENT '組合否認回数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kpi_kpi_guild_individs_1` (`report_date`,`guild_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合個別KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_guild_lv_maps`
--

DROP TABLE IF EXISTS `kpi_guild_lv_maps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_guild_lv_maps` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '組合レベル分布KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `lv` int(11) NOT NULL COMMENT '組合LV最小数',
  `guild_num` int(11) NOT NULL COMMENT '組合数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kpi_kpi_guild_lv_maps_1` (`report_date`,`lv`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合レベル分布KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_guild_quests`
--

DROP TABLE IF EXISTS `kpi_guild_quests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_guild_quests` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '組合クエストKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `quest_list_id` int(11) NOT NULL COMMENT '組合クエストリストID',
  `open` int(11) NOT NULL COMMENT '組合クエスト中の数',
  `clear` int(11) NOT NULL COMMENT '組合クエストクリアの数',
  `received` int(11) NOT NULL COMMENT '組合クエスト報酬受理の数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kpi_kpi_guild_quests_1` (`report_date`,`quest_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合クエストKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_guilds`
--

DROP TABLE IF EXISTS `kpi_guilds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_guilds` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '組合KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `total_count` int(11) NOT NULL COMMENT '総組合数',
  `new_create` int(11) NOT NULL COMMENT '新規組合作成数',
  `top_score` bigint(20) NOT NULL COMMENT '最大スコア',
  `avg_score` bigint(20) NOT NULL COMMENT '平均スコア',
  `pos8_uu` int(11) NOT NULL COMMENT '会長UU',
  `pos4_uu` int(11) NOT NULL COMMENT '副会長UU',
  `pos2_uu` int(11) NOT NULL COMMENT 'リーダーUU',
  `pos1_uu` int(11) NOT NULL COMMENT 'メンバーUU',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kpi_kpi_guilds_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_item_useds`
--

DROP TABLE IF EXISTS `kpi_item_useds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_item_useds` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'アイテム使用KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `report_hour` int(11) NOT NULL COMMENT '記録時間',
  `item_id` int(11) NOT NULL COMMENT 'アイテムID',
  `count_value` int(11) NOT NULL COMMENT '使用回数',
  `uu` int(11) NOT NULL COMMENT '使用UU',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_item_useds_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='アイテム使用KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_items`
--

DROP TABLE IF EXISTS `kpi_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'アイテム流通数KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `item_id` int(11) NOT NULL COMMENT 'アイテムID',
  `distribution` int(11) NOT NULL COMMENT '流通数',
  `uu` int(11) NOT NULL COMMENT 'UU',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_items_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='アイテム流通数KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_likes`
--

DROP TABLE IF EXISTS `kpi_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'グッドKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `like_kind_id` int(11) NOT NULL COMMENT 'グッド種別ID',
  `execute_num` int(11) NOT NULL COMMENT '実行数',
  `send_uu` int(11) NOT NULL COMMENT '送信した人数(UU)',
  `recv_uu` int(11) NOT NULL COMMENT '受信した人数(UU)',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_likes_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='グッドKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_login_daily_firsts`
--

DROP TABLE IF EXISTS `kpi_login_daily_firsts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_login_daily_firsts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '初回デイリーログインID',
  `report_date` date NOT NULL COMMENT '記録日',
  `report_hour` int(11) NOT NULL COMMENT '記録時間',
  `login_daily_id` int(11) NOT NULL COMMENT 'デイリーログインID',
  `count_value` int(11) NOT NULL COMMENT '初回デイリーログイン合計件数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kpi_login_daily_firsts_1` (`report_date`,`report_hour`,`login_daily_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='初回デイリーログインKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_login_daily_login_nums`
--

DROP TABLE IF EXISTS `kpi_login_daily_login_nums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_login_daily_login_nums` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'デイリーログイン回数KPI',
  `report_datetime` datetime NOT NULL COMMENT '記録日時',
  `login_daily_id` int(11) NOT NULL COMMENT 'デイリーログインID',
  `login_num` int(11) NOT NULL COMMENT 'ログイン回数',
  `player_num` int(11) NOT NULL COMMENT 'プレイヤー数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_login_daily_login_nums_1` (`report_datetime`,`login_daily_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='デイリーログイン回数KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_logins`
--

DROP TABLE IF EXISTS `kpi_logins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_logins` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ログインKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `continue` int(11) NOT NULL COMMENT '継続日数',
  `uu` int(11) NOT NULL COMMENT '人数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_logins_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ログインKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_monthly_logins`
--

DROP TABLE IF EXISTS `kpi_monthly_logins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_monthly_logins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '月別ログイン数ID',
  `report_date` date NOT NULL COMMENT '記録日',
  `login_num` int(11) NOT NULL COMMENT 'ログイン数',
  `count_value` int(11) NOT NULL COMMENT '人数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kpi_monthly_logins_1` (`report_date`,`login_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='月別ログイン数';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_monthly_reports`
--

DROP TABLE IF EXISTS `kpi_monthly_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_monthly_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '月次レポート',
  `report_date` date NOT NULL COMMENT '記録日',
  `mau` int(11) NOT NULL COMMENT 'MAU',
  `payment_uu` int(11) NOT NULL COMMENT '課金UU',
  `total_price` int(11) NOT NULL COMMENT '売上',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kpi_monthly_reports_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='月次レポート';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_npc_lists`
--

DROP TABLE IF EXISTS `kpi_npc_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_npc_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'NPC訪問KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `npc_id` int(11) NOT NULL COMMENT 'NPCID',
  `visit_num` int(11) NOT NULL COMMENT '来店数',
  `buy_num` int(11) NOT NULL COMMENT '購入数',
  `visit_uu` int(11) NOT NULL COMMENT '来店されたUU',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_npc_lists_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='NPC訪問KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_npc_visitors`
--

DROP TABLE IF EXISTS `kpi_npc_visitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_npc_visitors` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'NPC訪問KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `npc_kind_id` int(11) NOT NULL COMMENT 'NPC種別',
  `visit_num` int(11) NOT NULL COMMENT '来店数',
  `buy_num` int(11) NOT NULL COMMENT '購入数',
  `other_visit_uu` int(11) NOT NULL COMMENT '来店先UU',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_npc_visitors_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='NPC訪問KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_npcs`
--

DROP TABLE IF EXISTS `kpi_npcs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_npcs` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'NPCKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `npc_kind_id` int(11) NOT NULL COMMENT 'NPC種別',
  `npc_num` int(11) NOT NULL COMMENT 'NPC数',
  `visitor_num` int(11) NOT NULL COMMENT '訪問プレイヤー数',
  `buy_num` int(11) NOT NULL COMMENT '購入プレイヤー数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_npcs_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='NPCKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_payment_event_points`
--

DROP TABLE IF EXISTS `kpi_payment_event_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_payment_event_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'イベントポイントでの課金KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `report_hour` int(11) NOT NULL COMMENT '記録時間',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `shop_id` int(11) NOT NULL COMMENT 'ショップID',
  `item_id` int(11) NOT NULL COMMENT 'アイテムID',
  `count_value` int(11) NOT NULL COMMENT '購入回数',
  `uu` int(11) NOT NULL COMMENT '課金UU',
  `price` int(11) NOT NULL COMMENT '販売額',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_payment_event_points_1` (`report_date`,`point_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベントポイントでの課金KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_payments`
--

DROP TABLE IF EXISTS `kpi_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'チュートリアル離脱率KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `report_hour` int(11) NOT NULL COMMENT '記録時間',
  `shop_id` int(11) NOT NULL COMMENT 'ショップID',
  `item_id` int(11) NOT NULL COMMENT 'アイテムID',
  `count_value` int(11) NOT NULL COMMENT '購入回数',
  `uu` int(11) NOT NULL COMMENT '課金UU',
  `price` int(11) NOT NULL COMMENT '販売額',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_payments_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='チュートリアル離脱率KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_persistencies`
--

DROP TABLE IF EXISTS `kpi_persistencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_persistencies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '継続率ID',
  `regist_date` date NOT NULL COMMENT '登録日時',
  `day_num` int(11) NOT NULL COMMENT '日数',
  `target_num` int(11) NOT NULL COMMENT '対象人数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kpi_persistencies_1` (`regist_date`,`day_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='継続率';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_player_visitors`
--

DROP TABLE IF EXISTS `kpi_player_visitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_player_visitors` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤー訪問KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `visit_num` int(11) NOT NULL COMMENT '来店数',
  `buy_num` int(11) NOT NULL COMMENT '購入数',
  `other_visit_uu` int(11) NOT NULL COMMENT '来店先UU',
  `self_visit_uu` int(11) NOT NULL COMMENT '他人のマイストア訪問UU',
  `self_buy_uu` int(11) NOT NULL COMMENT '他人のマイストア購入UU',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_player_visitors_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤー訪問KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_point_limits`
--

DROP TABLE IF EXISTS `kpi_point_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_point_limits` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ポイント上限人数',
  `report_date` date NOT NULL COMMENT '記録日',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `count_value` bigint(20) NOT NULL COMMENT '人数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_point_limits_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ポイント上限人数';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_points`
--

DROP TABLE IF EXISTS `kpi_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ポイントKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `point_kind_id` int(11) NOT NULL COMMENT 'グッド種別ID',
  `distribution` bigint(20) NOT NULL COMMENT '流通数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_points_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ポイントKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_products`
--

DROP TABLE IF EXISTS `kpi_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '商品KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `product_id` bigint(20) NOT NULL COMMENT '商品ID',
  `distribution` int(11) NOT NULL COMMENT '流通数',
  `buy_num` int(11) NOT NULL COMMENT '購入数',
  `sell_num` int(11) NOT NULL COMMENT '販売数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_products_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_push_quest_clear_nums`
--

DROP TABLE IF EXISTS `kpi_push_quest_clear_nums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_push_quest_clear_nums` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プッシュクエストクリア回数KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `push_quest_id` int(11) NOT NULL COMMENT 'プッシュクエストID',
  `clear_num` int(11) NOT NULL COMMENT 'クリア回数',
  `player_num` int(11) NOT NULL COMMENT '人数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_push_quest_clear_nums_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プッシュクエストクリア回数KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_push_quest_items`
--

DROP TABLE IF EXISTS `kpi_push_quest_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_push_quest_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プッシュクエストアイテムKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `push_quest_id` int(11) NOT NULL COMMENT 'プッシュクエストID',
  `push_quest_list_id` int(11) NOT NULL COMMENT 'プッシュクエストリストID',
  `item_id` int(11) NOT NULL COMMENT 'アイテムID',
  `use_num` int(11) NOT NULL COMMENT '使用回数',
  `use_uu` int(11) NOT NULL COMMENT '使用UU',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_push_quest_items_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プッシュクエストアイテムKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_push_quest_lists`
--

DROP TABLE IF EXISTS `kpi_push_quest_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_push_quest_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プッシュクエストステージKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `push_quest_id` int(11) NOT NULL COMMENT 'プッシュクエストID',
  `push_quest_list_id` int(11) NOT NULL COMMENT 'プッシュクエストリストID',
  `player_num` int(11) NOT NULL COMMENT '到達数',
  `play_num` int(11) NOT NULL COMMENT 'プレイ人数',
  `drop_comp_num` int(11) NOT NULL COMMENT 'ドロップコンプ数',
  `point_avg` int(11) NOT NULL COMMENT 'ポイント平均',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_push_quest_lists_1` (`report_date`,`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プッシュクエストステージKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_push_quest_lot_lists`
--

DROP TABLE IF EXISTS `kpi_push_quest_lot_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_push_quest_lot_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プッシュクエスト抽選KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `push_quest_id` int(11) NOT NULL COMMENT 'プッシュクエストID',
  `push_quest_list_id` int(11) NOT NULL COMMENT 'プッシュクエストリストID',
  `lot_id` int(11) NOT NULL COMMENT 'プッシュクエスト抽選ID',
  `num` bigint(20) NOT NULL COMMENT '回数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_push_quest_lot_lists_1` (`report_date`,`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プッシュクエスト抽選KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_push_quest_ranking_clear_nums`
--

DROP TABLE IF EXISTS `kpi_push_quest_ranking_clear_nums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_push_quest_ranking_clear_nums` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プッシュクエストランキング上位クリア回数KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `spid` bigint(20) NOT NULL COMMENT 'プッシュクエストID',
  `push_quest_id` int(11) NOT NULL COMMENT 'プッシュクエストID',
  `push_quest_list_id` int(11) NOT NULL COMMENT 'プッシュクエストリストID',
  `clear_num` int(11) NOT NULL COMMENT 'クリア回数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_push_quest_ranking_clear_nums_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プッシュクエストランキング上位クリア回数KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_push_quest_ranking_treasures`
--

DROP TABLE IF EXISTS `kpi_push_quest_ranking_treasures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_push_quest_ranking_treasures` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プッシュクエストランキング上位クリア回数KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `spid` bigint(20) NOT NULL COMMENT 'プッシュクエストID',
  `treasure_id` int(11) NOT NULL COMMENT '宝箱ID',
  `appear_num` int(11) NOT NULL COMMENT '出現回数',
  `open_num` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_push_quest_ranking_treasures_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プッシュクエストランキング上位クリア回数KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_push_quest_rankings`
--

DROP TABLE IF EXISTS `kpi_push_quest_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_push_quest_rankings` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プッシュクエストランキング上位課金KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `spid` bigint(20) NOT NULL COMMENT 'プッシュクエストID',
  `ranking` int(11) NOT NULL COMMENT 'ランキング',
  `payment` int(11) NOT NULL COMMENT '課金額',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_push_quest_rankings_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プッシュクエストランキング上位課金KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_push_quest_treasures`
--

DROP TABLE IF EXISTS `kpi_push_quest_treasures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_push_quest_treasures` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プッシュクエスト宝箱KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `push_quest_id` int(11) NOT NULL COMMENT 'プッシュクエストID',
  `push_quest_list_id` int(11) NOT NULL COMMENT 'プッシュクエストリストID',
  `treasure_id` int(11) NOT NULL COMMENT '宝箱ID',
  `appear_num` int(11) NOT NULL COMMENT '出現回数',
  `open_num` int(11) NOT NULL COMMENT '開錠回数',
  `open_uu` int(11) NOT NULL COMMENT '開錠UU',
  `key_open_num` int(11) NOT NULL COMMENT '鍵使用開錠回数',
  `key_open_uu` int(11) NOT NULL COMMENT '鍵使用開錠UU',
  `key_use_num` int(11) NOT NULL COMMENT '鍵使用回数',
  `key_use_uu` int(11) NOT NULL COMMENT '鍵使用UU',
  `key_buy_num` int(11) NOT NULL COMMENT '鍵購入回数',
  `key_buy_uu` int(11) NOT NULL COMMENT '鍵購入UU',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_push_quest_treasures_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プッシュクエスト宝箱KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_push_quests`
--

DROP TABLE IF EXISTS `kpi_push_quests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_push_quests` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プッシュクエストエリアKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `push_quest_id` int(11) NOT NULL COMMENT 'プッシュクエストID',
  `player_num` int(11) NOT NULL COMMENT '到達数',
  `play_num` int(11) NOT NULL COMMENT 'プレイ人数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_push_quests_1` (`report_date`,`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プッシュクエストエリアKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_quests`
--

DROP TABLE IF EXISTS `kpi_quests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_quests` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'クエストKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `quest_list_id` int(11) NOT NULL COMMENT 'クエストデータID',
  `open` int(11) NOT NULL COMMENT '解放数',
  `clear` int(11) NOT NULL COMMENT '達成数',
  `received` int(11) NOT NULL COMMENT '報酬受け取り数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_quests_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='クエストKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_raid_appears`
--

DROP TABLE IF EXISTS `kpi_raid_appears`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_raid_appears` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'レイド出現数KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `raid_level_id` bigint(20) NOT NULL COMMENT 'レイドレベルID',
  `num` int(11) NOT NULL COMMENT '出現数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_raid_appears_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='レイド出現数KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_raid_apply_routes`
--

DROP TABLE IF EXISTS `kpi_raid_apply_routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_raid_apply_routes` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'レイドルート選択KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `route_id` int(11) NOT NULL COMMENT 'ルートID',
  `num` int(11) NOT NULL COMMENT '回数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_raid_apply_routes_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='レイドルート選択KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_raid_point_lot_rankings`
--

DROP TABLE IF EXISTS `kpi_raid_point_lot_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_raid_point_lot_rankings` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'レイドガチャポイントランキングKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `ranking` int(11) NOT NULL COMMENT 'ランキング',
  `spid` bigint(20) DEFAULT NULL COMMENT 'SPID',
  `org_num` int(11) NOT NULL COMMENT '合計ポイント',
  `rest_num` int(11) NOT NULL COMMENT '残りポイント',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_raid_point_lot_rankings_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='レイドガチャポイントランキングKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_raid_point_sell_rankings`
--

DROP TABLE IF EXISTS `kpi_raid_point_sell_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_raid_point_sell_rankings` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'レイド販売ポイントランキングKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `ranking` int(11) NOT NULL COMMENT 'ランキング',
  `spid` bigint(20) DEFAULT NULL COMMENT 'SPID',
  `total_num` int(11) NOT NULL COMMENT '合計ポイント',
  `sell_num` int(11) NOT NULL COMMENT '純粋販売ポイント',
  `raid_num` int(11) NOT NULL COMMENT 'レイド獲得ポイント',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_raid_point_sell_rankings_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='レイド販売ポイントランキングKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_raid_relif_join_nums`
--

DROP TABLE IF EXISTS `kpi_raid_relif_join_nums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_raid_relif_join_nums` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'レイド救援参加回数分布KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `join_num` int(11) NOT NULL COMMENT '参加回数',
  `player_num` int(11) NOT NULL COMMENT '人数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_raid_relif_join_nums_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='レイド救援参加回数分布KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_raid_relif_join_uus`
--

DROP TABLE IF EXISTS `kpi_raid_relif_join_uus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_raid_relif_join_uus` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'レイド救援UUKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `player_num` int(11) NOT NULL COMMENT 'プレイヤーUU',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_raid_relif_join_uus_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='レイド救援UUKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_raid_relif_send_nums`
--

DROP TABLE IF EXISTS `kpi_raid_relif_send_nums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_raid_relif_send_nums` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'レイド救援要請回数分布KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `send_num` int(11) NOT NULL COMMENT '要請回数',
  `player_num` int(11) NOT NULL COMMENT '人数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_raid_relif_send_nums_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='レイド救援要請回数分布KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_raid_relif_send_uus`
--

DROP TABLE IF EXISTS `kpi_raid_relif_send_uus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_raid_relif_send_uus` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'レイド救援要請UUKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `player_num` int(11) NOT NULL COMMENT 'プレイヤーUU',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_raid_relif_send_uus_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='レイド救援要請UUKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_ranking_event_coins`
--

DROP TABLE IF EXISTS `kpi_ranking_event_coins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_ranking_event_coins` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'イベントコイン所持ランキングKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `ranking` int(11) NOT NULL COMMENT '順位',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `count_value` bigint(20) NOT NULL COMMENT '所持量',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_ranking_event_coins_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベントコイン所持ランキングKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_ranking_store_points`
--

DROP TABLE IF EXISTS `kpi_ranking_store_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_ranking_store_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ストアP所持ランキングKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `ranking` int(11) NOT NULL COMMENT '順位',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `count_value` bigint(20) NOT NULL COMMENT '所持量',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_ranking_store_points_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ストアP所持ランキングKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_reports`
--

DROP TABLE IF EXISTS `kpi_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '日次レポート',
  `report_date` date NOT NULL COMMENT '記録日',
  `arppu` int(11) NOT NULL COMMENT 'ARPPU',
  `arpu` int(11) NOT NULL COMMENT 'ARPU',
  `dau` int(11) NOT NULL COMMENT 'DAU',
  `dau_rate` float NOT NULL COMMENT 'DAU率',
  `dau_charge_rate` float NOT NULL COMMENT '消費DAU',
  `dau_charge_uu` int(11) NOT NULL COMMENT '消費DAU率',
  `install_num` int(11) NOT NULL COMMENT 'DAU率',
  `payment` int(11) NOT NULL COMMENT '売り上げ',
  `new_payment_num` int(11) NOT NULL COMMENT '新規課金ユーザー',
  `player_num` int(11) NOT NULL COMMENT 'プレイヤー数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_reports_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='日次レポート';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_store_genres`
--

DROP TABLE IF EXISTS `kpi_store_genres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_store_genres` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ストアジャンルKPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `store_genre_id` int(11) NOT NULL COMMENT 'ストアジャンルID',
  `num` int(11) NOT NULL COMMENT '店舗数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_store_genres_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ストアジャンルKPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_titles`
--

DROP TABLE IF EXISTS `kpi_titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_titles` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '称号KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `title_id` int(11) NOT NULL COMMENT '称号ID',
  `unlock_num` int(11) NOT NULL COMMENT 'アンロック人数',
  `active_num` int(11) NOT NULL COMMENT '使用中人数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_titles_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='称号KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_tpoints`
--

DROP TABLE IF EXISTS `kpi_tpoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_tpoints` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Tカード利用KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `hkigyoCd` varchar(32) NOT NULL COMMENT 'アライアンス企業コード',
  `hgyotaiCd` varchar(32) NOT NULL COMMENT '業態コード',
  `hcontent` varchar(32) NOT NULL COMMENT '内容',
  `num` int(11) NOT NULL COMMENT '利用回数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_tpoints_1` (`report_date`,`hkigyoCd`,`hgyotaiCd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tカード利用KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_tutorials`
--

DROP TABLE IF EXISTS `kpi_tutorials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_tutorials` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'チュートリアル離脱率KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `tutorial_id` int(11) NOT NULL COMMENT 'チュートリアルID',
  `uu` int(11) NOT NULL COMMENT '何人いるか',
  `player_num` int(11) NOT NULL DEFAULT '0' COMMENT 'ユーザー数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_tutorials_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='チュートリアル離脱率KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_visitors`
--

DROP TABLE IF EXISTS `kpi_visitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_visitors` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '来店KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `player_kind_id` int(11) NOT NULL COMMENT 'プレイヤー種別',
  `visit_num` int(11) NOT NULL COMMENT '来店数',
  `buy_num` int(11) NOT NULL COMMENT '購入数',
  `visit_uu` int(11) NOT NULL COMMENT '来店先UU',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_visitors_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='来店KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `kpi_visits`
--

DROP TABLE IF EXISTS `kpi_visits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kpi_visits` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '訪問KPI',
  `report_date` date NOT NULL COMMENT '記録日',
  `visit_uu` int(11) NOT NULL COMMENT '他人のマイストア訪問UU',
  `buy_uu` int(11) NOT NULL COMMENT '他人のマイストア購入UU',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_visits_1` (`report_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='訪問KPI';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_alliance_rewards`
--

DROP TABLE IF EXISTS `log_alliance_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_alliance_rewards` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'アライアンス報酬履歴ID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `alliance_id` int(11) NOT NULL COMMENT 'アライアンスID',
  `accumulation_kind` int(11) NOT NULL COMMENT '累積種別',
  `accumulation_num` int(11) NOT NULL COMMENT '累積回数',
  `use_at` date NOT NULL COMMENT '使用日',
  `tpoint_history_id` bigint(20) NOT NULL COMMENT 'Tポイント利用履歴ID',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_log_alliance_rewards_1` (`spid`,`alliance_id`,`use_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='アライアンス報酬履歴';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_avatar_inventories`
--

DROP TABLE IF EXISTS `log_avatar_inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_avatar_inventories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `avatar_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_log_avatar_inventories_1` (`spid`,`avatar_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_clerk_inventories`
--

DROP TABLE IF EXISTS `log_clerk_inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_clerk_inventories` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤー販売員取得履歴',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `clerk_id` int(11) NOT NULL COMMENT '販売員マスタID',
  `num` int(11) NOT NULL COMMENT '所持販売員数',
  `add_num` int(11) NOT NULL COMMENT '追加販売員数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`,`created_at`),
  KEY `idx_log_clerk_inventories_1` (`spid`,`clerk_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤー販売員取得履歴'
/*!50500 PARTITION BY RANGE  COLUMNS(created_at)
(PARTITION p201605 VALUES LESS THAN ('2016-06-01') ENGINE = InnoDB,
 PARTITION p201606 VALUES LESS THAN ('2016-07-01') ENGINE = InnoDB,
 PARTITION p201607 VALUES LESS THAN ('2016-08-01') ENGINE = InnoDB,
 PARTITION p201608 VALUES LESS THAN ('2016-09-01') ENGINE = InnoDB,
 PARTITION p201609 VALUES LESS THAN ('2016-10-01') ENGINE = InnoDB,
 PARTITION p201610 VALUES LESS THAN ('2016-11-01') ENGINE = InnoDB,
 PARTITION p201611 VALUES LESS THAN ('2016-12-01') ENGINE = InnoDB,
 PARTITION p201612 VALUES LESS THAN ('2017-01-01') ENGINE = InnoDB,
 PARTITION p201701 VALUES LESS THAN ('2017-02-01') ENGINE = InnoDB,
 PARTITION p201702 VALUES LESS THAN ('2017-03-01') ENGINE = InnoDB,
 PARTITION p201703 VALUES LESS THAN ('2017-04-01') ENGINE = InnoDB,
 PARTITION p201704 VALUES LESS THAN ('2017-05-01') ENGINE = InnoDB,
 PARTITION p201705 VALUES LESS THAN ('2017-06-01') ENGINE = InnoDB,
 PARTITION p201706 VALUES LESS THAN ('2017-07-01') ENGINE = InnoDB,
 PARTITION p201707 VALUES LESS THAN ('2017-08-01') ENGINE = InnoDB,
 PARTITION p201708 VALUES LESS THAN ('2017-09-01') ENGINE = InnoDB,
 PARTITION p201709 VALUES LESS THAN ('2017-10-01') ENGINE = InnoDB,
 PARTITION p201710 VALUES LESS THAN ('2017-11-01') ENGINE = InnoDB,
 PARTITION p201711 VALUES LESS THAN ('2017-12-01') ENGINE = InnoDB,
 PARTITION p201712 VALUES LESS THAN ('2018-01-01') ENGINE = InnoDB,
 PARTITION p201801 VALUES LESS THAN ('2018-02-01') ENGINE = InnoDB,
 PARTITION p201802 VALUES LESS THAN ('2018-03-01') ENGINE = InnoDB,
 PARTITION p201803 VALUES LESS THAN ('2018-04-01') ENGINE = InnoDB,
 PARTITION p201804 VALUES LESS THAN ('2018-05-01') ENGINE = InnoDB,
 PARTITION p201805 VALUES LESS THAN ('2018-06-01') ENGINE = InnoDB,
 PARTITION p201806 VALUES LESS THAN ('2018-07-01') ENGINE = InnoDB,
 PARTITION p201807 VALUES LESS THAN ('2018-08-01') ENGINE = InnoDB,
 PARTITION p201808 VALUES LESS THAN ('2018-09-01') ENGINE = InnoDB,
 PARTITION p201809 VALUES LESS THAN ('2018-10-01') ENGINE = InnoDB,
 PARTITION p201810 VALUES LESS THAN ('2018-11-01') ENGINE = InnoDB,
 PARTITION p201811 VALUES LESS THAN ('2018-12-01') ENGINE = InnoDB,
 PARTITION p201812 VALUES LESS THAN ('2019-01-01') ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_container_inventories`
--

DROP TABLE IF EXISTS `log_container_inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_container_inventories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `container_id` bigint(20) NOT NULL,
  `lv` int(11) NOT NULL DEFAULT '1' COMMENT 'レベル',
  `quality` int(11) NOT NULL DEFAULT '1' COMMENT 'クオリティ',
  `quality_exp` int(11) NOT NULL DEFAULT '0' COMMENT 'クオリティ経験値',
  `quality_max` int(11) NOT NULL DEFAULT '0' COMMENT 'クオリティ上限',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_log_container_inventories_1` (`spid`,`container_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_container_inventory_deletes`
--

DROP TABLE IF EXISTS `log_container_inventory_deletes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_container_inventory_deletes` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '什器削除履歴',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `container_inventory_id` bigint(20) NOT NULL COMMENT '什器在庫ID',
  `container_id` bigint(20) NOT NULL COMMENT '什器ID',
  `lv` int(11) NOT NULL COMMENT 'lv',
  `quality` int(11) NOT NULL COMMENT 'クオリティ',
  `quality_exp` int(11) NOT NULL COMMENT 'クオリティ経験値',
  `action` text COMMENT '動作',
  `quality_max` int(11) NOT NULL DEFAULT '0' COMMENT 'クオリティ上限',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_log_container_inventory_deletes_1` (`spid`,`container_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='什器削除履歴';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_container_synth_materials`
--

DROP TABLE IF EXISTS `log_container_synth_materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_container_synth_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '合成素材ログ',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `container_inventory_id` int(11) NOT NULL COMMENT '什器在庫ID',
  `container_id` bigint(20) NOT NULL COMMENT '什器ID',
  `rarity_id` int(11) NOT NULL COMMENT '什器レアリティID',
  `lv` int(11) NOT NULL COMMENT 'Lv',
  `quality` int(11) NOT NULL COMMENT 'クオリティ',
  `quality_exp` int(11) NOT NULL COMMENT 'クオリティ経験値',
  `quality_max` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_log_container_synth_materials_1` (`spid`,`created_at`),
  KEY `idx_log_container_synth_materials_2` (`rarity_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='合成素材ログ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_container_synths`
--

DROP TABLE IF EXISTS `log_container_synths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_container_synths` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '合成ログ',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `container_inventory_id` int(11) NOT NULL COMMENT '什器在庫ID',
  `container_id` int(11) NOT NULL COMMENT '什器ID',
  `rarity_id` int(11) NOT NULL COMMENT '什器レアリティID',
  `quality` int(11) NOT NULL COMMENT '合成前クオリティ',
  `quality_exp` int(11) NOT NULL COMMENT '合成前クオリティ経験値',
  `after_quality` int(11) NOT NULL COMMENT '合成後クオリティ',
  `after_quality_exp` int(11) NOT NULL,
  `add_exp` int(11) NOT NULL COMMENT '獲得経験値',
  `cost` int(11) NOT NULL COMMENT 'コスト',
  `is_success` smallint(6) NOT NULL COMMENT '大成功フラグ',
  `complete_at` datetime NOT NULL COMMENT '完了日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_log_container_synths_1` (`spid`,`container_inventory_id`),
  KEY `idx_log_container_synths_2` (`spid`,`created_at`),
  KEY `idx_log_container_synths_3` (`rarity_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='合成ログ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_deal_wait_lists`
--

DROP TABLE IF EXISTS `log_deal_wait_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_deal_wait_lists` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '仕入れ待ちリストログID',
  `log_transaction_id` varbinary(32) DEFAULT NULL COMMENT 'ログトランザクションID',
  `deal_wait_list_id` int(10) unsigned NOT NULL COMMENT '仕入れ待ちリストID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `deal_wait_id` int(10) unsigned NOT NULL COMMENT '仕入れ待ちID',
  `dealer_id` int(11) NOT NULL COMMENT '問屋ID',
  `dealer_kind` int(11) NOT NULL COMMENT '取扱対象種別',
  `target_id` bigint(20) NOT NULL COMMENT '対象ID(問屋商品ID/問屋什器ID)',
  `set_num` int(11) NOT NULL COMMENT '設定数',
  `org_created_at` datetime NOT NULL COMMENT '元データ作成日時',
  `org_updated_at` datetime NOT NULL COMMENT '元データ更新日時',
  `crud_kind` binary(1) DEFAULT NULL COMMENT 'CRUD種別',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`,`created_at`),
  KEY `idx_log_deal_wait_lists_1` (`log_transaction_id`),
  KEY `idx_log_deal_wait_lists_2` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='仕入れ待ちリストログ'
/*!50500 PARTITION BY RANGE  COLUMNS(created_at)
(PARTITION p201512 VALUES LESS THAN ('2016-01-01') ENGINE = InnoDB,
 PARTITION p201601 VALUES LESS THAN ('2016-02-01') ENGINE = InnoDB,
 PARTITION p201602 VALUES LESS THAN ('2016-03-01') ENGINE = InnoDB,
 PARTITION p201603 VALUES LESS THAN ('2016-04-01') ENGINE = InnoDB,
 PARTITION p201604 VALUES LESS THAN ('2016-05-01') ENGINE = InnoDB,
 PARTITION p201605 VALUES LESS THAN ('2016-06-01') ENGINE = InnoDB,
 PARTITION p201606 VALUES LESS THAN ('2016-07-01') ENGINE = InnoDB,
 PARTITION p201607 VALUES LESS THAN ('2016-08-01') ENGINE = InnoDB,
 PARTITION p201608 VALUES LESS THAN ('2016-09-01') ENGINE = InnoDB,
 PARTITION p201609 VALUES LESS THAN ('2016-10-01') ENGINE = InnoDB,
 PARTITION p201610 VALUES LESS THAN ('2016-11-01') ENGINE = InnoDB,
 PARTITION p201611 VALUES LESS THAN ('2016-12-01') ENGINE = InnoDB,
 PARTITION p201612 VALUES LESS THAN ('2017-01-01') ENGINE = InnoDB,
 PARTITION p201701 VALUES LESS THAN ('2017-02-01') ENGINE = InnoDB,
 PARTITION p201702 VALUES LESS THAN ('2017-03-01') ENGINE = InnoDB,
 PARTITION p201703 VALUES LESS THAN ('2017-04-01') ENGINE = InnoDB,
 PARTITION p201704 VALUES LESS THAN ('2017-05-01') ENGINE = InnoDB,
 PARTITION p201705 VALUES LESS THAN ('2017-06-01') ENGINE = InnoDB,
 PARTITION p201706 VALUES LESS THAN ('2017-07-01') ENGINE = InnoDB,
 PARTITION p201707 VALUES LESS THAN ('2017-08-01') ENGINE = InnoDB,
 PARTITION p201708 VALUES LESS THAN ('2017-09-01') ENGINE = InnoDB,
 PARTITION p201709 VALUES LESS THAN ('2017-10-01') ENGINE = InnoDB,
 PARTITION p201710 VALUES LESS THAN ('2017-11-01') ENGINE = InnoDB,
 PARTITION p201711 VALUES LESS THAN ('2017-12-01') ENGINE = InnoDB,
 PARTITION p201712 VALUES LESS THAN ('2018-01-01') ENGINE = InnoDB,
 PARTITION p201801 VALUES LESS THAN ('2018-02-01') ENGINE = InnoDB,
 PARTITION p201802 VALUES LESS THAN ('2018-03-01') ENGINE = InnoDB,
 PARTITION p201803 VALUES LESS THAN ('2018-04-01') ENGINE = InnoDB,
 PARTITION p201804 VALUES LESS THAN ('2018-05-01') ENGINE = InnoDB,
 PARTITION p201805 VALUES LESS THAN ('2018-06-01') ENGINE = InnoDB,
 PARTITION p201806 VALUES LESS THAN ('2018-07-01') ENGINE = InnoDB,
 PARTITION p201807 VALUES LESS THAN ('2018-08-01') ENGINE = InnoDB,
 PARTITION p201808 VALUES LESS THAN ('2018-09-01') ENGINE = InnoDB,
 PARTITION p201809 VALUES LESS THAN ('2018-10-01') ENGINE = InnoDB,
 PARTITION p201810 VALUES LESS THAN ('2018-11-01') ENGINE = InnoDB,
 PARTITION p201811 VALUES LESS THAN ('2018-12-01') ENGINE = InnoDB,
 PARTITION p201812 VALUES LESS THAN ('2019-01-01') ENGINE = InnoDB,
 PARTITION p201901 VALUES LESS THAN ('2019-02-01') ENGINE = InnoDB,
 PARTITION p201902 VALUES LESS THAN ('2019-03-01') ENGINE = InnoDB,
 PARTITION p201903 VALUES LESS THAN ('2019-04-01') ENGINE = InnoDB,
 PARTITION p201904 VALUES LESS THAN ('2019-05-01') ENGINE = InnoDB,
 PARTITION p201905 VALUES LESS THAN ('2019-06-01') ENGINE = InnoDB,
 PARTITION p201906 VALUES LESS THAN ('2019-07-01') ENGINE = InnoDB,
 PARTITION p201907 VALUES LESS THAN ('2019-08-01') ENGINE = InnoDB,
 PARTITION p201908 VALUES LESS THAN ('2019-09-01') ENGINE = InnoDB,
 PARTITION p201909 VALUES LESS THAN ('2019-10-01') ENGINE = InnoDB,
 PARTITION p201910 VALUES LESS THAN ('2019-11-01') ENGINE = InnoDB,
 PARTITION p201911 VALUES LESS THAN ('2019-12-01') ENGINE = InnoDB,
 PARTITION p201912 VALUES LESS THAN ('2020-01-01') ENGINE = InnoDB,
 PARTITION p202001 VALUES LESS THAN ('2020-02-01') ENGINE = InnoDB,
 PARTITION p202002 VALUES LESS THAN ('2020-03-01') ENGINE = InnoDB,
 PARTITION p202003 VALUES LESS THAN ('2020-04-01') ENGINE = InnoDB,
 PARTITION p202004 VALUES LESS THAN ('2020-05-01') ENGINE = InnoDB,
 PARTITION p202005 VALUES LESS THAN ('2020-06-01') ENGINE = InnoDB,
 PARTITION p202006 VALUES LESS THAN ('2020-07-01') ENGINE = InnoDB,
 PARTITION p202007 VALUES LESS THAN ('2020-08-01') ENGINE = InnoDB,
 PARTITION p202008 VALUES LESS THAN ('2020-09-01') ENGINE = InnoDB,
 PARTITION p202009 VALUES LESS THAN ('2020-10-01') ENGINE = InnoDB,
 PARTITION p202010 VALUES LESS THAN ('2020-11-01') ENGINE = InnoDB,
 PARTITION p202011 VALUES LESS THAN ('2020-12-01') ENGINE = InnoDB,
 PARTITION p202012 VALUES LESS THAN ('2021-01-01') ENGINE = InnoDB,
 PARTITION p202101 VALUES LESS THAN ('2021-02-01') ENGINE = InnoDB,
 PARTITION p202102 VALUES LESS THAN ('2021-03-01') ENGINE = InnoDB,
 PARTITION p202103 VALUES LESS THAN ('2021-04-01') ENGINE = InnoDB,
 PARTITION p202104 VALUES LESS THAN ('2021-05-01') ENGINE = InnoDB,
 PARTITION p202105 VALUES LESS THAN ('2021-06-01') ENGINE = InnoDB,
 PARTITION p202106 VALUES LESS THAN ('2021-07-01') ENGINE = InnoDB,
 PARTITION p202107 VALUES LESS THAN ('2021-08-01') ENGINE = InnoDB,
 PARTITION p202108 VALUES LESS THAN ('2021-09-01') ENGINE = InnoDB,
 PARTITION p202109 VALUES LESS THAN ('2021-10-01') ENGINE = InnoDB,
 PARTITION p202110 VALUES LESS THAN ('2021-11-01') ENGINE = InnoDB,
 PARTITION p202111 VALUES LESS THAN ('2021-12-01') ENGINE = InnoDB,
 PARTITION p202112 VALUES LESS THAN ('2022-01-01') ENGINE = InnoDB,
 PARTITION p202201 VALUES LESS THAN ('2022-02-01') ENGINE = InnoDB,
 PARTITION p202202 VALUES LESS THAN ('2022-03-01') ENGINE = InnoDB,
 PARTITION p202203 VALUES LESS THAN ('2022-04-01') ENGINE = InnoDB,
 PARTITION p202204 VALUES LESS THAN ('2022-05-01') ENGINE = InnoDB,
 PARTITION p202205 VALUES LESS THAN ('2022-06-01') ENGINE = InnoDB,
 PARTITION p202206 VALUES LESS THAN ('2022-07-01') ENGINE = InnoDB,
 PARTITION p202207 VALUES LESS THAN ('2022-08-01') ENGINE = InnoDB,
 PARTITION p202208 VALUES LESS THAN ('2022-09-01') ENGINE = InnoDB,
 PARTITION p202209 VALUES LESS THAN ('2022-10-01') ENGINE = InnoDB,
 PARTITION p202210 VALUES LESS THAN ('2022-11-01') ENGINE = InnoDB,
 PARTITION p202211 VALUES LESS THAN ('2022-12-01') ENGINE = InnoDB,
 PARTITION p202212 VALUES LESS THAN ('2023-01-01') ENGINE = InnoDB,
 PARTITION p202301 VALUES LESS THAN ('2023-02-01') ENGINE = InnoDB,
 PARTITION p202302 VALUES LESS THAN ('2023-03-01') ENGINE = InnoDB,
 PARTITION p202303 VALUES LESS THAN ('2023-04-01') ENGINE = InnoDB,
 PARTITION p202304 VALUES LESS THAN ('2023-05-01') ENGINE = InnoDB,
 PARTITION p202305 VALUES LESS THAN ('2023-06-01') ENGINE = InnoDB,
 PARTITION p202306 VALUES LESS THAN ('2023-07-01') ENGINE = InnoDB,
 PARTITION p202307 VALUES LESS THAN ('2023-08-01') ENGINE = InnoDB,
 PARTITION p202308 VALUES LESS THAN ('2023-09-01') ENGINE = InnoDB,
 PARTITION p202309 VALUES LESS THAN ('2023-10-01') ENGINE = InnoDB,
 PARTITION p202310 VALUES LESS THAN ('2023-11-01') ENGINE = InnoDB,
 PARTITION p202311 VALUES LESS THAN ('2023-12-01') ENGINE = InnoDB,
 PARTITION p202312 VALUES LESS THAN ('2024-01-01') ENGINE = InnoDB,
 PARTITION p202401 VALUES LESS THAN ('2024-02-01') ENGINE = InnoDB,
 PARTITION p202402 VALUES LESS THAN ('2024-03-01') ENGINE = InnoDB,
 PARTITION p202403 VALUES LESS THAN ('2024-04-01') ENGINE = InnoDB,
 PARTITION p202404 VALUES LESS THAN ('2024-05-01') ENGINE = InnoDB,
 PARTITION p202405 VALUES LESS THAN ('2024-06-01') ENGINE = InnoDB,
 PARTITION p202406 VALUES LESS THAN ('2024-07-01') ENGINE = InnoDB,
 PARTITION p202407 VALUES LESS THAN ('2024-08-01') ENGINE = InnoDB,
 PARTITION p202408 VALUES LESS THAN ('2024-09-01') ENGINE = InnoDB,
 PARTITION p202409 VALUES LESS THAN ('2024-10-01') ENGINE = InnoDB,
 PARTITION p202410 VALUES LESS THAN ('2024-11-01') ENGINE = InnoDB,
 PARTITION p202411 VALUES LESS THAN ('2024-12-01') ENGINE = InnoDB,
 PARTITION p202412 VALUES LESS THAN ('2025-01-01') ENGINE = InnoDB,
 PARTITION p202501 VALUES LESS THAN ('2025-02-01') ENGINE = InnoDB,
 PARTITION p202502 VALUES LESS THAN ('2025-03-01') ENGINE = InnoDB,
 PARTITION p202503 VALUES LESS THAN ('2025-04-01') ENGINE = InnoDB,
 PARTITION p202504 VALUES LESS THAN ('2025-05-01') ENGINE = InnoDB,
 PARTITION p202505 VALUES LESS THAN ('2025-06-01') ENGINE = InnoDB,
 PARTITION p202506 VALUES LESS THAN ('2025-07-01') ENGINE = InnoDB,
 PARTITION p202507 VALUES LESS THAN ('2025-08-01') ENGINE = InnoDB,
 PARTITION p202508 VALUES LESS THAN ('2025-09-01') ENGINE = InnoDB,
 PARTITION p202509 VALUES LESS THAN ('2025-10-01') ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN ('2025-11-01') ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN ('2025-12-01') ENGINE = InnoDB,
 PARTITION p202512 VALUES LESS THAN ('2026-01-01') ENGINE = InnoDB,
 PARTITION p202601 VALUES LESS THAN ('2026-02-01') ENGINE = InnoDB,
 PARTITION p202602 VALUES LESS THAN ('2026-03-01') ENGINE = InnoDB,
 PARTITION p202603 VALUES LESS THAN ('2026-04-01') ENGINE = InnoDB,
 PARTITION p202604 VALUES LESS THAN ('2026-05-01') ENGINE = InnoDB,
 PARTITION p202605 VALUES LESS THAN ('2026-06-01') ENGINE = InnoDB,
 PARTITION p202606 VALUES LESS THAN ('2026-07-01') ENGINE = InnoDB,
 PARTITION p202607 VALUES LESS THAN ('2026-08-01') ENGINE = InnoDB,
 PARTITION p202608 VALUES LESS THAN ('2026-09-01') ENGINE = InnoDB,
 PARTITION p202609 VALUES LESS THAN ('2026-10-01') ENGINE = InnoDB,
 PARTITION p202610 VALUES LESS THAN ('2026-11-01') ENGINE = InnoDB,
 PARTITION p202611 VALUES LESS THAN ('2026-12-01') ENGINE = InnoDB,
 PARTITION p202612 VALUES LESS THAN ('2027-01-01') ENGINE = InnoDB,
 PARTITION p202701 VALUES LESS THAN ('2027-02-01') ENGINE = InnoDB,
 PARTITION p202702 VALUES LESS THAN ('2027-03-01') ENGINE = InnoDB,
 PARTITION p202703 VALUES LESS THAN ('2027-04-01') ENGINE = InnoDB,
 PARTITION p202704 VALUES LESS THAN ('2027-05-01') ENGINE = InnoDB,
 PARTITION p202705 VALUES LESS THAN ('2027-06-01') ENGINE = InnoDB,
 PARTITION p202706 VALUES LESS THAN ('2027-07-01') ENGINE = InnoDB,
 PARTITION p202707 VALUES LESS THAN ('2027-08-01') ENGINE = InnoDB,
 PARTITION p202708 VALUES LESS THAN ('2027-09-01') ENGINE = InnoDB,
 PARTITION p202709 VALUES LESS THAN ('2027-10-01') ENGINE = InnoDB,
 PARTITION p202710 VALUES LESS THAN ('2027-11-01') ENGINE = InnoDB,
 PARTITION p202711 VALUES LESS THAN ('2027-12-01') ENGINE = InnoDB,
 PARTITION p202712 VALUES LESS THAN ('2028-01-01') ENGINE = InnoDB,
 PARTITION p202801 VALUES LESS THAN ('2028-02-01') ENGINE = InnoDB,
 PARTITION p202802 VALUES LESS THAN ('2028-03-01') ENGINE = InnoDB,
 PARTITION p202803 VALUES LESS THAN ('2028-04-01') ENGINE = InnoDB,
 PARTITION p202804 VALUES LESS THAN ('2028-05-01') ENGINE = InnoDB,
 PARTITION p202805 VALUES LESS THAN ('2028-06-01') ENGINE = InnoDB,
 PARTITION p202806 VALUES LESS THAN ('2028-07-01') ENGINE = InnoDB,
 PARTITION p202807 VALUES LESS THAN ('2028-08-01') ENGINE = InnoDB,
 PARTITION p202808 VALUES LESS THAN ('2028-09-01') ENGINE = InnoDB,
 PARTITION p202809 VALUES LESS THAN ('2028-10-01') ENGINE = InnoDB,
 PARTITION p202810 VALUES LESS THAN ('2028-11-01') ENGINE = InnoDB,
 PARTITION p202811 VALUES LESS THAN ('2028-12-01') ENGINE = InnoDB,
 PARTITION p202812 VALUES LESS THAN ('2029-01-01') ENGINE = InnoDB,
 PARTITION p202901 VALUES LESS THAN ('2029-02-01') ENGINE = InnoDB,
 PARTITION p202902 VALUES LESS THAN ('2029-03-01') ENGINE = InnoDB,
 PARTITION p202903 VALUES LESS THAN ('2029-04-01') ENGINE = InnoDB,
 PARTITION p202904 VALUES LESS THAN ('2029-05-01') ENGINE = InnoDB,
 PARTITION p202905 VALUES LESS THAN ('2029-06-01') ENGINE = InnoDB,
 PARTITION p202906 VALUES LESS THAN ('2029-07-01') ENGINE = InnoDB,
 PARTITION p202907 VALUES LESS THAN ('2029-08-01') ENGINE = InnoDB,
 PARTITION p202908 VALUES LESS THAN ('2029-09-01') ENGINE = InnoDB,
 PARTITION p202909 VALUES LESS THAN ('2029-10-01') ENGINE = InnoDB,
 PARTITION p202910 VALUES LESS THAN ('2029-11-01') ENGINE = InnoDB,
 PARTITION p202911 VALUES LESS THAN ('2029-12-01') ENGINE = InnoDB,
 PARTITION p202912 VALUES LESS THAN ('2030-01-01') ENGINE = InnoDB,
 PARTITION p203001 VALUES LESS THAN ('2030-02-01') ENGINE = InnoDB,
 PARTITION p203002 VALUES LESS THAN ('2030-03-01') ENGINE = InnoDB,
 PARTITION p203003 VALUES LESS THAN ('2030-04-01') ENGINE = InnoDB,
 PARTITION p203004 VALUES LESS THAN ('2030-05-01') ENGINE = InnoDB,
 PARTITION p203005 VALUES LESS THAN ('2030-06-01') ENGINE = InnoDB,
 PARTITION p203006 VALUES LESS THAN ('2030-07-01') ENGINE = InnoDB,
 PARTITION p203007 VALUES LESS THAN ('2030-08-01') ENGINE = InnoDB,
 PARTITION p203008 VALUES LESS THAN ('2030-09-01') ENGINE = InnoDB,
 PARTITION p203009 VALUES LESS THAN ('2030-10-01') ENGINE = InnoDB,
 PARTITION p203010 VALUES LESS THAN ('2030-11-01') ENGINE = InnoDB,
 PARTITION p203011 VALUES LESS THAN ('2030-12-01') ENGINE = InnoDB,
 PARTITION p203012 VALUES LESS THAN ('2031-01-01') ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_deal_wait_targets`
--

DROP TABLE IF EXISTS `log_deal_wait_targets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_deal_wait_targets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '仕入れ待ち対象ログID',
  `log_transaction_id` varbinary(32) DEFAULT NULL COMMENT 'ログトランザクションID',
  `target_id` bigint(20) NOT NULL COMMENT '対象ID(問屋商品ID/問屋什器ID)',
  `dealer_id` int(11) NOT NULL COMMENT '問屋ID',
  `subject_id` bigint(20) NOT NULL COMMENT '対象物ID(商品ID/什器ID)',
  `num` int(11) NOT NULL COMMENT '個数',
  `buy_price` int(11) NOT NULL COMMENT '価格',
  `buy_store_point` int(11) NOT NULL COMMENT '必要ストアポイント',
  `buy_guest_point` int(11) NOT NULL COMMENT '必要ゲストポイント',
  `wait_time` int(11) NOT NULL COMMENT '仕入れ待ち時間',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`,`created_at`),
  KEY `idx_log_deal_wait_targets_1` (`log_transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='仕入れ待ち対象ログ'
/*!50500 PARTITION BY RANGE  COLUMNS(created_at)
(PARTITION p201512 VALUES LESS THAN ('2016-01-01') ENGINE = InnoDB,
 PARTITION p201601 VALUES LESS THAN ('2016-02-01') ENGINE = InnoDB,
 PARTITION p201602 VALUES LESS THAN ('2016-03-01') ENGINE = InnoDB,
 PARTITION p201603 VALUES LESS THAN ('2016-04-01') ENGINE = InnoDB,
 PARTITION p201604 VALUES LESS THAN ('2016-05-01') ENGINE = InnoDB,
 PARTITION p201605 VALUES LESS THAN ('2016-06-01') ENGINE = InnoDB,
 PARTITION p201606 VALUES LESS THAN ('2016-07-01') ENGINE = InnoDB,
 PARTITION p201607 VALUES LESS THAN ('2016-08-01') ENGINE = InnoDB,
 PARTITION p201608 VALUES LESS THAN ('2016-09-01') ENGINE = InnoDB,
 PARTITION p201609 VALUES LESS THAN ('2016-10-01') ENGINE = InnoDB,
 PARTITION p201610 VALUES LESS THAN ('2016-11-01') ENGINE = InnoDB,
 PARTITION p201611 VALUES LESS THAN ('2016-12-01') ENGINE = InnoDB,
 PARTITION p201612 VALUES LESS THAN ('2017-01-01') ENGINE = InnoDB,
 PARTITION p201701 VALUES LESS THAN ('2017-02-01') ENGINE = InnoDB,
 PARTITION p201702 VALUES LESS THAN ('2017-03-01') ENGINE = InnoDB,
 PARTITION p201703 VALUES LESS THAN ('2017-04-01') ENGINE = InnoDB,
 PARTITION p201704 VALUES LESS THAN ('2017-05-01') ENGINE = InnoDB,
 PARTITION p201705 VALUES LESS THAN ('2017-06-01') ENGINE = InnoDB,
 PARTITION p201706 VALUES LESS THAN ('2017-07-01') ENGINE = InnoDB,
 PARTITION p201707 VALUES LESS THAN ('2017-08-01') ENGINE = InnoDB,
 PARTITION p201708 VALUES LESS THAN ('2017-09-01') ENGINE = InnoDB,
 PARTITION p201709 VALUES LESS THAN ('2017-10-01') ENGINE = InnoDB,
 PARTITION p201710 VALUES LESS THAN ('2017-11-01') ENGINE = InnoDB,
 PARTITION p201711 VALUES LESS THAN ('2017-12-01') ENGINE = InnoDB,
 PARTITION p201712 VALUES LESS THAN ('2018-01-01') ENGINE = InnoDB,
 PARTITION p201801 VALUES LESS THAN ('2018-02-01') ENGINE = InnoDB,
 PARTITION p201802 VALUES LESS THAN ('2018-03-01') ENGINE = InnoDB,
 PARTITION p201803 VALUES LESS THAN ('2018-04-01') ENGINE = InnoDB,
 PARTITION p201804 VALUES LESS THAN ('2018-05-01') ENGINE = InnoDB,
 PARTITION p201805 VALUES LESS THAN ('2018-06-01') ENGINE = InnoDB,
 PARTITION p201806 VALUES LESS THAN ('2018-07-01') ENGINE = InnoDB,
 PARTITION p201807 VALUES LESS THAN ('2018-08-01') ENGINE = InnoDB,
 PARTITION p201808 VALUES LESS THAN ('2018-09-01') ENGINE = InnoDB,
 PARTITION p201809 VALUES LESS THAN ('2018-10-01') ENGINE = InnoDB,
 PARTITION p201810 VALUES LESS THAN ('2018-11-01') ENGINE = InnoDB,
 PARTITION p201811 VALUES LESS THAN ('2018-12-01') ENGINE = InnoDB,
 PARTITION p201812 VALUES LESS THAN ('2019-01-01') ENGINE = InnoDB,
 PARTITION p201901 VALUES LESS THAN ('2019-02-01') ENGINE = InnoDB,
 PARTITION p201902 VALUES LESS THAN ('2019-03-01') ENGINE = InnoDB,
 PARTITION p201903 VALUES LESS THAN ('2019-04-01') ENGINE = InnoDB,
 PARTITION p201904 VALUES LESS THAN ('2019-05-01') ENGINE = InnoDB,
 PARTITION p201905 VALUES LESS THAN ('2019-06-01') ENGINE = InnoDB,
 PARTITION p201906 VALUES LESS THAN ('2019-07-01') ENGINE = InnoDB,
 PARTITION p201907 VALUES LESS THAN ('2019-08-01') ENGINE = InnoDB,
 PARTITION p201908 VALUES LESS THAN ('2019-09-01') ENGINE = InnoDB,
 PARTITION p201909 VALUES LESS THAN ('2019-10-01') ENGINE = InnoDB,
 PARTITION p201910 VALUES LESS THAN ('2019-11-01') ENGINE = InnoDB,
 PARTITION p201911 VALUES LESS THAN ('2019-12-01') ENGINE = InnoDB,
 PARTITION p201912 VALUES LESS THAN ('2020-01-01') ENGINE = InnoDB,
 PARTITION p202001 VALUES LESS THAN ('2020-02-01') ENGINE = InnoDB,
 PARTITION p202002 VALUES LESS THAN ('2020-03-01') ENGINE = InnoDB,
 PARTITION p202003 VALUES LESS THAN ('2020-04-01') ENGINE = InnoDB,
 PARTITION p202004 VALUES LESS THAN ('2020-05-01') ENGINE = InnoDB,
 PARTITION p202005 VALUES LESS THAN ('2020-06-01') ENGINE = InnoDB,
 PARTITION p202006 VALUES LESS THAN ('2020-07-01') ENGINE = InnoDB,
 PARTITION p202007 VALUES LESS THAN ('2020-08-01') ENGINE = InnoDB,
 PARTITION p202008 VALUES LESS THAN ('2020-09-01') ENGINE = InnoDB,
 PARTITION p202009 VALUES LESS THAN ('2020-10-01') ENGINE = InnoDB,
 PARTITION p202010 VALUES LESS THAN ('2020-11-01') ENGINE = InnoDB,
 PARTITION p202011 VALUES LESS THAN ('2020-12-01') ENGINE = InnoDB,
 PARTITION p202012 VALUES LESS THAN ('2021-01-01') ENGINE = InnoDB,
 PARTITION p202101 VALUES LESS THAN ('2021-02-01') ENGINE = InnoDB,
 PARTITION p202102 VALUES LESS THAN ('2021-03-01') ENGINE = InnoDB,
 PARTITION p202103 VALUES LESS THAN ('2021-04-01') ENGINE = InnoDB,
 PARTITION p202104 VALUES LESS THAN ('2021-05-01') ENGINE = InnoDB,
 PARTITION p202105 VALUES LESS THAN ('2021-06-01') ENGINE = InnoDB,
 PARTITION p202106 VALUES LESS THAN ('2021-07-01') ENGINE = InnoDB,
 PARTITION p202107 VALUES LESS THAN ('2021-08-01') ENGINE = InnoDB,
 PARTITION p202108 VALUES LESS THAN ('2021-09-01') ENGINE = InnoDB,
 PARTITION p202109 VALUES LESS THAN ('2021-10-01') ENGINE = InnoDB,
 PARTITION p202110 VALUES LESS THAN ('2021-11-01') ENGINE = InnoDB,
 PARTITION p202111 VALUES LESS THAN ('2021-12-01') ENGINE = InnoDB,
 PARTITION p202112 VALUES LESS THAN ('2022-01-01') ENGINE = InnoDB,
 PARTITION p202201 VALUES LESS THAN ('2022-02-01') ENGINE = InnoDB,
 PARTITION p202202 VALUES LESS THAN ('2022-03-01') ENGINE = InnoDB,
 PARTITION p202203 VALUES LESS THAN ('2022-04-01') ENGINE = InnoDB,
 PARTITION p202204 VALUES LESS THAN ('2022-05-01') ENGINE = InnoDB,
 PARTITION p202205 VALUES LESS THAN ('2022-06-01') ENGINE = InnoDB,
 PARTITION p202206 VALUES LESS THAN ('2022-07-01') ENGINE = InnoDB,
 PARTITION p202207 VALUES LESS THAN ('2022-08-01') ENGINE = InnoDB,
 PARTITION p202208 VALUES LESS THAN ('2022-09-01') ENGINE = InnoDB,
 PARTITION p202209 VALUES LESS THAN ('2022-10-01') ENGINE = InnoDB,
 PARTITION p202210 VALUES LESS THAN ('2022-11-01') ENGINE = InnoDB,
 PARTITION p202211 VALUES LESS THAN ('2022-12-01') ENGINE = InnoDB,
 PARTITION p202212 VALUES LESS THAN ('2023-01-01') ENGINE = InnoDB,
 PARTITION p202301 VALUES LESS THAN ('2023-02-01') ENGINE = InnoDB,
 PARTITION p202302 VALUES LESS THAN ('2023-03-01') ENGINE = InnoDB,
 PARTITION p202303 VALUES LESS THAN ('2023-04-01') ENGINE = InnoDB,
 PARTITION p202304 VALUES LESS THAN ('2023-05-01') ENGINE = InnoDB,
 PARTITION p202305 VALUES LESS THAN ('2023-06-01') ENGINE = InnoDB,
 PARTITION p202306 VALUES LESS THAN ('2023-07-01') ENGINE = InnoDB,
 PARTITION p202307 VALUES LESS THAN ('2023-08-01') ENGINE = InnoDB,
 PARTITION p202308 VALUES LESS THAN ('2023-09-01') ENGINE = InnoDB,
 PARTITION p202309 VALUES LESS THAN ('2023-10-01') ENGINE = InnoDB,
 PARTITION p202310 VALUES LESS THAN ('2023-11-01') ENGINE = InnoDB,
 PARTITION p202311 VALUES LESS THAN ('2023-12-01') ENGINE = InnoDB,
 PARTITION p202312 VALUES LESS THAN ('2024-01-01') ENGINE = InnoDB,
 PARTITION p202401 VALUES LESS THAN ('2024-02-01') ENGINE = InnoDB,
 PARTITION p202402 VALUES LESS THAN ('2024-03-01') ENGINE = InnoDB,
 PARTITION p202403 VALUES LESS THAN ('2024-04-01') ENGINE = InnoDB,
 PARTITION p202404 VALUES LESS THAN ('2024-05-01') ENGINE = InnoDB,
 PARTITION p202405 VALUES LESS THAN ('2024-06-01') ENGINE = InnoDB,
 PARTITION p202406 VALUES LESS THAN ('2024-07-01') ENGINE = InnoDB,
 PARTITION p202407 VALUES LESS THAN ('2024-08-01') ENGINE = InnoDB,
 PARTITION p202408 VALUES LESS THAN ('2024-09-01') ENGINE = InnoDB,
 PARTITION p202409 VALUES LESS THAN ('2024-10-01') ENGINE = InnoDB,
 PARTITION p202410 VALUES LESS THAN ('2024-11-01') ENGINE = InnoDB,
 PARTITION p202411 VALUES LESS THAN ('2024-12-01') ENGINE = InnoDB,
 PARTITION p202412 VALUES LESS THAN ('2025-01-01') ENGINE = InnoDB,
 PARTITION p202501 VALUES LESS THAN ('2025-02-01') ENGINE = InnoDB,
 PARTITION p202502 VALUES LESS THAN ('2025-03-01') ENGINE = InnoDB,
 PARTITION p202503 VALUES LESS THAN ('2025-04-01') ENGINE = InnoDB,
 PARTITION p202504 VALUES LESS THAN ('2025-05-01') ENGINE = InnoDB,
 PARTITION p202505 VALUES LESS THAN ('2025-06-01') ENGINE = InnoDB,
 PARTITION p202506 VALUES LESS THAN ('2025-07-01') ENGINE = InnoDB,
 PARTITION p202507 VALUES LESS THAN ('2025-08-01') ENGINE = InnoDB,
 PARTITION p202508 VALUES LESS THAN ('2025-09-01') ENGINE = InnoDB,
 PARTITION p202509 VALUES LESS THAN ('2025-10-01') ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN ('2025-11-01') ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN ('2025-12-01') ENGINE = InnoDB,
 PARTITION p202512 VALUES LESS THAN ('2026-01-01') ENGINE = InnoDB,
 PARTITION p202601 VALUES LESS THAN ('2026-02-01') ENGINE = InnoDB,
 PARTITION p202602 VALUES LESS THAN ('2026-03-01') ENGINE = InnoDB,
 PARTITION p202603 VALUES LESS THAN ('2026-04-01') ENGINE = InnoDB,
 PARTITION p202604 VALUES LESS THAN ('2026-05-01') ENGINE = InnoDB,
 PARTITION p202605 VALUES LESS THAN ('2026-06-01') ENGINE = InnoDB,
 PARTITION p202606 VALUES LESS THAN ('2026-07-01') ENGINE = InnoDB,
 PARTITION p202607 VALUES LESS THAN ('2026-08-01') ENGINE = InnoDB,
 PARTITION p202608 VALUES LESS THAN ('2026-09-01') ENGINE = InnoDB,
 PARTITION p202609 VALUES LESS THAN ('2026-10-01') ENGINE = InnoDB,
 PARTITION p202610 VALUES LESS THAN ('2026-11-01') ENGINE = InnoDB,
 PARTITION p202611 VALUES LESS THAN ('2026-12-01') ENGINE = InnoDB,
 PARTITION p202612 VALUES LESS THAN ('2027-01-01') ENGINE = InnoDB,
 PARTITION p202701 VALUES LESS THAN ('2027-02-01') ENGINE = InnoDB,
 PARTITION p202702 VALUES LESS THAN ('2027-03-01') ENGINE = InnoDB,
 PARTITION p202703 VALUES LESS THAN ('2027-04-01') ENGINE = InnoDB,
 PARTITION p202704 VALUES LESS THAN ('2027-05-01') ENGINE = InnoDB,
 PARTITION p202705 VALUES LESS THAN ('2027-06-01') ENGINE = InnoDB,
 PARTITION p202706 VALUES LESS THAN ('2027-07-01') ENGINE = InnoDB,
 PARTITION p202707 VALUES LESS THAN ('2027-08-01') ENGINE = InnoDB,
 PARTITION p202708 VALUES LESS THAN ('2027-09-01') ENGINE = InnoDB,
 PARTITION p202709 VALUES LESS THAN ('2027-10-01') ENGINE = InnoDB,
 PARTITION p202710 VALUES LESS THAN ('2027-11-01') ENGINE = InnoDB,
 PARTITION p202711 VALUES LESS THAN ('2027-12-01') ENGINE = InnoDB,
 PARTITION p202712 VALUES LESS THAN ('2028-01-01') ENGINE = InnoDB,
 PARTITION p202801 VALUES LESS THAN ('2028-02-01') ENGINE = InnoDB,
 PARTITION p202802 VALUES LESS THAN ('2028-03-01') ENGINE = InnoDB,
 PARTITION p202803 VALUES LESS THAN ('2028-04-01') ENGINE = InnoDB,
 PARTITION p202804 VALUES LESS THAN ('2028-05-01') ENGINE = InnoDB,
 PARTITION p202805 VALUES LESS THAN ('2028-06-01') ENGINE = InnoDB,
 PARTITION p202806 VALUES LESS THAN ('2028-07-01') ENGINE = InnoDB,
 PARTITION p202807 VALUES LESS THAN ('2028-08-01') ENGINE = InnoDB,
 PARTITION p202808 VALUES LESS THAN ('2028-09-01') ENGINE = InnoDB,
 PARTITION p202809 VALUES LESS THAN ('2028-10-01') ENGINE = InnoDB,
 PARTITION p202810 VALUES LESS THAN ('2028-11-01') ENGINE = InnoDB,
 PARTITION p202811 VALUES LESS THAN ('2028-12-01') ENGINE = InnoDB,
 PARTITION p202812 VALUES LESS THAN ('2029-01-01') ENGINE = InnoDB,
 PARTITION p202901 VALUES LESS THAN ('2029-02-01') ENGINE = InnoDB,
 PARTITION p202902 VALUES LESS THAN ('2029-03-01') ENGINE = InnoDB,
 PARTITION p202903 VALUES LESS THAN ('2029-04-01') ENGINE = InnoDB,
 PARTITION p202904 VALUES LESS THAN ('2029-05-01') ENGINE = InnoDB,
 PARTITION p202905 VALUES LESS THAN ('2029-06-01') ENGINE = InnoDB,
 PARTITION p202906 VALUES LESS THAN ('2029-07-01') ENGINE = InnoDB,
 PARTITION p202907 VALUES LESS THAN ('2029-08-01') ENGINE = InnoDB,
 PARTITION p202908 VALUES LESS THAN ('2029-09-01') ENGINE = InnoDB,
 PARTITION p202909 VALUES LESS THAN ('2029-10-01') ENGINE = InnoDB,
 PARTITION p202910 VALUES LESS THAN ('2029-11-01') ENGINE = InnoDB,
 PARTITION p202911 VALUES LESS THAN ('2029-12-01') ENGINE = InnoDB,
 PARTITION p202912 VALUES LESS THAN ('2030-01-01') ENGINE = InnoDB,
 PARTITION p203001 VALUES LESS THAN ('2030-02-01') ENGINE = InnoDB,
 PARTITION p203002 VALUES LESS THAN ('2030-03-01') ENGINE = InnoDB,
 PARTITION p203003 VALUES LESS THAN ('2030-04-01') ENGINE = InnoDB,
 PARTITION p203004 VALUES LESS THAN ('2030-05-01') ENGINE = InnoDB,
 PARTITION p203005 VALUES LESS THAN ('2030-06-01') ENGINE = InnoDB,
 PARTITION p203006 VALUES LESS THAN ('2030-07-01') ENGINE = InnoDB,
 PARTITION p203007 VALUES LESS THAN ('2030-08-01') ENGINE = InnoDB,
 PARTITION p203008 VALUES LESS THAN ('2030-09-01') ENGINE = InnoDB,
 PARTITION p203009 VALUES LESS THAN ('2030-10-01') ENGINE = InnoDB,
 PARTITION p203010 VALUES LESS THAN ('2030-11-01') ENGINE = InnoDB,
 PARTITION p203011 VALUES LESS THAN ('2030-12-01') ENGINE = InnoDB,
 PARTITION p203012 VALUES LESS THAN ('2031-01-01') ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_deal_waits`
--

DROP TABLE IF EXISTS `log_deal_waits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_deal_waits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '仕入れ待ちログID',
  `log_transaction_id` varbinary(32) DEFAULT NULL COMMENT 'ログトランザクションID',
  `deal_wait_id` int(10) unsigned NOT NULL COMMENT '仕入れ待ちID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `complete_at` datetime NOT NULL COMMENT '完了日時',
  `is_complete` tinyint(4) NOT NULL COMMENT '完了フラグ',
  `org_created_at` datetime NOT NULL COMMENT '元データ作成日時',
  `org_updated_at` datetime NOT NULL COMMENT '元データ更新日時',
  `crud_kind` binary(1) DEFAULT NULL COMMENT 'CRUD種別',
  `class_id` varchar(40) DEFAULT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`,`created_at`),
  KEY `idx_log_deal_waits_1` (`log_transaction_id`),
  KEY `idx_log_deal_waits_2` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='仕入れ待ちログ'
/*!50500 PARTITION BY RANGE  COLUMNS(created_at)
(PARTITION p201512 VALUES LESS THAN ('2016-01-01') ENGINE = InnoDB,
 PARTITION p201601 VALUES LESS THAN ('2016-02-01') ENGINE = InnoDB,
 PARTITION p201602 VALUES LESS THAN ('2016-03-01') ENGINE = InnoDB,
 PARTITION p201603 VALUES LESS THAN ('2016-04-01') ENGINE = InnoDB,
 PARTITION p201604 VALUES LESS THAN ('2016-05-01') ENGINE = InnoDB,
 PARTITION p201605 VALUES LESS THAN ('2016-06-01') ENGINE = InnoDB,
 PARTITION p201606 VALUES LESS THAN ('2016-07-01') ENGINE = InnoDB,
 PARTITION p201607 VALUES LESS THAN ('2016-08-01') ENGINE = InnoDB,
 PARTITION p201608 VALUES LESS THAN ('2016-09-01') ENGINE = InnoDB,
 PARTITION p201609 VALUES LESS THAN ('2016-10-01') ENGINE = InnoDB,
 PARTITION p201610 VALUES LESS THAN ('2016-11-01') ENGINE = InnoDB,
 PARTITION p201611 VALUES LESS THAN ('2016-12-01') ENGINE = InnoDB,
 PARTITION p201612 VALUES LESS THAN ('2017-01-01') ENGINE = InnoDB,
 PARTITION p201701 VALUES LESS THAN ('2017-02-01') ENGINE = InnoDB,
 PARTITION p201702 VALUES LESS THAN ('2017-03-01') ENGINE = InnoDB,
 PARTITION p201703 VALUES LESS THAN ('2017-04-01') ENGINE = InnoDB,
 PARTITION p201704 VALUES LESS THAN ('2017-05-01') ENGINE = InnoDB,
 PARTITION p201705 VALUES LESS THAN ('2017-06-01') ENGINE = InnoDB,
 PARTITION p201706 VALUES LESS THAN ('2017-07-01') ENGINE = InnoDB,
 PARTITION p201707 VALUES LESS THAN ('2017-08-01') ENGINE = InnoDB,
 PARTITION p201708 VALUES LESS THAN ('2017-09-01') ENGINE = InnoDB,
 PARTITION p201709 VALUES LESS THAN ('2017-10-01') ENGINE = InnoDB,
 PARTITION p201710 VALUES LESS THAN ('2017-11-01') ENGINE = InnoDB,
 PARTITION p201711 VALUES LESS THAN ('2017-12-01') ENGINE = InnoDB,
 PARTITION p201712 VALUES LESS THAN ('2018-01-01') ENGINE = InnoDB,
 PARTITION p201801 VALUES LESS THAN ('2018-02-01') ENGINE = InnoDB,
 PARTITION p201802 VALUES LESS THAN ('2018-03-01') ENGINE = InnoDB,
 PARTITION p201803 VALUES LESS THAN ('2018-04-01') ENGINE = InnoDB,
 PARTITION p201804 VALUES LESS THAN ('2018-05-01') ENGINE = InnoDB,
 PARTITION p201805 VALUES LESS THAN ('2018-06-01') ENGINE = InnoDB,
 PARTITION p201806 VALUES LESS THAN ('2018-07-01') ENGINE = InnoDB,
 PARTITION p201807 VALUES LESS THAN ('2018-08-01') ENGINE = InnoDB,
 PARTITION p201808 VALUES LESS THAN ('2018-09-01') ENGINE = InnoDB,
 PARTITION p201809 VALUES LESS THAN ('2018-10-01') ENGINE = InnoDB,
 PARTITION p201810 VALUES LESS THAN ('2018-11-01') ENGINE = InnoDB,
 PARTITION p201811 VALUES LESS THAN ('2018-12-01') ENGINE = InnoDB,
 PARTITION p201812 VALUES LESS THAN ('2019-01-01') ENGINE = InnoDB,
 PARTITION p201901 VALUES LESS THAN ('2019-02-01') ENGINE = InnoDB,
 PARTITION p201902 VALUES LESS THAN ('2019-03-01') ENGINE = InnoDB,
 PARTITION p201903 VALUES LESS THAN ('2019-04-01') ENGINE = InnoDB,
 PARTITION p201904 VALUES LESS THAN ('2019-05-01') ENGINE = InnoDB,
 PARTITION p201905 VALUES LESS THAN ('2019-06-01') ENGINE = InnoDB,
 PARTITION p201906 VALUES LESS THAN ('2019-07-01') ENGINE = InnoDB,
 PARTITION p201907 VALUES LESS THAN ('2019-08-01') ENGINE = InnoDB,
 PARTITION p201908 VALUES LESS THAN ('2019-09-01') ENGINE = InnoDB,
 PARTITION p201909 VALUES LESS THAN ('2019-10-01') ENGINE = InnoDB,
 PARTITION p201910 VALUES LESS THAN ('2019-11-01') ENGINE = InnoDB,
 PARTITION p201911 VALUES LESS THAN ('2019-12-01') ENGINE = InnoDB,
 PARTITION p201912 VALUES LESS THAN ('2020-01-01') ENGINE = InnoDB,
 PARTITION p202001 VALUES LESS THAN ('2020-02-01') ENGINE = InnoDB,
 PARTITION p202002 VALUES LESS THAN ('2020-03-01') ENGINE = InnoDB,
 PARTITION p202003 VALUES LESS THAN ('2020-04-01') ENGINE = InnoDB,
 PARTITION p202004 VALUES LESS THAN ('2020-05-01') ENGINE = InnoDB,
 PARTITION p202005 VALUES LESS THAN ('2020-06-01') ENGINE = InnoDB,
 PARTITION p202006 VALUES LESS THAN ('2020-07-01') ENGINE = InnoDB,
 PARTITION p202007 VALUES LESS THAN ('2020-08-01') ENGINE = InnoDB,
 PARTITION p202008 VALUES LESS THAN ('2020-09-01') ENGINE = InnoDB,
 PARTITION p202009 VALUES LESS THAN ('2020-10-01') ENGINE = InnoDB,
 PARTITION p202010 VALUES LESS THAN ('2020-11-01') ENGINE = InnoDB,
 PARTITION p202011 VALUES LESS THAN ('2020-12-01') ENGINE = InnoDB,
 PARTITION p202012 VALUES LESS THAN ('2021-01-01') ENGINE = InnoDB,
 PARTITION p202101 VALUES LESS THAN ('2021-02-01') ENGINE = InnoDB,
 PARTITION p202102 VALUES LESS THAN ('2021-03-01') ENGINE = InnoDB,
 PARTITION p202103 VALUES LESS THAN ('2021-04-01') ENGINE = InnoDB,
 PARTITION p202104 VALUES LESS THAN ('2021-05-01') ENGINE = InnoDB,
 PARTITION p202105 VALUES LESS THAN ('2021-06-01') ENGINE = InnoDB,
 PARTITION p202106 VALUES LESS THAN ('2021-07-01') ENGINE = InnoDB,
 PARTITION p202107 VALUES LESS THAN ('2021-08-01') ENGINE = InnoDB,
 PARTITION p202108 VALUES LESS THAN ('2021-09-01') ENGINE = InnoDB,
 PARTITION p202109 VALUES LESS THAN ('2021-10-01') ENGINE = InnoDB,
 PARTITION p202110 VALUES LESS THAN ('2021-11-01') ENGINE = InnoDB,
 PARTITION p202111 VALUES LESS THAN ('2021-12-01') ENGINE = InnoDB,
 PARTITION p202112 VALUES LESS THAN ('2022-01-01') ENGINE = InnoDB,
 PARTITION p202201 VALUES LESS THAN ('2022-02-01') ENGINE = InnoDB,
 PARTITION p202202 VALUES LESS THAN ('2022-03-01') ENGINE = InnoDB,
 PARTITION p202203 VALUES LESS THAN ('2022-04-01') ENGINE = InnoDB,
 PARTITION p202204 VALUES LESS THAN ('2022-05-01') ENGINE = InnoDB,
 PARTITION p202205 VALUES LESS THAN ('2022-06-01') ENGINE = InnoDB,
 PARTITION p202206 VALUES LESS THAN ('2022-07-01') ENGINE = InnoDB,
 PARTITION p202207 VALUES LESS THAN ('2022-08-01') ENGINE = InnoDB,
 PARTITION p202208 VALUES LESS THAN ('2022-09-01') ENGINE = InnoDB,
 PARTITION p202209 VALUES LESS THAN ('2022-10-01') ENGINE = InnoDB,
 PARTITION p202210 VALUES LESS THAN ('2022-11-01') ENGINE = InnoDB,
 PARTITION p202211 VALUES LESS THAN ('2022-12-01') ENGINE = InnoDB,
 PARTITION p202212 VALUES LESS THAN ('2023-01-01') ENGINE = InnoDB,
 PARTITION p202301 VALUES LESS THAN ('2023-02-01') ENGINE = InnoDB,
 PARTITION p202302 VALUES LESS THAN ('2023-03-01') ENGINE = InnoDB,
 PARTITION p202303 VALUES LESS THAN ('2023-04-01') ENGINE = InnoDB,
 PARTITION p202304 VALUES LESS THAN ('2023-05-01') ENGINE = InnoDB,
 PARTITION p202305 VALUES LESS THAN ('2023-06-01') ENGINE = InnoDB,
 PARTITION p202306 VALUES LESS THAN ('2023-07-01') ENGINE = InnoDB,
 PARTITION p202307 VALUES LESS THAN ('2023-08-01') ENGINE = InnoDB,
 PARTITION p202308 VALUES LESS THAN ('2023-09-01') ENGINE = InnoDB,
 PARTITION p202309 VALUES LESS THAN ('2023-10-01') ENGINE = InnoDB,
 PARTITION p202310 VALUES LESS THAN ('2023-11-01') ENGINE = InnoDB,
 PARTITION p202311 VALUES LESS THAN ('2023-12-01') ENGINE = InnoDB,
 PARTITION p202312 VALUES LESS THAN ('2024-01-01') ENGINE = InnoDB,
 PARTITION p202401 VALUES LESS THAN ('2024-02-01') ENGINE = InnoDB,
 PARTITION p202402 VALUES LESS THAN ('2024-03-01') ENGINE = InnoDB,
 PARTITION p202403 VALUES LESS THAN ('2024-04-01') ENGINE = InnoDB,
 PARTITION p202404 VALUES LESS THAN ('2024-05-01') ENGINE = InnoDB,
 PARTITION p202405 VALUES LESS THAN ('2024-06-01') ENGINE = InnoDB,
 PARTITION p202406 VALUES LESS THAN ('2024-07-01') ENGINE = InnoDB,
 PARTITION p202407 VALUES LESS THAN ('2024-08-01') ENGINE = InnoDB,
 PARTITION p202408 VALUES LESS THAN ('2024-09-01') ENGINE = InnoDB,
 PARTITION p202409 VALUES LESS THAN ('2024-10-01') ENGINE = InnoDB,
 PARTITION p202410 VALUES LESS THAN ('2024-11-01') ENGINE = InnoDB,
 PARTITION p202411 VALUES LESS THAN ('2024-12-01') ENGINE = InnoDB,
 PARTITION p202412 VALUES LESS THAN ('2025-01-01') ENGINE = InnoDB,
 PARTITION p202501 VALUES LESS THAN ('2025-02-01') ENGINE = InnoDB,
 PARTITION p202502 VALUES LESS THAN ('2025-03-01') ENGINE = InnoDB,
 PARTITION p202503 VALUES LESS THAN ('2025-04-01') ENGINE = InnoDB,
 PARTITION p202504 VALUES LESS THAN ('2025-05-01') ENGINE = InnoDB,
 PARTITION p202505 VALUES LESS THAN ('2025-06-01') ENGINE = InnoDB,
 PARTITION p202506 VALUES LESS THAN ('2025-07-01') ENGINE = InnoDB,
 PARTITION p202507 VALUES LESS THAN ('2025-08-01') ENGINE = InnoDB,
 PARTITION p202508 VALUES LESS THAN ('2025-09-01') ENGINE = InnoDB,
 PARTITION p202509 VALUES LESS THAN ('2025-10-01') ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN ('2025-11-01') ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN ('2025-12-01') ENGINE = InnoDB,
 PARTITION p202512 VALUES LESS THAN ('2026-01-01') ENGINE = InnoDB,
 PARTITION p202601 VALUES LESS THAN ('2026-02-01') ENGINE = InnoDB,
 PARTITION p202602 VALUES LESS THAN ('2026-03-01') ENGINE = InnoDB,
 PARTITION p202603 VALUES LESS THAN ('2026-04-01') ENGINE = InnoDB,
 PARTITION p202604 VALUES LESS THAN ('2026-05-01') ENGINE = InnoDB,
 PARTITION p202605 VALUES LESS THAN ('2026-06-01') ENGINE = InnoDB,
 PARTITION p202606 VALUES LESS THAN ('2026-07-01') ENGINE = InnoDB,
 PARTITION p202607 VALUES LESS THAN ('2026-08-01') ENGINE = InnoDB,
 PARTITION p202608 VALUES LESS THAN ('2026-09-01') ENGINE = InnoDB,
 PARTITION p202609 VALUES LESS THAN ('2026-10-01') ENGINE = InnoDB,
 PARTITION p202610 VALUES LESS THAN ('2026-11-01') ENGINE = InnoDB,
 PARTITION p202611 VALUES LESS THAN ('2026-12-01') ENGINE = InnoDB,
 PARTITION p202612 VALUES LESS THAN ('2027-01-01') ENGINE = InnoDB,
 PARTITION p202701 VALUES LESS THAN ('2027-02-01') ENGINE = InnoDB,
 PARTITION p202702 VALUES LESS THAN ('2027-03-01') ENGINE = InnoDB,
 PARTITION p202703 VALUES LESS THAN ('2027-04-01') ENGINE = InnoDB,
 PARTITION p202704 VALUES LESS THAN ('2027-05-01') ENGINE = InnoDB,
 PARTITION p202705 VALUES LESS THAN ('2027-06-01') ENGINE = InnoDB,
 PARTITION p202706 VALUES LESS THAN ('2027-07-01') ENGINE = InnoDB,
 PARTITION p202707 VALUES LESS THAN ('2027-08-01') ENGINE = InnoDB,
 PARTITION p202708 VALUES LESS THAN ('2027-09-01') ENGINE = InnoDB,
 PARTITION p202709 VALUES LESS THAN ('2027-10-01') ENGINE = InnoDB,
 PARTITION p202710 VALUES LESS THAN ('2027-11-01') ENGINE = InnoDB,
 PARTITION p202711 VALUES LESS THAN ('2027-12-01') ENGINE = InnoDB,
 PARTITION p202712 VALUES LESS THAN ('2028-01-01') ENGINE = InnoDB,
 PARTITION p202801 VALUES LESS THAN ('2028-02-01') ENGINE = InnoDB,
 PARTITION p202802 VALUES LESS THAN ('2028-03-01') ENGINE = InnoDB,
 PARTITION p202803 VALUES LESS THAN ('2028-04-01') ENGINE = InnoDB,
 PARTITION p202804 VALUES LESS THAN ('2028-05-01') ENGINE = InnoDB,
 PARTITION p202805 VALUES LESS THAN ('2028-06-01') ENGINE = InnoDB,
 PARTITION p202806 VALUES LESS THAN ('2028-07-01') ENGINE = InnoDB,
 PARTITION p202807 VALUES LESS THAN ('2028-08-01') ENGINE = InnoDB,
 PARTITION p202808 VALUES LESS THAN ('2028-09-01') ENGINE = InnoDB,
 PARTITION p202809 VALUES LESS THAN ('2028-10-01') ENGINE = InnoDB,
 PARTITION p202810 VALUES LESS THAN ('2028-11-01') ENGINE = InnoDB,
 PARTITION p202811 VALUES LESS THAN ('2028-12-01') ENGINE = InnoDB,
 PARTITION p202812 VALUES LESS THAN ('2029-01-01') ENGINE = InnoDB,
 PARTITION p202901 VALUES LESS THAN ('2029-02-01') ENGINE = InnoDB,
 PARTITION p202902 VALUES LESS THAN ('2029-03-01') ENGINE = InnoDB,
 PARTITION p202903 VALUES LESS THAN ('2029-04-01') ENGINE = InnoDB,
 PARTITION p202904 VALUES LESS THAN ('2029-05-01') ENGINE = InnoDB,
 PARTITION p202905 VALUES LESS THAN ('2029-06-01') ENGINE = InnoDB,
 PARTITION p202906 VALUES LESS THAN ('2029-07-01') ENGINE = InnoDB,
 PARTITION p202907 VALUES LESS THAN ('2029-08-01') ENGINE = InnoDB,
 PARTITION p202908 VALUES LESS THAN ('2029-09-01') ENGINE = InnoDB,
 PARTITION p202909 VALUES LESS THAN ('2029-10-01') ENGINE = InnoDB,
 PARTITION p202910 VALUES LESS THAN ('2029-11-01') ENGINE = InnoDB,
 PARTITION p202911 VALUES LESS THAN ('2029-12-01') ENGINE = InnoDB,
 PARTITION p202912 VALUES LESS THAN ('2030-01-01') ENGINE = InnoDB,
 PARTITION p203001 VALUES LESS THAN ('2030-02-01') ENGINE = InnoDB,
 PARTITION p203002 VALUES LESS THAN ('2030-03-01') ENGINE = InnoDB,
 PARTITION p203003 VALUES LESS THAN ('2030-04-01') ENGINE = InnoDB,
 PARTITION p203004 VALUES LESS THAN ('2030-05-01') ENGINE = InnoDB,
 PARTITION p203005 VALUES LESS THAN ('2030-06-01') ENGINE = InnoDB,
 PARTITION p203006 VALUES LESS THAN ('2030-07-01') ENGINE = InnoDB,
 PARTITION p203007 VALUES LESS THAN ('2030-08-01') ENGINE = InnoDB,
 PARTITION p203008 VALUES LESS THAN ('2030-09-01') ENGINE = InnoDB,
 PARTITION p203009 VALUES LESS THAN ('2030-10-01') ENGINE = InnoDB,
 PARTITION p203010 VALUES LESS THAN ('2030-11-01') ENGINE = InnoDB,
 PARTITION p203011 VALUES LESS THAN ('2030-12-01') ENGINE = InnoDB,
 PARTITION p203012 VALUES LESS THAN ('2031-01-01') ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_diary_configs`
--

DROP TABLE IF EXISTS `log_diary_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_diary_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '日記設定ログ',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `visible_all` tinyint(4) NOT NULL COMMENT '全員公開設定',
  `visible_friend` tinyint(4) NOT NULL COMMENT '店とも公開設定',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_log_diary_configs_1` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='日記設定ログ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_diary_contents`
--

DROP TABLE IF EXISTS `log_diary_contents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_diary_contents` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '日記内容ログ',
  `content_id` int(11) unsigned NOT NULL COMMENT '日記内容ID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `subject` varchar(50) NOT NULL COMMENT '件名',
  `body` varchar(1100) NOT NULL COMMENT '本文',
  `content_created_at` datetime NOT NULL COMMENT '日記内容生成日時',
  `crud_kind` varbinary(1) DEFAULT NULL COMMENT 'CRUD種別',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`,`created_at`),
  KEY `idx_log_diary_contents_1` (`spid`,`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='日記内容ログ'
/*!50500 PARTITION BY RANGE  COLUMNS(created_at)
(PARTITION p201512 VALUES LESS THAN ('2016-01-01') ENGINE = InnoDB,
 PARTITION p201601 VALUES LESS THAN ('2016-02-01') ENGINE = InnoDB,
 PARTITION p201602 VALUES LESS THAN ('2016-03-01') ENGINE = InnoDB,
 PARTITION p201603 VALUES LESS THAN ('2016-04-01') ENGINE = InnoDB,
 PARTITION p201604 VALUES LESS THAN ('2016-05-01') ENGINE = InnoDB,
 PARTITION p201605 VALUES LESS THAN ('2016-06-01') ENGINE = InnoDB,
 PARTITION p201606 VALUES LESS THAN ('2016-07-01') ENGINE = InnoDB,
 PARTITION p201607 VALUES LESS THAN ('2016-08-01') ENGINE = InnoDB,
 PARTITION p201608 VALUES LESS THAN ('2016-09-01') ENGINE = InnoDB,
 PARTITION p201609 VALUES LESS THAN ('2016-10-01') ENGINE = InnoDB,
 PARTITION p201610 VALUES LESS THAN ('2016-11-01') ENGINE = InnoDB,
 PARTITION p201611 VALUES LESS THAN ('2016-12-01') ENGINE = InnoDB,
 PARTITION p201612 VALUES LESS THAN ('2017-01-01') ENGINE = InnoDB,
 PARTITION p201701 VALUES LESS THAN ('2017-02-01') ENGINE = InnoDB,
 PARTITION p201702 VALUES LESS THAN ('2017-03-01') ENGINE = InnoDB,
 PARTITION p201703 VALUES LESS THAN ('2017-04-01') ENGINE = InnoDB,
 PARTITION p201704 VALUES LESS THAN ('2017-05-01') ENGINE = InnoDB,
 PARTITION p201705 VALUES LESS THAN ('2017-06-01') ENGINE = InnoDB,
 PARTITION p201706 VALUES LESS THAN ('2017-07-01') ENGINE = InnoDB,
 PARTITION p201707 VALUES LESS THAN ('2017-08-01') ENGINE = InnoDB,
 PARTITION p201708 VALUES LESS THAN ('2017-09-01') ENGINE = InnoDB,
 PARTITION p201709 VALUES LESS THAN ('2017-10-01') ENGINE = InnoDB,
 PARTITION p201710 VALUES LESS THAN ('2017-11-01') ENGINE = InnoDB,
 PARTITION p201711 VALUES LESS THAN ('2017-12-01') ENGINE = InnoDB,
 PARTITION p201712 VALUES LESS THAN ('2018-01-01') ENGINE = InnoDB,
 PARTITION p201801 VALUES LESS THAN ('2018-02-01') ENGINE = InnoDB,
 PARTITION p201802 VALUES LESS THAN ('2018-03-01') ENGINE = InnoDB,
 PARTITION p201803 VALUES LESS THAN ('2018-04-01') ENGINE = InnoDB,
 PARTITION p201804 VALUES LESS THAN ('2018-05-01') ENGINE = InnoDB,
 PARTITION p201805 VALUES LESS THAN ('2018-06-01') ENGINE = InnoDB,
 PARTITION p201806 VALUES LESS THAN ('2018-07-01') ENGINE = InnoDB,
 PARTITION p201807 VALUES LESS THAN ('2018-08-01') ENGINE = InnoDB,
 PARTITION p201808 VALUES LESS THAN ('2018-09-01') ENGINE = InnoDB,
 PARTITION p201809 VALUES LESS THAN ('2018-10-01') ENGINE = InnoDB,
 PARTITION p201810 VALUES LESS THAN ('2018-11-01') ENGINE = InnoDB,
 PARTITION p201811 VALUES LESS THAN ('2018-12-01') ENGINE = InnoDB,
 PARTITION p201812 VALUES LESS THAN ('2019-01-01') ENGINE = InnoDB,
 PARTITION p201901 VALUES LESS THAN ('2019-02-01') ENGINE = InnoDB,
 PARTITION p201902 VALUES LESS THAN ('2019-03-01') ENGINE = InnoDB,
 PARTITION p201903 VALUES LESS THAN ('2019-04-01') ENGINE = InnoDB,
 PARTITION p201904 VALUES LESS THAN ('2019-05-01') ENGINE = InnoDB,
 PARTITION p201905 VALUES LESS THAN ('2019-06-01') ENGINE = InnoDB,
 PARTITION p201906 VALUES LESS THAN ('2019-07-01') ENGINE = InnoDB,
 PARTITION p201907 VALUES LESS THAN ('2019-08-01') ENGINE = InnoDB,
 PARTITION p201908 VALUES LESS THAN ('2019-09-01') ENGINE = InnoDB,
 PARTITION p201909 VALUES LESS THAN ('2019-10-01') ENGINE = InnoDB,
 PARTITION p201910 VALUES LESS THAN ('2019-11-01') ENGINE = InnoDB,
 PARTITION p201911 VALUES LESS THAN ('2019-12-01') ENGINE = InnoDB,
 PARTITION p201912 VALUES LESS THAN ('2020-01-01') ENGINE = InnoDB,
 PARTITION p202001 VALUES LESS THAN ('2020-02-01') ENGINE = InnoDB,
 PARTITION p202002 VALUES LESS THAN ('2020-03-01') ENGINE = InnoDB,
 PARTITION p202003 VALUES LESS THAN ('2020-04-01') ENGINE = InnoDB,
 PARTITION p202004 VALUES LESS THAN ('2020-05-01') ENGINE = InnoDB,
 PARTITION p202005 VALUES LESS THAN ('2020-06-01') ENGINE = InnoDB,
 PARTITION p202006 VALUES LESS THAN ('2020-07-01') ENGINE = InnoDB,
 PARTITION p202007 VALUES LESS THAN ('2020-08-01') ENGINE = InnoDB,
 PARTITION p202008 VALUES LESS THAN ('2020-09-01') ENGINE = InnoDB,
 PARTITION p202009 VALUES LESS THAN ('2020-10-01') ENGINE = InnoDB,
 PARTITION p202010 VALUES LESS THAN ('2020-11-01') ENGINE = InnoDB,
 PARTITION p202011 VALUES LESS THAN ('2020-12-01') ENGINE = InnoDB,
 PARTITION p202012 VALUES LESS THAN ('2021-01-01') ENGINE = InnoDB,
 PARTITION p202101 VALUES LESS THAN ('2021-02-01') ENGINE = InnoDB,
 PARTITION p202102 VALUES LESS THAN ('2021-03-01') ENGINE = InnoDB,
 PARTITION p202103 VALUES LESS THAN ('2021-04-01') ENGINE = InnoDB,
 PARTITION p202104 VALUES LESS THAN ('2021-05-01') ENGINE = InnoDB,
 PARTITION p202105 VALUES LESS THAN ('2021-06-01') ENGINE = InnoDB,
 PARTITION p202106 VALUES LESS THAN ('2021-07-01') ENGINE = InnoDB,
 PARTITION p202107 VALUES LESS THAN ('2021-08-01') ENGINE = InnoDB,
 PARTITION p202108 VALUES LESS THAN ('2021-09-01') ENGINE = InnoDB,
 PARTITION p202109 VALUES LESS THAN ('2021-10-01') ENGINE = InnoDB,
 PARTITION p202110 VALUES LESS THAN ('2021-11-01') ENGINE = InnoDB,
 PARTITION p202111 VALUES LESS THAN ('2021-12-01') ENGINE = InnoDB,
 PARTITION p202112 VALUES LESS THAN ('2022-01-01') ENGINE = InnoDB,
 PARTITION p202201 VALUES LESS THAN ('2022-02-01') ENGINE = InnoDB,
 PARTITION p202202 VALUES LESS THAN ('2022-03-01') ENGINE = InnoDB,
 PARTITION p202203 VALUES LESS THAN ('2022-04-01') ENGINE = InnoDB,
 PARTITION p202204 VALUES LESS THAN ('2022-05-01') ENGINE = InnoDB,
 PARTITION p202205 VALUES LESS THAN ('2022-06-01') ENGINE = InnoDB,
 PARTITION p202206 VALUES LESS THAN ('2022-07-01') ENGINE = InnoDB,
 PARTITION p202207 VALUES LESS THAN ('2022-08-01') ENGINE = InnoDB,
 PARTITION p202208 VALUES LESS THAN ('2022-09-01') ENGINE = InnoDB,
 PARTITION p202209 VALUES LESS THAN ('2022-10-01') ENGINE = InnoDB,
 PARTITION p202210 VALUES LESS THAN ('2022-11-01') ENGINE = InnoDB,
 PARTITION p202211 VALUES LESS THAN ('2022-12-01') ENGINE = InnoDB,
 PARTITION p202212 VALUES LESS THAN ('2023-01-01') ENGINE = InnoDB,
 PARTITION p202301 VALUES LESS THAN ('2023-02-01') ENGINE = InnoDB,
 PARTITION p202302 VALUES LESS THAN ('2023-03-01') ENGINE = InnoDB,
 PARTITION p202303 VALUES LESS THAN ('2023-04-01') ENGINE = InnoDB,
 PARTITION p202304 VALUES LESS THAN ('2023-05-01') ENGINE = InnoDB,
 PARTITION p202305 VALUES LESS THAN ('2023-06-01') ENGINE = InnoDB,
 PARTITION p202306 VALUES LESS THAN ('2023-07-01') ENGINE = InnoDB,
 PARTITION p202307 VALUES LESS THAN ('2023-08-01') ENGINE = InnoDB,
 PARTITION p202308 VALUES LESS THAN ('2023-09-01') ENGINE = InnoDB,
 PARTITION p202309 VALUES LESS THAN ('2023-10-01') ENGINE = InnoDB,
 PARTITION p202310 VALUES LESS THAN ('2023-11-01') ENGINE = InnoDB,
 PARTITION p202311 VALUES LESS THAN ('2023-12-01') ENGINE = InnoDB,
 PARTITION p202312 VALUES LESS THAN ('2024-01-01') ENGINE = InnoDB,
 PARTITION p202401 VALUES LESS THAN ('2024-02-01') ENGINE = InnoDB,
 PARTITION p202402 VALUES LESS THAN ('2024-03-01') ENGINE = InnoDB,
 PARTITION p202403 VALUES LESS THAN ('2024-04-01') ENGINE = InnoDB,
 PARTITION p202404 VALUES LESS THAN ('2024-05-01') ENGINE = InnoDB,
 PARTITION p202405 VALUES LESS THAN ('2024-06-01') ENGINE = InnoDB,
 PARTITION p202406 VALUES LESS THAN ('2024-07-01') ENGINE = InnoDB,
 PARTITION p202407 VALUES LESS THAN ('2024-08-01') ENGINE = InnoDB,
 PARTITION p202408 VALUES LESS THAN ('2024-09-01') ENGINE = InnoDB,
 PARTITION p202409 VALUES LESS THAN ('2024-10-01') ENGINE = InnoDB,
 PARTITION p202410 VALUES LESS THAN ('2024-11-01') ENGINE = InnoDB,
 PARTITION p202411 VALUES LESS THAN ('2024-12-01') ENGINE = InnoDB,
 PARTITION p202412 VALUES LESS THAN ('2025-01-01') ENGINE = InnoDB,
 PARTITION p202501 VALUES LESS THAN ('2025-02-01') ENGINE = InnoDB,
 PARTITION p202502 VALUES LESS THAN ('2025-03-01') ENGINE = InnoDB,
 PARTITION p202503 VALUES LESS THAN ('2025-04-01') ENGINE = InnoDB,
 PARTITION p202504 VALUES LESS THAN ('2025-05-01') ENGINE = InnoDB,
 PARTITION p202505 VALUES LESS THAN ('2025-06-01') ENGINE = InnoDB,
 PARTITION p202506 VALUES LESS THAN ('2025-07-01') ENGINE = InnoDB,
 PARTITION p202507 VALUES LESS THAN ('2025-08-01') ENGINE = InnoDB,
 PARTITION p202508 VALUES LESS THAN ('2025-09-01') ENGINE = InnoDB,
 PARTITION p202509 VALUES LESS THAN ('2025-10-01') ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN ('2025-11-01') ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN ('2025-12-01') ENGINE = InnoDB,
 PARTITION p202512 VALUES LESS THAN ('2026-01-01') ENGINE = InnoDB,
 PARTITION p202601 VALUES LESS THAN ('2026-02-01') ENGINE = InnoDB,
 PARTITION p202602 VALUES LESS THAN ('2026-03-01') ENGINE = InnoDB,
 PARTITION p202603 VALUES LESS THAN ('2026-04-01') ENGINE = InnoDB,
 PARTITION p202604 VALUES LESS THAN ('2026-05-01') ENGINE = InnoDB,
 PARTITION p202605 VALUES LESS THAN ('2026-06-01') ENGINE = InnoDB,
 PARTITION p202606 VALUES LESS THAN ('2026-07-01') ENGINE = InnoDB,
 PARTITION p202607 VALUES LESS THAN ('2026-08-01') ENGINE = InnoDB,
 PARTITION p202608 VALUES LESS THAN ('2026-09-01') ENGINE = InnoDB,
 PARTITION p202609 VALUES LESS THAN ('2026-10-01') ENGINE = InnoDB,
 PARTITION p202610 VALUES LESS THAN ('2026-11-01') ENGINE = InnoDB,
 PARTITION p202611 VALUES LESS THAN ('2026-12-01') ENGINE = InnoDB,
 PARTITION p202612 VALUES LESS THAN ('2027-01-01') ENGINE = InnoDB,
 PARTITION p202701 VALUES LESS THAN ('2027-02-01') ENGINE = InnoDB,
 PARTITION p202702 VALUES LESS THAN ('2027-03-01') ENGINE = InnoDB,
 PARTITION p202703 VALUES LESS THAN ('2027-04-01') ENGINE = InnoDB,
 PARTITION p202704 VALUES LESS THAN ('2027-05-01') ENGINE = InnoDB,
 PARTITION p202705 VALUES LESS THAN ('2027-06-01') ENGINE = InnoDB,
 PARTITION p202706 VALUES LESS THAN ('2027-07-01') ENGINE = InnoDB,
 PARTITION p202707 VALUES LESS THAN ('2027-08-01') ENGINE = InnoDB,
 PARTITION p202708 VALUES LESS THAN ('2027-09-01') ENGINE = InnoDB,
 PARTITION p202709 VALUES LESS THAN ('2027-10-01') ENGINE = InnoDB,
 PARTITION p202710 VALUES LESS THAN ('2027-11-01') ENGINE = InnoDB,
 PARTITION p202711 VALUES LESS THAN ('2027-12-01') ENGINE = InnoDB,
 PARTITION p202712 VALUES LESS THAN ('2028-01-01') ENGINE = InnoDB,
 PARTITION p202801 VALUES LESS THAN ('2028-02-01') ENGINE = InnoDB,
 PARTITION p202802 VALUES LESS THAN ('2028-03-01') ENGINE = InnoDB,
 PARTITION p202803 VALUES LESS THAN ('2028-04-01') ENGINE = InnoDB,
 PARTITION p202804 VALUES LESS THAN ('2028-05-01') ENGINE = InnoDB,
 PARTITION p202805 VALUES LESS THAN ('2028-06-01') ENGINE = InnoDB,
 PARTITION p202806 VALUES LESS THAN ('2028-07-01') ENGINE = InnoDB,
 PARTITION p202807 VALUES LESS THAN ('2028-08-01') ENGINE = InnoDB,
 PARTITION p202808 VALUES LESS THAN ('2028-09-01') ENGINE = InnoDB,
 PARTITION p202809 VALUES LESS THAN ('2028-10-01') ENGINE = InnoDB,
 PARTITION p202810 VALUES LESS THAN ('2028-11-01') ENGINE = InnoDB,
 PARTITION p202811 VALUES LESS THAN ('2028-12-01') ENGINE = InnoDB,
 PARTITION p202812 VALUES LESS THAN ('2029-01-01') ENGINE = InnoDB,
 PARTITION p202901 VALUES LESS THAN ('2029-02-01') ENGINE = InnoDB,
 PARTITION p202902 VALUES LESS THAN ('2029-03-01') ENGINE = InnoDB,
 PARTITION p202903 VALUES LESS THAN ('2029-04-01') ENGINE = InnoDB,
 PARTITION p202904 VALUES LESS THAN ('2029-05-01') ENGINE = InnoDB,
 PARTITION p202905 VALUES LESS THAN ('2029-06-01') ENGINE = InnoDB,
 PARTITION p202906 VALUES LESS THAN ('2029-07-01') ENGINE = InnoDB,
 PARTITION p202907 VALUES LESS THAN ('2029-08-01') ENGINE = InnoDB,
 PARTITION p202908 VALUES LESS THAN ('2029-09-01') ENGINE = InnoDB,
 PARTITION p202909 VALUES LESS THAN ('2029-10-01') ENGINE = InnoDB,
 PARTITION p202910 VALUES LESS THAN ('2029-11-01') ENGINE = InnoDB,
 PARTITION p202911 VALUES LESS THAN ('2029-12-01') ENGINE = InnoDB,
 PARTITION p202912 VALUES LESS THAN ('2030-01-01') ENGINE = InnoDB,
 PARTITION p203001 VALUES LESS THAN ('2030-02-01') ENGINE = InnoDB,
 PARTITION p203002 VALUES LESS THAN ('2030-03-01') ENGINE = InnoDB,
 PARTITION p203003 VALUES LESS THAN ('2030-04-01') ENGINE = InnoDB,
 PARTITION p203004 VALUES LESS THAN ('2030-05-01') ENGINE = InnoDB,
 PARTITION p203005 VALUES LESS THAN ('2030-06-01') ENGINE = InnoDB,
 PARTITION p203006 VALUES LESS THAN ('2030-07-01') ENGINE = InnoDB,
 PARTITION p203007 VALUES LESS THAN ('2030-08-01') ENGINE = InnoDB,
 PARTITION p203008 VALUES LESS THAN ('2030-09-01') ENGINE = InnoDB,
 PARTITION p203009 VALUES LESS THAN ('2030-10-01') ENGINE = InnoDB,
 PARTITION p203010 VALUES LESS THAN ('2030-11-01') ENGINE = InnoDB,
 PARTITION p203011 VALUES LESS THAN ('2030-12-01') ENGINE = InnoDB,
 PARTITION p203012 VALUES LESS THAN ('2031-01-01') ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_diary_likes`
--

DROP TABLE IF EXISTS `log_diary_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_diary_likes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '日記いいねログ',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `content_id` int(11) unsigned NOT NULL COMMENT '日記内容ID',
  `content_spid` bigint(20) NOT NULL COMMENT '内容SPID',
  `like_at` datetime NOT NULL COMMENT 'いいね日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`,`created_at`),
  KEY `idx_log_diary_likes_1` (`spid`),
  KEY `idx_log_diary_likes_2` (`content_id`),
  KEY `idx_log_diary_likes_3` (`content_spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='日記いいねログ'
/*!50500 PARTITION BY RANGE  COLUMNS(created_at)
(PARTITION p201512 VALUES LESS THAN ('2016-01-01') ENGINE = InnoDB,
 PARTITION p201601 VALUES LESS THAN ('2016-02-01') ENGINE = InnoDB,
 PARTITION p201602 VALUES LESS THAN ('2016-03-01') ENGINE = InnoDB,
 PARTITION p201603 VALUES LESS THAN ('2016-04-01') ENGINE = InnoDB,
 PARTITION p201604 VALUES LESS THAN ('2016-05-01') ENGINE = InnoDB,
 PARTITION p201605 VALUES LESS THAN ('2016-06-01') ENGINE = InnoDB,
 PARTITION p201606 VALUES LESS THAN ('2016-07-01') ENGINE = InnoDB,
 PARTITION p201607 VALUES LESS THAN ('2016-08-01') ENGINE = InnoDB,
 PARTITION p201608 VALUES LESS THAN ('2016-09-01') ENGINE = InnoDB,
 PARTITION p201609 VALUES LESS THAN ('2016-10-01') ENGINE = InnoDB,
 PARTITION p201610 VALUES LESS THAN ('2016-11-01') ENGINE = InnoDB,
 PARTITION p201611 VALUES LESS THAN ('2016-12-01') ENGINE = InnoDB,
 PARTITION p201612 VALUES LESS THAN ('2017-01-01') ENGINE = InnoDB,
 PARTITION p201701 VALUES LESS THAN ('2017-02-01') ENGINE = InnoDB,
 PARTITION p201702 VALUES LESS THAN ('2017-03-01') ENGINE = InnoDB,
 PARTITION p201703 VALUES LESS THAN ('2017-04-01') ENGINE = InnoDB,
 PARTITION p201704 VALUES LESS THAN ('2017-05-01') ENGINE = InnoDB,
 PARTITION p201705 VALUES LESS THAN ('2017-06-01') ENGINE = InnoDB,
 PARTITION p201706 VALUES LESS THAN ('2017-07-01') ENGINE = InnoDB,
 PARTITION p201707 VALUES LESS THAN ('2017-08-01') ENGINE = InnoDB,
 PARTITION p201708 VALUES LESS THAN ('2017-09-01') ENGINE = InnoDB,
 PARTITION p201709 VALUES LESS THAN ('2017-10-01') ENGINE = InnoDB,
 PARTITION p201710 VALUES LESS THAN ('2017-11-01') ENGINE = InnoDB,
 PARTITION p201711 VALUES LESS THAN ('2017-12-01') ENGINE = InnoDB,
 PARTITION p201712 VALUES LESS THAN ('2018-01-01') ENGINE = InnoDB,
 PARTITION p201801 VALUES LESS THAN ('2018-02-01') ENGINE = InnoDB,
 PARTITION p201802 VALUES LESS THAN ('2018-03-01') ENGINE = InnoDB,
 PARTITION p201803 VALUES LESS THAN ('2018-04-01') ENGINE = InnoDB,
 PARTITION p201804 VALUES LESS THAN ('2018-05-01') ENGINE = InnoDB,
 PARTITION p201805 VALUES LESS THAN ('2018-06-01') ENGINE = InnoDB,
 PARTITION p201806 VALUES LESS THAN ('2018-07-01') ENGINE = InnoDB,
 PARTITION p201807 VALUES LESS THAN ('2018-08-01') ENGINE = InnoDB,
 PARTITION p201808 VALUES LESS THAN ('2018-09-01') ENGINE = InnoDB,
 PARTITION p201809 VALUES LESS THAN ('2018-10-01') ENGINE = InnoDB,
 PARTITION p201810 VALUES LESS THAN ('2018-11-01') ENGINE = InnoDB,
 PARTITION p201811 VALUES LESS THAN ('2018-12-01') ENGINE = InnoDB,
 PARTITION p201812 VALUES LESS THAN ('2019-01-01') ENGINE = InnoDB,
 PARTITION p201901 VALUES LESS THAN ('2019-02-01') ENGINE = InnoDB,
 PARTITION p201902 VALUES LESS THAN ('2019-03-01') ENGINE = InnoDB,
 PARTITION p201903 VALUES LESS THAN ('2019-04-01') ENGINE = InnoDB,
 PARTITION p201904 VALUES LESS THAN ('2019-05-01') ENGINE = InnoDB,
 PARTITION p201905 VALUES LESS THAN ('2019-06-01') ENGINE = InnoDB,
 PARTITION p201906 VALUES LESS THAN ('2019-07-01') ENGINE = InnoDB,
 PARTITION p201907 VALUES LESS THAN ('2019-08-01') ENGINE = InnoDB,
 PARTITION p201908 VALUES LESS THAN ('2019-09-01') ENGINE = InnoDB,
 PARTITION p201909 VALUES LESS THAN ('2019-10-01') ENGINE = InnoDB,
 PARTITION p201910 VALUES LESS THAN ('2019-11-01') ENGINE = InnoDB,
 PARTITION p201911 VALUES LESS THAN ('2019-12-01') ENGINE = InnoDB,
 PARTITION p201912 VALUES LESS THAN ('2020-01-01') ENGINE = InnoDB,
 PARTITION p202001 VALUES LESS THAN ('2020-02-01') ENGINE = InnoDB,
 PARTITION p202002 VALUES LESS THAN ('2020-03-01') ENGINE = InnoDB,
 PARTITION p202003 VALUES LESS THAN ('2020-04-01') ENGINE = InnoDB,
 PARTITION p202004 VALUES LESS THAN ('2020-05-01') ENGINE = InnoDB,
 PARTITION p202005 VALUES LESS THAN ('2020-06-01') ENGINE = InnoDB,
 PARTITION p202006 VALUES LESS THAN ('2020-07-01') ENGINE = InnoDB,
 PARTITION p202007 VALUES LESS THAN ('2020-08-01') ENGINE = InnoDB,
 PARTITION p202008 VALUES LESS THAN ('2020-09-01') ENGINE = InnoDB,
 PARTITION p202009 VALUES LESS THAN ('2020-10-01') ENGINE = InnoDB,
 PARTITION p202010 VALUES LESS THAN ('2020-11-01') ENGINE = InnoDB,
 PARTITION p202011 VALUES LESS THAN ('2020-12-01') ENGINE = InnoDB,
 PARTITION p202012 VALUES LESS THAN ('2021-01-01') ENGINE = InnoDB,
 PARTITION p202101 VALUES LESS THAN ('2021-02-01') ENGINE = InnoDB,
 PARTITION p202102 VALUES LESS THAN ('2021-03-01') ENGINE = InnoDB,
 PARTITION p202103 VALUES LESS THAN ('2021-04-01') ENGINE = InnoDB,
 PARTITION p202104 VALUES LESS THAN ('2021-05-01') ENGINE = InnoDB,
 PARTITION p202105 VALUES LESS THAN ('2021-06-01') ENGINE = InnoDB,
 PARTITION p202106 VALUES LESS THAN ('2021-07-01') ENGINE = InnoDB,
 PARTITION p202107 VALUES LESS THAN ('2021-08-01') ENGINE = InnoDB,
 PARTITION p202108 VALUES LESS THAN ('2021-09-01') ENGINE = InnoDB,
 PARTITION p202109 VALUES LESS THAN ('2021-10-01') ENGINE = InnoDB,
 PARTITION p202110 VALUES LESS THAN ('2021-11-01') ENGINE = InnoDB,
 PARTITION p202111 VALUES LESS THAN ('2021-12-01') ENGINE = InnoDB,
 PARTITION p202112 VALUES LESS THAN ('2022-01-01') ENGINE = InnoDB,
 PARTITION p202201 VALUES LESS THAN ('2022-02-01') ENGINE = InnoDB,
 PARTITION p202202 VALUES LESS THAN ('2022-03-01') ENGINE = InnoDB,
 PARTITION p202203 VALUES LESS THAN ('2022-04-01') ENGINE = InnoDB,
 PARTITION p202204 VALUES LESS THAN ('2022-05-01') ENGINE = InnoDB,
 PARTITION p202205 VALUES LESS THAN ('2022-06-01') ENGINE = InnoDB,
 PARTITION p202206 VALUES LESS THAN ('2022-07-01') ENGINE = InnoDB,
 PARTITION p202207 VALUES LESS THAN ('2022-08-01') ENGINE = InnoDB,
 PARTITION p202208 VALUES LESS THAN ('2022-09-01') ENGINE = InnoDB,
 PARTITION p202209 VALUES LESS THAN ('2022-10-01') ENGINE = InnoDB,
 PARTITION p202210 VALUES LESS THAN ('2022-11-01') ENGINE = InnoDB,
 PARTITION p202211 VALUES LESS THAN ('2022-12-01') ENGINE = InnoDB,
 PARTITION p202212 VALUES LESS THAN ('2023-01-01') ENGINE = InnoDB,
 PARTITION p202301 VALUES LESS THAN ('2023-02-01') ENGINE = InnoDB,
 PARTITION p202302 VALUES LESS THAN ('2023-03-01') ENGINE = InnoDB,
 PARTITION p202303 VALUES LESS THAN ('2023-04-01') ENGINE = InnoDB,
 PARTITION p202304 VALUES LESS THAN ('2023-05-01') ENGINE = InnoDB,
 PARTITION p202305 VALUES LESS THAN ('2023-06-01') ENGINE = InnoDB,
 PARTITION p202306 VALUES LESS THAN ('2023-07-01') ENGINE = InnoDB,
 PARTITION p202307 VALUES LESS THAN ('2023-08-01') ENGINE = InnoDB,
 PARTITION p202308 VALUES LESS THAN ('2023-09-01') ENGINE = InnoDB,
 PARTITION p202309 VALUES LESS THAN ('2023-10-01') ENGINE = InnoDB,
 PARTITION p202310 VALUES LESS THAN ('2023-11-01') ENGINE = InnoDB,
 PARTITION p202311 VALUES LESS THAN ('2023-12-01') ENGINE = InnoDB,
 PARTITION p202312 VALUES LESS THAN ('2024-01-01') ENGINE = InnoDB,
 PARTITION p202401 VALUES LESS THAN ('2024-02-01') ENGINE = InnoDB,
 PARTITION p202402 VALUES LESS THAN ('2024-03-01') ENGINE = InnoDB,
 PARTITION p202403 VALUES LESS THAN ('2024-04-01') ENGINE = InnoDB,
 PARTITION p202404 VALUES LESS THAN ('2024-05-01') ENGINE = InnoDB,
 PARTITION p202405 VALUES LESS THAN ('2024-06-01') ENGINE = InnoDB,
 PARTITION p202406 VALUES LESS THAN ('2024-07-01') ENGINE = InnoDB,
 PARTITION p202407 VALUES LESS THAN ('2024-08-01') ENGINE = InnoDB,
 PARTITION p202408 VALUES LESS THAN ('2024-09-01') ENGINE = InnoDB,
 PARTITION p202409 VALUES LESS THAN ('2024-10-01') ENGINE = InnoDB,
 PARTITION p202410 VALUES LESS THAN ('2024-11-01') ENGINE = InnoDB,
 PARTITION p202411 VALUES LESS THAN ('2024-12-01') ENGINE = InnoDB,
 PARTITION p202412 VALUES LESS THAN ('2025-01-01') ENGINE = InnoDB,
 PARTITION p202501 VALUES LESS THAN ('2025-02-01') ENGINE = InnoDB,
 PARTITION p202502 VALUES LESS THAN ('2025-03-01') ENGINE = InnoDB,
 PARTITION p202503 VALUES LESS THAN ('2025-04-01') ENGINE = InnoDB,
 PARTITION p202504 VALUES LESS THAN ('2025-05-01') ENGINE = InnoDB,
 PARTITION p202505 VALUES LESS THAN ('2025-06-01') ENGINE = InnoDB,
 PARTITION p202506 VALUES LESS THAN ('2025-07-01') ENGINE = InnoDB,
 PARTITION p202507 VALUES LESS THAN ('2025-08-01') ENGINE = InnoDB,
 PARTITION p202508 VALUES LESS THAN ('2025-09-01') ENGINE = InnoDB,
 PARTITION p202509 VALUES LESS THAN ('2025-10-01') ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN ('2025-11-01') ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN ('2025-12-01') ENGINE = InnoDB,
 PARTITION p202512 VALUES LESS THAN ('2026-01-01') ENGINE = InnoDB,
 PARTITION p202601 VALUES LESS THAN ('2026-02-01') ENGINE = InnoDB,
 PARTITION p202602 VALUES LESS THAN ('2026-03-01') ENGINE = InnoDB,
 PARTITION p202603 VALUES LESS THAN ('2026-04-01') ENGINE = InnoDB,
 PARTITION p202604 VALUES LESS THAN ('2026-05-01') ENGINE = InnoDB,
 PARTITION p202605 VALUES LESS THAN ('2026-06-01') ENGINE = InnoDB,
 PARTITION p202606 VALUES LESS THAN ('2026-07-01') ENGINE = InnoDB,
 PARTITION p202607 VALUES LESS THAN ('2026-08-01') ENGINE = InnoDB,
 PARTITION p202608 VALUES LESS THAN ('2026-09-01') ENGINE = InnoDB,
 PARTITION p202609 VALUES LESS THAN ('2026-10-01') ENGINE = InnoDB,
 PARTITION p202610 VALUES LESS THAN ('2026-11-01') ENGINE = InnoDB,
 PARTITION p202611 VALUES LESS THAN ('2026-12-01') ENGINE = InnoDB,
 PARTITION p202612 VALUES LESS THAN ('2027-01-01') ENGINE = InnoDB,
 PARTITION p202701 VALUES LESS THAN ('2027-02-01') ENGINE = InnoDB,
 PARTITION p202702 VALUES LESS THAN ('2027-03-01') ENGINE = InnoDB,
 PARTITION p202703 VALUES LESS THAN ('2027-04-01') ENGINE = InnoDB,
 PARTITION p202704 VALUES LESS THAN ('2027-05-01') ENGINE = InnoDB,
 PARTITION p202705 VALUES LESS THAN ('2027-06-01') ENGINE = InnoDB,
 PARTITION p202706 VALUES LESS THAN ('2027-07-01') ENGINE = InnoDB,
 PARTITION p202707 VALUES LESS THAN ('2027-08-01') ENGINE = InnoDB,
 PARTITION p202708 VALUES LESS THAN ('2027-09-01') ENGINE = InnoDB,
 PARTITION p202709 VALUES LESS THAN ('2027-10-01') ENGINE = InnoDB,
 PARTITION p202710 VALUES LESS THAN ('2027-11-01') ENGINE = InnoDB,
 PARTITION p202711 VALUES LESS THAN ('2027-12-01') ENGINE = InnoDB,
 PARTITION p202712 VALUES LESS THAN ('2028-01-01') ENGINE = InnoDB,
 PARTITION p202801 VALUES LESS THAN ('2028-02-01') ENGINE = InnoDB,
 PARTITION p202802 VALUES LESS THAN ('2028-03-01') ENGINE = InnoDB,
 PARTITION p202803 VALUES LESS THAN ('2028-04-01') ENGINE = InnoDB,
 PARTITION p202804 VALUES LESS THAN ('2028-05-01') ENGINE = InnoDB,
 PARTITION p202805 VALUES LESS THAN ('2028-06-01') ENGINE = InnoDB,
 PARTITION p202806 VALUES LESS THAN ('2028-07-01') ENGINE = InnoDB,
 PARTITION p202807 VALUES LESS THAN ('2028-08-01') ENGINE = InnoDB,
 PARTITION p202808 VALUES LESS THAN ('2028-09-01') ENGINE = InnoDB,
 PARTITION p202809 VALUES LESS THAN ('2028-10-01') ENGINE = InnoDB,
 PARTITION p202810 VALUES LESS THAN ('2028-11-01') ENGINE = InnoDB,
 PARTITION p202811 VALUES LESS THAN ('2028-12-01') ENGINE = InnoDB,
 PARTITION p202812 VALUES LESS THAN ('2029-01-01') ENGINE = InnoDB,
 PARTITION p202901 VALUES LESS THAN ('2029-02-01') ENGINE = InnoDB,
 PARTITION p202902 VALUES LESS THAN ('2029-03-01') ENGINE = InnoDB,
 PARTITION p202903 VALUES LESS THAN ('2029-04-01') ENGINE = InnoDB,
 PARTITION p202904 VALUES LESS THAN ('2029-05-01') ENGINE = InnoDB,
 PARTITION p202905 VALUES LESS THAN ('2029-06-01') ENGINE = InnoDB,
 PARTITION p202906 VALUES LESS THAN ('2029-07-01') ENGINE = InnoDB,
 PARTITION p202907 VALUES LESS THAN ('2029-08-01') ENGINE = InnoDB,
 PARTITION p202908 VALUES LESS THAN ('2029-09-01') ENGINE = InnoDB,
 PARTITION p202909 VALUES LESS THAN ('2029-10-01') ENGINE = InnoDB,
 PARTITION p202910 VALUES LESS THAN ('2029-11-01') ENGINE = InnoDB,
 PARTITION p202911 VALUES LESS THAN ('2029-12-01') ENGINE = InnoDB,
 PARTITION p202912 VALUES LESS THAN ('2030-01-01') ENGINE = InnoDB,
 PARTITION p203001 VALUES LESS THAN ('2030-02-01') ENGINE = InnoDB,
 PARTITION p203002 VALUES LESS THAN ('2030-03-01') ENGINE = InnoDB,
 PARTITION p203003 VALUES LESS THAN ('2030-04-01') ENGINE = InnoDB,
 PARTITION p203004 VALUES LESS THAN ('2030-05-01') ENGINE = InnoDB,
 PARTITION p203005 VALUES LESS THAN ('2030-06-01') ENGINE = InnoDB,
 PARTITION p203006 VALUES LESS THAN ('2030-07-01') ENGINE = InnoDB,
 PARTITION p203007 VALUES LESS THAN ('2030-08-01') ENGINE = InnoDB,
 PARTITION p203008 VALUES LESS THAN ('2030-09-01') ENGINE = InnoDB,
 PARTITION p203009 VALUES LESS THAN ('2030-10-01') ENGINE = InnoDB,
 PARTITION p203010 VALUES LESS THAN ('2030-11-01') ENGINE = InnoDB,
 PARTITION p203011 VALUES LESS THAN ('2030-12-01') ENGINE = InnoDB,
 PARTITION p203012 VALUES LESS THAN ('2031-01-01') ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_event_points`
--

DROP TABLE IF EXISTS `log_event_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_event_points` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'イベントポイント所持情報ID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `num` int(11) NOT NULL COMMENT '所持ポイント数',
  `org_num` int(11) NOT NULL COMMENT 'もともとの所持ポイント数',
  `add_num` int(11) DEFAULT '0' COMMENT 'ベース追加数',
  `boost_add_num` int(11) DEFAULT '0' COMMENT 'ブースト後の追加数',
  `boost_rate` int(11) NOT NULL DEFAULT '0' COMMENT '補正値',
  `lock_version` int(11) NOT NULL DEFAULT '0' COMMENT 'バージョン番号',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_log_event_points_1` (`spid`,`id`),
  KEY `idx_log_event_points_2` (`point_id`,`id`),
  KEY `idx_log_event_points_3` (`point_id`,`created_at`),
  KEY `idx_log_event_points_4` (`spid`,`point_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベントポイント所持情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_event_ranking_baks`
--

DROP TABLE IF EXISTS `log_event_ranking_baks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_event_ranking_baks` (
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `ranking_date` datetime NOT NULL COMMENT 'ランキング日時',
  `ranking` int(11) NOT NULL COMMENT '順位',
  `count_value` int(11) NOT NULL COMMENT 'カウント値',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  KEY `idx_log_event_rankings_1` (`event_id`,`ranking_date`,`ranking`),
  KEY `idx_log_event_rankings_2` (`event_id`,`ranking_date`,`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーイベントランキング';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_event_rankings`
--

DROP TABLE IF EXISTS `log_event_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_event_rankings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `ranking_date` datetime NOT NULL COMMENT 'ランキング日時',
  `ranking` int(11) NOT NULL COMMENT '順位',
  `count_value` int(11) NOT NULL COMMENT 'カウント値',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`,`created_at`),
  KEY `idx_log_event_rankings_1` (`event_id`,`ranking_date`,`ranking`),
  KEY `idx_log_event_rankings_2` (`event_id`,`ranking_date`,`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='プレイヤーイベントランキング'
/*!50500 PARTITION BY RANGE  COLUMNS(created_at)
(PARTITION p201610 VALUES LESS THAN ('2016-11-01') ENGINE = InnoDB,
 PARTITION p201611 VALUES LESS THAN ('2016-12-01') ENGINE = InnoDB,
 PARTITION p201612 VALUES LESS THAN ('2017-01-01') ENGINE = InnoDB,
 PARTITION p201701 VALUES LESS THAN ('2017-02-01') ENGINE = InnoDB,
 PARTITION p201702 VALUES LESS THAN ('2017-03-01') ENGINE = InnoDB,
 PARTITION p201703 VALUES LESS THAN ('2017-04-01') ENGINE = InnoDB,
 PARTITION p201704 VALUES LESS THAN ('2017-05-01') ENGINE = InnoDB,
 PARTITION p201705 VALUES LESS THAN ('2017-06-01') ENGINE = InnoDB,
 PARTITION p201706 VALUES LESS THAN ('2017-07-01') ENGINE = InnoDB,
 PARTITION p201707 VALUES LESS THAN ('2017-08-01') ENGINE = InnoDB,
 PARTITION p201708 VALUES LESS THAN ('2017-09-01') ENGINE = InnoDB,
 PARTITION p201709 VALUES LESS THAN ('2017-10-01') ENGINE = InnoDB,
 PARTITION p201710 VALUES LESS THAN ('2017-11-01') ENGINE = InnoDB,
 PARTITION p201711 VALUES LESS THAN ('2017-12-01') ENGINE = InnoDB,
 PARTITION p201712 VALUES LESS THAN ('2018-01-01') ENGINE = InnoDB,
 PARTITION p201801 VALUES LESS THAN ('2018-02-01') ENGINE = InnoDB,
 PARTITION p201802 VALUES LESS THAN ('2018-03-01') ENGINE = InnoDB,
 PARTITION p201803 VALUES LESS THAN ('2018-04-01') ENGINE = InnoDB,
 PARTITION p201804 VALUES LESS THAN ('2018-05-01') ENGINE = InnoDB,
 PARTITION p201805 VALUES LESS THAN ('2018-06-01') ENGINE = InnoDB,
 PARTITION p201806 VALUES LESS THAN ('2018-07-01') ENGINE = InnoDB,
 PARTITION p201807 VALUES LESS THAN ('2018-08-01') ENGINE = InnoDB,
 PARTITION p201808 VALUES LESS THAN ('2018-09-01') ENGINE = InnoDB,
 PARTITION p201809 VALUES LESS THAN ('2018-10-01') ENGINE = InnoDB,
 PARTITION p201810 VALUES LESS THAN ('2018-11-01') ENGINE = InnoDB,
 PARTITION p201811 VALUES LESS THAN ('2018-12-01') ENGINE = InnoDB,
 PARTITION p201812 VALUES LESS THAN ('2019-01-01') ENGINE = InnoDB,
 PARTITION p201901 VALUES LESS THAN ('2019-02-01') ENGINE = InnoDB,
 PARTITION p201902 VALUES LESS THAN ('2019-03-01') ENGINE = InnoDB,
 PARTITION p201903 VALUES LESS THAN ('2019-04-01') ENGINE = InnoDB,
 PARTITION p201904 VALUES LESS THAN ('2019-05-01') ENGINE = InnoDB,
 PARTITION p201905 VALUES LESS THAN ('2019-06-01') ENGINE = InnoDB,
 PARTITION p201906 VALUES LESS THAN ('2019-07-01') ENGINE = InnoDB,
 PARTITION p201907 VALUES LESS THAN ('2019-08-01') ENGINE = InnoDB,
 PARTITION p201908 VALUES LESS THAN ('2019-09-01') ENGINE = InnoDB,
 PARTITION p201909 VALUES LESS THAN ('2019-10-01') ENGINE = InnoDB,
 PARTITION p201910 VALUES LESS THAN ('2019-11-01') ENGINE = InnoDB,
 PARTITION p201911 VALUES LESS THAN ('2019-12-01') ENGINE = InnoDB,
 PARTITION p201912 VALUES LESS THAN ('2020-01-01') ENGINE = InnoDB,
 PARTITION p202001 VALUES LESS THAN ('2020-02-01') ENGINE = InnoDB,
 PARTITION p202002 VALUES LESS THAN ('2020-03-01') ENGINE = InnoDB,
 PARTITION p202003 VALUES LESS THAN ('2020-04-01') ENGINE = InnoDB,
 PARTITION p202004 VALUES LESS THAN ('2020-05-01') ENGINE = InnoDB,
 PARTITION p202005 VALUES LESS THAN ('2020-06-01') ENGINE = InnoDB,
 PARTITION p202006 VALUES LESS THAN ('2020-07-01') ENGINE = InnoDB,
 PARTITION p202007 VALUES LESS THAN ('2020-08-01') ENGINE = InnoDB,
 PARTITION p202008 VALUES LESS THAN ('2020-09-01') ENGINE = InnoDB,
 PARTITION p202009 VALUES LESS THAN ('2020-10-01') ENGINE = InnoDB,
 PARTITION p202010 VALUES LESS THAN ('2020-11-01') ENGINE = InnoDB,
 PARTITION p202011 VALUES LESS THAN ('2020-12-01') ENGINE = InnoDB,
 PARTITION p202012 VALUES LESS THAN ('2021-01-01') ENGINE = InnoDB,
 PARTITION p202101 VALUES LESS THAN ('2021-02-01') ENGINE = InnoDB,
 PARTITION p202102 VALUES LESS THAN ('2021-03-01') ENGINE = InnoDB,
 PARTITION p202103 VALUES LESS THAN ('2021-04-01') ENGINE = InnoDB,
 PARTITION p202104 VALUES LESS THAN ('2021-05-01') ENGINE = InnoDB,
 PARTITION p202105 VALUES LESS THAN ('2021-06-01') ENGINE = InnoDB,
 PARTITION p202106 VALUES LESS THAN ('2021-07-01') ENGINE = InnoDB,
 PARTITION p202107 VALUES LESS THAN ('2021-08-01') ENGINE = InnoDB,
 PARTITION p202108 VALUES LESS THAN ('2021-09-01') ENGINE = InnoDB,
 PARTITION p202109 VALUES LESS THAN ('2021-10-01') ENGINE = InnoDB,
 PARTITION p202110 VALUES LESS THAN ('2021-11-01') ENGINE = InnoDB,
 PARTITION p202111 VALUES LESS THAN ('2021-12-01') ENGINE = InnoDB,
 PARTITION p202112 VALUES LESS THAN ('2022-01-01') ENGINE = InnoDB,
 PARTITION p202201 VALUES LESS THAN ('2022-02-01') ENGINE = InnoDB,
 PARTITION p202202 VALUES LESS THAN ('2022-03-01') ENGINE = InnoDB,
 PARTITION p202203 VALUES LESS THAN ('2022-04-01') ENGINE = InnoDB,
 PARTITION p202204 VALUES LESS THAN ('2022-05-01') ENGINE = InnoDB,
 PARTITION p202205 VALUES LESS THAN ('2022-06-01') ENGINE = InnoDB,
 PARTITION p202206 VALUES LESS THAN ('2022-07-01') ENGINE = InnoDB,
 PARTITION p202207 VALUES LESS THAN ('2022-08-01') ENGINE = InnoDB,
 PARTITION p202208 VALUES LESS THAN ('2022-09-01') ENGINE = InnoDB,
 PARTITION p202209 VALUES LESS THAN ('2022-10-01') ENGINE = InnoDB,
 PARTITION p202210 VALUES LESS THAN ('2022-11-01') ENGINE = InnoDB,
 PARTITION p202211 VALUES LESS THAN ('2022-12-01') ENGINE = InnoDB,
 PARTITION p202212 VALUES LESS THAN ('2023-01-01') ENGINE = InnoDB,
 PARTITION p202301 VALUES LESS THAN ('2023-02-01') ENGINE = InnoDB,
 PARTITION p202302 VALUES LESS THAN ('2023-03-01') ENGINE = InnoDB,
 PARTITION p202303 VALUES LESS THAN ('2023-04-01') ENGINE = InnoDB,
 PARTITION p202304 VALUES LESS THAN ('2023-05-01') ENGINE = InnoDB,
 PARTITION p202305 VALUES LESS THAN ('2023-06-01') ENGINE = InnoDB,
 PARTITION p202306 VALUES LESS THAN ('2023-07-01') ENGINE = InnoDB,
 PARTITION p202307 VALUES LESS THAN ('2023-08-01') ENGINE = InnoDB,
 PARTITION p202308 VALUES LESS THAN ('2023-09-01') ENGINE = InnoDB,
 PARTITION p202309 VALUES LESS THAN ('2023-10-01') ENGINE = InnoDB,
 PARTITION p202310 VALUES LESS THAN ('2023-11-01') ENGINE = InnoDB,
 PARTITION p202311 VALUES LESS THAN ('2023-12-01') ENGINE = InnoDB,
 PARTITION p202312 VALUES LESS THAN ('2024-01-01') ENGINE = InnoDB,
 PARTITION p202401 VALUES LESS THAN ('2024-02-01') ENGINE = InnoDB,
 PARTITION p202402 VALUES LESS THAN ('2024-03-01') ENGINE = InnoDB,
 PARTITION p202403 VALUES LESS THAN ('2024-04-01') ENGINE = InnoDB,
 PARTITION p202404 VALUES LESS THAN ('2024-05-01') ENGINE = InnoDB,
 PARTITION p202405 VALUES LESS THAN ('2024-06-01') ENGINE = InnoDB,
 PARTITION p202406 VALUES LESS THAN ('2024-07-01') ENGINE = InnoDB,
 PARTITION p202407 VALUES LESS THAN ('2024-08-01') ENGINE = InnoDB,
 PARTITION p202408 VALUES LESS THAN ('2024-09-01') ENGINE = InnoDB,
 PARTITION p202409 VALUES LESS THAN ('2024-10-01') ENGINE = InnoDB,
 PARTITION p202410 VALUES LESS THAN ('2024-11-01') ENGINE = InnoDB,
 PARTITION p202411 VALUES LESS THAN ('2024-12-01') ENGINE = InnoDB,
 PARTITION p202412 VALUES LESS THAN ('2025-01-01') ENGINE = InnoDB,
 PARTITION p202501 VALUES LESS THAN ('2025-02-01') ENGINE = InnoDB,
 PARTITION p202502 VALUES LESS THAN ('2025-03-01') ENGINE = InnoDB,
 PARTITION p202503 VALUES LESS THAN ('2025-04-01') ENGINE = InnoDB,
 PARTITION p202504 VALUES LESS THAN ('2025-05-01') ENGINE = InnoDB,
 PARTITION p202505 VALUES LESS THAN ('2025-06-01') ENGINE = InnoDB,
 PARTITION p202506 VALUES LESS THAN ('2025-07-01') ENGINE = InnoDB,
 PARTITION p202507 VALUES LESS THAN ('2025-08-01') ENGINE = InnoDB,
 PARTITION p202508 VALUES LESS THAN ('2025-09-01') ENGINE = InnoDB,
 PARTITION p202509 VALUES LESS THAN ('2025-10-01') ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN ('2025-11-01') ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN ('2025-12-01') ENGINE = InnoDB,
 PARTITION p202512 VALUES LESS THAN ('2026-01-01') ENGINE = InnoDB,
 PARTITION p202601 VALUES LESS THAN ('2026-02-01') ENGINE = InnoDB,
 PARTITION p202602 VALUES LESS THAN ('2026-03-01') ENGINE = InnoDB,
 PARTITION p202603 VALUES LESS THAN ('2026-04-01') ENGINE = InnoDB,
 PARTITION p202604 VALUES LESS THAN ('2026-05-01') ENGINE = InnoDB,
 PARTITION p202605 VALUES LESS THAN ('2026-06-01') ENGINE = InnoDB,
 PARTITION p202606 VALUES LESS THAN ('2026-07-01') ENGINE = InnoDB,
 PARTITION p202607 VALUES LESS THAN ('2026-08-01') ENGINE = InnoDB,
 PARTITION p202608 VALUES LESS THAN ('2026-09-01') ENGINE = InnoDB,
 PARTITION p202609 VALUES LESS THAN ('2026-10-01') ENGINE = InnoDB,
 PARTITION p202610 VALUES LESS THAN ('2026-11-01') ENGINE = InnoDB,
 PARTITION p202611 VALUES LESS THAN ('2026-12-01') ENGINE = InnoDB,
 PARTITION p202612 VALUES LESS THAN ('2027-01-01') ENGINE = InnoDB,
 PARTITION p202701 VALUES LESS THAN ('2027-02-01') ENGINE = InnoDB,
 PARTITION p202702 VALUES LESS THAN ('2027-03-01') ENGINE = InnoDB,
 PARTITION p202703 VALUES LESS THAN ('2027-04-01') ENGINE = InnoDB,
 PARTITION p202704 VALUES LESS THAN ('2027-05-01') ENGINE = InnoDB,
 PARTITION p202705 VALUES LESS THAN ('2027-06-01') ENGINE = InnoDB,
 PARTITION p202706 VALUES LESS THAN ('2027-07-01') ENGINE = InnoDB,
 PARTITION p202707 VALUES LESS THAN ('2027-08-01') ENGINE = InnoDB,
 PARTITION p202708 VALUES LESS THAN ('2027-09-01') ENGINE = InnoDB,
 PARTITION p202709 VALUES LESS THAN ('2027-10-01') ENGINE = InnoDB,
 PARTITION p202710 VALUES LESS THAN ('2027-11-01') ENGINE = InnoDB,
 PARTITION p202711 VALUES LESS THAN ('2027-12-01') ENGINE = InnoDB,
 PARTITION p202712 VALUES LESS THAN ('2028-01-01') ENGINE = InnoDB,
 PARTITION p202801 VALUES LESS THAN ('2028-02-01') ENGINE = InnoDB,
 PARTITION p202802 VALUES LESS THAN ('2028-03-01') ENGINE = InnoDB,
 PARTITION p202803 VALUES LESS THAN ('2028-04-01') ENGINE = InnoDB,
 PARTITION p202804 VALUES LESS THAN ('2028-05-01') ENGINE = InnoDB,
 PARTITION p202805 VALUES LESS THAN ('2028-06-01') ENGINE = InnoDB,
 PARTITION p202806 VALUES LESS THAN ('2028-07-01') ENGINE = InnoDB,
 PARTITION p202807 VALUES LESS THAN ('2028-08-01') ENGINE = InnoDB,
 PARTITION p202808 VALUES LESS THAN ('2028-09-01') ENGINE = InnoDB,
 PARTITION p202809 VALUES LESS THAN ('2028-10-01') ENGINE = InnoDB,
 PARTITION p202810 VALUES LESS THAN ('2028-11-01') ENGINE = InnoDB,
 PARTITION p202811 VALUES LESS THAN ('2028-12-01') ENGINE = InnoDB,
 PARTITION p202812 VALUES LESS THAN ('2029-01-01') ENGINE = InnoDB,
 PARTITION p202901 VALUES LESS THAN ('2029-02-01') ENGINE = InnoDB,
 PARTITION p202902 VALUES LESS THAN ('2029-03-01') ENGINE = InnoDB,
 PARTITION p202903 VALUES LESS THAN ('2029-04-01') ENGINE = InnoDB,
 PARTITION p202904 VALUES LESS THAN ('2029-05-01') ENGINE = InnoDB,
 PARTITION p202905 VALUES LESS THAN ('2029-06-01') ENGINE = InnoDB,
 PARTITION p202906 VALUES LESS THAN ('2029-07-01') ENGINE = InnoDB,
 PARTITION p202907 VALUES LESS THAN ('2029-08-01') ENGINE = InnoDB,
 PARTITION p202908 VALUES LESS THAN ('2029-09-01') ENGINE = InnoDB,
 PARTITION p202909 VALUES LESS THAN ('2029-10-01') ENGINE = InnoDB,
 PARTITION p202910 VALUES LESS THAN ('2029-11-01') ENGINE = InnoDB,
 PARTITION p202911 VALUES LESS THAN ('2029-12-01') ENGINE = InnoDB,
 PARTITION p202912 VALUES LESS THAN ('2030-01-01') ENGINE = InnoDB,
 PARTITION p203001 VALUES LESS THAN ('2030-02-01') ENGINE = InnoDB,
 PARTITION p203002 VALUES LESS THAN ('2030-03-01') ENGINE = InnoDB,
 PARTITION p203003 VALUES LESS THAN ('2030-04-01') ENGINE = InnoDB,
 PARTITION p203004 VALUES LESS THAN ('2030-05-01') ENGINE = InnoDB,
 PARTITION p203005 VALUES LESS THAN ('2030-06-01') ENGINE = InnoDB,
 PARTITION p203006 VALUES LESS THAN ('2030-07-01') ENGINE = InnoDB,
 PARTITION p203007 VALUES LESS THAN ('2030-08-01') ENGINE = InnoDB,
 PARTITION p203008 VALUES LESS THAN ('2030-09-01') ENGINE = InnoDB,
 PARTITION p203009 VALUES LESS THAN ('2030-10-01') ENGINE = InnoDB,
 PARTITION p203010 VALUES LESS THAN ('2030-11-01') ENGINE = InnoDB,
 PARTITION p203011 VALUES LESS THAN ('2030-12-01') ENGINE = InnoDB,
 PARTITION p203012 VALUES LESS THAN ('2031-01-01') ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_event_shop_useds`
--

DROP TABLE IF EXISTS `log_event_shop_useds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_event_shop_useds` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'イベントショップ使用履歴ID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_shop_id` int(11) NOT NULL COMMENT 'イベントショップID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_log_event_shop_useds_1` (`spid`,`id`),
  KEY `idx_log_event_shop_useds_2` (`event_shop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベントショップ使用履歴';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_event_useds`
--

DROP TABLE IF EXISTS `log_event_useds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_event_useds` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'イベントポイント使用履歴ID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `point_effect_id` int(11) NOT NULL COMMENT 'ポイント効果ID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_log_event_useds_1` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベントポイント使用履歴';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_item_inventories`
--

DROP TABLE IF EXISTS `log_item_inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_item_inventories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `item_id` int(11) NOT NULL,
  `num` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_log_item_inventories_1` (`spid`,`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_item_useds`
--

DROP TABLE IF EXISTS `log_item_useds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_item_useds` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'アイテム使用履歴',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `item_id` int(11) NOT NULL COMMENT 'アイテムID',
  `num` int(11) NOT NULL DEFAULT '0' COMMENT '使用個数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_log_item_useds_1` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='アイテム使用履歴';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_login_dailies`
--

DROP TABLE IF EXISTS `log_login_dailies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_login_dailies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_log_login_dailies_1` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_payments`
--

DROP TABLE IF EXISTS `log_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '購入履歴',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `shop_id` int(11) NOT NULL COMMENT 'ショップID',
  `item_id` int(11) NOT NULL COMMENT 'アイテムID',
  `amount` int(11) NOT NULL DEFAULT '0' COMMENT '購入数',
  `price` int(11) NOT NULL DEFAULT '0' COMMENT '購入金額',
  `target_id` int(11) NOT NULL COMMENT '対象ID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_log_payments_1` (`spid`),
  KEY `idx_log_payments_2` (`created_at`,`shop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='購入履歴';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_player_container_quality_rewards`
--

DROP TABLE IF EXISTS `log_player_container_quality_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_player_container_quality_rewards` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤー什器合成達成報酬ログ',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `rarity_id` int(11) NOT NULL COMMENT 'レアリティ',
  `quality` int(11) NOT NULL COMMENT '什器クオリティ',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`,`created_at`),
  KEY `idx_log_player_container_quality_rewards_1` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤー什器合成達成報酬ログ'
/*!50500 PARTITION BY RANGE  COLUMNS(created_at)
(PARTITION p201605 VALUES LESS THAN ('2016-06-01') ENGINE = InnoDB,
 PARTITION p201606 VALUES LESS THAN ('2016-07-01') ENGINE = InnoDB,
 PARTITION p201607 VALUES LESS THAN ('2016-08-01') ENGINE = InnoDB,
 PARTITION p201608 VALUES LESS THAN ('2016-09-01') ENGINE = InnoDB,
 PARTITION p201609 VALUES LESS THAN ('2016-10-01') ENGINE = InnoDB,
 PARTITION p201610 VALUES LESS THAN ('2016-11-01') ENGINE = InnoDB,
 PARTITION p201611 VALUES LESS THAN ('2016-12-01') ENGINE = InnoDB,
 PARTITION p201612 VALUES LESS THAN ('2017-01-01') ENGINE = InnoDB,
 PARTITION p201701 VALUES LESS THAN ('2017-02-01') ENGINE = InnoDB,
 PARTITION p201702 VALUES LESS THAN ('2017-03-01') ENGINE = InnoDB,
 PARTITION p201703 VALUES LESS THAN ('2017-04-01') ENGINE = InnoDB,
 PARTITION p201704 VALUES LESS THAN ('2017-05-01') ENGINE = InnoDB,
 PARTITION p201705 VALUES LESS THAN ('2017-06-01') ENGINE = InnoDB,
 PARTITION p201706 VALUES LESS THAN ('2017-07-01') ENGINE = InnoDB,
 PARTITION p201707 VALUES LESS THAN ('2017-08-01') ENGINE = InnoDB,
 PARTITION p201708 VALUES LESS THAN ('2017-09-01') ENGINE = InnoDB,
 PARTITION p201709 VALUES LESS THAN ('2017-10-01') ENGINE = InnoDB,
 PARTITION p201710 VALUES LESS THAN ('2017-11-01') ENGINE = InnoDB,
 PARTITION p201711 VALUES LESS THAN ('2017-12-01') ENGINE = InnoDB,
 PARTITION p201712 VALUES LESS THAN ('2018-01-01') ENGINE = InnoDB,
 PARTITION p201801 VALUES LESS THAN ('2018-02-01') ENGINE = InnoDB,
 PARTITION p201802 VALUES LESS THAN ('2018-03-01') ENGINE = InnoDB,
 PARTITION p201803 VALUES LESS THAN ('2018-04-01') ENGINE = InnoDB,
 PARTITION p201804 VALUES LESS THAN ('2018-05-01') ENGINE = InnoDB,
 PARTITION p201805 VALUES LESS THAN ('2018-06-01') ENGINE = InnoDB,
 PARTITION p201806 VALUES LESS THAN ('2018-07-01') ENGINE = InnoDB,
 PARTITION p201807 VALUES LESS THAN ('2018-08-01') ENGINE = InnoDB,
 PARTITION p201808 VALUES LESS THAN ('2018-09-01') ENGINE = InnoDB,
 PARTITION p201809 VALUES LESS THAN ('2018-10-01') ENGINE = InnoDB,
 PARTITION p201810 VALUES LESS THAN ('2018-11-01') ENGINE = InnoDB,
 PARTITION p201811 VALUES LESS THAN ('2018-12-01') ENGINE = InnoDB,
 PARTITION p201812 VALUES LESS THAN ('2019-01-01') ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_player_dispatches`
--

DROP TABLE IF EXISTS `log_player_dispatches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_player_dispatches` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '探索ログ',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `dispatch_id` int(11) NOT NULL COMMENT '派遣マスタID',
  `clerk_id` int(11) NOT NULL COMMENT '販売員マスタID',
  `success_num` int(11) NOT NULL COMMENT '成功回数',
  `failure_num` int(11) NOT NULL COMMENT '失敗回数',
  `is_fever` int(11) NOT NULL COMMENT 'フィーバー発生',
  `reward` text COMMENT '報酬内容',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`,`created_at`),
  KEY `idx_log_player_dispatches_1` (`spid`,`dispatch_id`,`clerk_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='探索ログ'
/*!50500 PARTITION BY RANGE  COLUMNS(created_at)
(PARTITION p201605 VALUES LESS THAN ('2016-06-01') ENGINE = InnoDB,
 PARTITION p201606 VALUES LESS THAN ('2016-07-01') ENGINE = InnoDB,
 PARTITION p201607 VALUES LESS THAN ('2016-08-01') ENGINE = InnoDB,
 PARTITION p201608 VALUES LESS THAN ('2016-09-01') ENGINE = InnoDB,
 PARTITION p201609 VALUES LESS THAN ('2016-10-01') ENGINE = InnoDB,
 PARTITION p201610 VALUES LESS THAN ('2016-11-01') ENGINE = InnoDB,
 PARTITION p201611 VALUES LESS THAN ('2016-12-01') ENGINE = InnoDB,
 PARTITION p201612 VALUES LESS THAN ('2017-01-01') ENGINE = InnoDB,
 PARTITION p201701 VALUES LESS THAN ('2017-02-01') ENGINE = InnoDB,
 PARTITION p201702 VALUES LESS THAN ('2017-03-01') ENGINE = InnoDB,
 PARTITION p201703 VALUES LESS THAN ('2017-04-01') ENGINE = InnoDB,
 PARTITION p201704 VALUES LESS THAN ('2017-05-01') ENGINE = InnoDB,
 PARTITION p201705 VALUES LESS THAN ('2017-06-01') ENGINE = InnoDB,
 PARTITION p201706 VALUES LESS THAN ('2017-07-01') ENGINE = InnoDB,
 PARTITION p201707 VALUES LESS THAN ('2017-08-01') ENGINE = InnoDB,
 PARTITION p201708 VALUES LESS THAN ('2017-09-01') ENGINE = InnoDB,
 PARTITION p201709 VALUES LESS THAN ('2017-10-01') ENGINE = InnoDB,
 PARTITION p201710 VALUES LESS THAN ('2017-11-01') ENGINE = InnoDB,
 PARTITION p201711 VALUES LESS THAN ('2017-12-01') ENGINE = InnoDB,
 PARTITION p201712 VALUES LESS THAN ('2018-01-01') ENGINE = InnoDB,
 PARTITION p201801 VALUES LESS THAN ('2018-02-01') ENGINE = InnoDB,
 PARTITION p201802 VALUES LESS THAN ('2018-03-01') ENGINE = InnoDB,
 PARTITION p201803 VALUES LESS THAN ('2018-04-01') ENGINE = InnoDB,
 PARTITION p201804 VALUES LESS THAN ('2018-05-01') ENGINE = InnoDB,
 PARTITION p201805 VALUES LESS THAN ('2018-06-01') ENGINE = InnoDB,
 PARTITION p201806 VALUES LESS THAN ('2018-07-01') ENGINE = InnoDB,
 PARTITION p201807 VALUES LESS THAN ('2018-08-01') ENGINE = InnoDB,
 PARTITION p201808 VALUES LESS THAN ('2018-09-01') ENGINE = InnoDB,
 PARTITION p201809 VALUES LESS THAN ('2018-10-01') ENGINE = InnoDB,
 PARTITION p201810 VALUES LESS THAN ('2018-11-01') ENGINE = InnoDB,
 PARTITION p201811 VALUES LESS THAN ('2018-12-01') ENGINE = InnoDB,
 PARTITION p201812 VALUES LESS THAN ('2019-01-01') ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_player_store_point_pools`
--

DROP TABLE IF EXISTS `log_player_store_point_pools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_player_store_point_pools` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ポイントプール履歴ID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `store_id` bigint(20) NOT NULL COMMENT 'ストアID',
  `value` bigint(20) NOT NULL COMMENT 'プール値',
  `description` text NOT NULL COMMENT '説明',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`,`created_at`),
  KEY `idx_log_player_store_point_pools_1` (`spid`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ポイントプール'
/*!50500 PARTITION BY RANGE  COLUMNS(created_at)
(PARTITION p201605 VALUES LESS THAN ('2016-06-01') ENGINE = InnoDB,
 PARTITION p201606 VALUES LESS THAN ('2016-07-01') ENGINE = InnoDB,
 PARTITION p201607 VALUES LESS THAN ('2016-08-01') ENGINE = InnoDB,
 PARTITION p201608 VALUES LESS THAN ('2016-09-01') ENGINE = InnoDB,
 PARTITION p201609 VALUES LESS THAN ('2016-10-01') ENGINE = InnoDB,
 PARTITION p201610 VALUES LESS THAN ('2016-11-01') ENGINE = InnoDB,
 PARTITION p201611 VALUES LESS THAN ('2016-12-01') ENGINE = InnoDB,
 PARTITION p201612 VALUES LESS THAN ('2017-01-01') ENGINE = InnoDB,
 PARTITION p201701 VALUES LESS THAN ('2017-02-01') ENGINE = InnoDB,
 PARTITION p201702 VALUES LESS THAN ('2017-03-01') ENGINE = InnoDB,
 PARTITION p201703 VALUES LESS THAN ('2017-04-01') ENGINE = InnoDB,
 PARTITION p201704 VALUES LESS THAN ('2017-05-01') ENGINE = InnoDB,
 PARTITION p201705 VALUES LESS THAN ('2017-06-01') ENGINE = InnoDB,
 PARTITION p201706 VALUES LESS THAN ('2017-07-01') ENGINE = InnoDB,
 PARTITION p201707 VALUES LESS THAN ('2017-08-01') ENGINE = InnoDB,
 PARTITION p201708 VALUES LESS THAN ('2017-09-01') ENGINE = InnoDB,
 PARTITION p201709 VALUES LESS THAN ('2017-10-01') ENGINE = InnoDB,
 PARTITION p201710 VALUES LESS THAN ('2017-11-01') ENGINE = InnoDB,
 PARTITION p201711 VALUES LESS THAN ('2017-12-01') ENGINE = InnoDB,
 PARTITION p201712 VALUES LESS THAN ('2018-01-01') ENGINE = InnoDB,
 PARTITION p201801 VALUES LESS THAN ('2018-02-01') ENGINE = InnoDB,
 PARTITION p201802 VALUES LESS THAN ('2018-03-01') ENGINE = InnoDB,
 PARTITION p201803 VALUES LESS THAN ('2018-04-01') ENGINE = InnoDB,
 PARTITION p201804 VALUES LESS THAN ('2018-05-01') ENGINE = InnoDB,
 PARTITION p201805 VALUES LESS THAN ('2018-06-01') ENGINE = InnoDB,
 PARTITION p201806 VALUES LESS THAN ('2018-07-01') ENGINE = InnoDB,
 PARTITION p201807 VALUES LESS THAN ('2018-08-01') ENGINE = InnoDB,
 PARTITION p201808 VALUES LESS THAN ('2018-09-01') ENGINE = InnoDB,
 PARTITION p201809 VALUES LESS THAN ('2018-10-01') ENGINE = InnoDB,
 PARTITION p201810 VALUES LESS THAN ('2018-11-01') ENGINE = InnoDB,
 PARTITION p201811 VALUES LESS THAN ('2018-12-01') ENGINE = InnoDB,
 PARTITION p201812 VALUES LESS THAN ('2019-01-01') ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_point_baks`
--

DROP TABLE IF EXISTS `log_point_baks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_point_baks` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ポイントID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `num` int(11) NOT NULL COMMENT '所持ポイント数',
  `org_num` int(11) NOT NULL COMMENT 'もともとの所持ポイント数',
  `add_num` int(11) NOT NULL COMMENT '追加数',
  `action` text COMMENT '追加箇所',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_log_points_1` (`spid`,`point_id`),
  KEY `idx_log_points_2` (`spid`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ポイント情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_points`
--

DROP TABLE IF EXISTS `log_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_points` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ポイントID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `num` bigint(20) NOT NULL COMMENT '所持ポイント数',
  `org_num` bigint(20) NOT NULL COMMENT 'もともとの所持ポイント数',
  `add_num` bigint(20) NOT NULL COMMENT '追加数',
  `action` text COMMENT '追加箇所',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`,`created_at`),
  KEY `idx_log_points_1` (`spid`,`point_id`),
  KEY `idx_log_points_2` (`spid`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='ポイントログ'
/*!50500 PARTITION BY RANGE  COLUMNS(created_at)
(PARTITION p201512 VALUES LESS THAN ('2016-01-01') ENGINE = InnoDB,
 PARTITION p201601 VALUES LESS THAN ('2016-02-01') ENGINE = InnoDB,
 PARTITION p201602 VALUES LESS THAN ('2016-03-01') ENGINE = InnoDB,
 PARTITION p201603 VALUES LESS THAN ('2016-04-01') ENGINE = InnoDB,
 PARTITION p201604 VALUES LESS THAN ('2016-05-01') ENGINE = InnoDB,
 PARTITION p201605 VALUES LESS THAN ('2016-06-01') ENGINE = InnoDB,
 PARTITION p201606 VALUES LESS THAN ('2016-07-01') ENGINE = InnoDB,
 PARTITION p201607 VALUES LESS THAN ('2016-08-01') ENGINE = InnoDB,
 PARTITION p201608 VALUES LESS THAN ('2016-09-01') ENGINE = InnoDB,
 PARTITION p201609 VALUES LESS THAN ('2016-10-01') ENGINE = InnoDB,
 PARTITION p201610 VALUES LESS THAN ('2016-11-01') ENGINE = InnoDB,
 PARTITION p201611 VALUES LESS THAN ('2016-12-01') ENGINE = InnoDB,
 PARTITION p201612 VALUES LESS THAN ('2017-01-01') ENGINE = InnoDB,
 PARTITION p201701 VALUES LESS THAN ('2017-02-01') ENGINE = InnoDB,
 PARTITION p201702 VALUES LESS THAN ('2017-03-01') ENGINE = InnoDB,
 PARTITION p201703 VALUES LESS THAN ('2017-04-01') ENGINE = InnoDB,
 PARTITION p201704 VALUES LESS THAN ('2017-05-01') ENGINE = InnoDB,
 PARTITION p201705 VALUES LESS THAN ('2017-06-01') ENGINE = InnoDB,
 PARTITION p201706 VALUES LESS THAN ('2017-07-01') ENGINE = InnoDB,
 PARTITION p201707 VALUES LESS THAN ('2017-08-01') ENGINE = InnoDB,
 PARTITION p201708 VALUES LESS THAN ('2017-09-01') ENGINE = InnoDB,
 PARTITION p201709 VALUES LESS THAN ('2017-10-01') ENGINE = InnoDB,
 PARTITION p201710 VALUES LESS THAN ('2017-11-01') ENGINE = InnoDB,
 PARTITION p201711 VALUES LESS THAN ('2017-12-01') ENGINE = InnoDB,
 PARTITION p201712 VALUES LESS THAN ('2018-01-01') ENGINE = InnoDB,
 PARTITION p201801 VALUES LESS THAN ('2018-02-01') ENGINE = InnoDB,
 PARTITION p201802 VALUES LESS THAN ('2018-03-01') ENGINE = InnoDB,
 PARTITION p201803 VALUES LESS THAN ('2018-04-01') ENGINE = InnoDB,
 PARTITION p201804 VALUES LESS THAN ('2018-05-01') ENGINE = InnoDB,
 PARTITION p201805 VALUES LESS THAN ('2018-06-01') ENGINE = InnoDB,
 PARTITION p201806 VALUES LESS THAN ('2018-07-01') ENGINE = InnoDB,
 PARTITION p201807 VALUES LESS THAN ('2018-08-01') ENGINE = InnoDB,
 PARTITION p201808 VALUES LESS THAN ('2018-09-01') ENGINE = InnoDB,
 PARTITION p201809 VALUES LESS THAN ('2018-10-01') ENGINE = InnoDB,
 PARTITION p201810 VALUES LESS THAN ('2018-11-01') ENGINE = InnoDB,
 PARTITION p201811 VALUES LESS THAN ('2018-12-01') ENGINE = InnoDB,
 PARTITION p201812 VALUES LESS THAN ('2019-01-01') ENGINE = InnoDB,
 PARTITION p201901 VALUES LESS THAN ('2019-02-01') ENGINE = InnoDB,
 PARTITION p201902 VALUES LESS THAN ('2019-03-01') ENGINE = InnoDB,
 PARTITION p201903 VALUES LESS THAN ('2019-04-01') ENGINE = InnoDB,
 PARTITION p201904 VALUES LESS THAN ('2019-05-01') ENGINE = InnoDB,
 PARTITION p201905 VALUES LESS THAN ('2019-06-01') ENGINE = InnoDB,
 PARTITION p201906 VALUES LESS THAN ('2019-07-01') ENGINE = InnoDB,
 PARTITION p201907 VALUES LESS THAN ('2019-08-01') ENGINE = InnoDB,
 PARTITION p201908 VALUES LESS THAN ('2019-09-01') ENGINE = InnoDB,
 PARTITION p201909 VALUES LESS THAN ('2019-10-01') ENGINE = InnoDB,
 PARTITION p201910 VALUES LESS THAN ('2019-11-01') ENGINE = InnoDB,
 PARTITION p201911 VALUES LESS THAN ('2019-12-01') ENGINE = InnoDB,
 PARTITION p201912 VALUES LESS THAN ('2020-01-01') ENGINE = InnoDB,
 PARTITION p202001 VALUES LESS THAN ('2020-02-01') ENGINE = InnoDB,
 PARTITION p202002 VALUES LESS THAN ('2020-03-01') ENGINE = InnoDB,
 PARTITION p202003 VALUES LESS THAN ('2020-04-01') ENGINE = InnoDB,
 PARTITION p202004 VALUES LESS THAN ('2020-05-01') ENGINE = InnoDB,
 PARTITION p202005 VALUES LESS THAN ('2020-06-01') ENGINE = InnoDB,
 PARTITION p202006 VALUES LESS THAN ('2020-07-01') ENGINE = InnoDB,
 PARTITION p202007 VALUES LESS THAN ('2020-08-01') ENGINE = InnoDB,
 PARTITION p202008 VALUES LESS THAN ('2020-09-01') ENGINE = InnoDB,
 PARTITION p202009 VALUES LESS THAN ('2020-10-01') ENGINE = InnoDB,
 PARTITION p202010 VALUES LESS THAN ('2020-11-01') ENGINE = InnoDB,
 PARTITION p202011 VALUES LESS THAN ('2020-12-01') ENGINE = InnoDB,
 PARTITION p202012 VALUES LESS THAN ('2021-01-01') ENGINE = InnoDB,
 PARTITION p202101 VALUES LESS THAN ('2021-02-01') ENGINE = InnoDB,
 PARTITION p202102 VALUES LESS THAN ('2021-03-01') ENGINE = InnoDB,
 PARTITION p202103 VALUES LESS THAN ('2021-04-01') ENGINE = InnoDB,
 PARTITION p202104 VALUES LESS THAN ('2021-05-01') ENGINE = InnoDB,
 PARTITION p202105 VALUES LESS THAN ('2021-06-01') ENGINE = InnoDB,
 PARTITION p202106 VALUES LESS THAN ('2021-07-01') ENGINE = InnoDB,
 PARTITION p202107 VALUES LESS THAN ('2021-08-01') ENGINE = InnoDB,
 PARTITION p202108 VALUES LESS THAN ('2021-09-01') ENGINE = InnoDB,
 PARTITION p202109 VALUES LESS THAN ('2021-10-01') ENGINE = InnoDB,
 PARTITION p202110 VALUES LESS THAN ('2021-11-01') ENGINE = InnoDB,
 PARTITION p202111 VALUES LESS THAN ('2021-12-01') ENGINE = InnoDB,
 PARTITION p202112 VALUES LESS THAN ('2022-01-01') ENGINE = InnoDB,
 PARTITION p202201 VALUES LESS THAN ('2022-02-01') ENGINE = InnoDB,
 PARTITION p202202 VALUES LESS THAN ('2022-03-01') ENGINE = InnoDB,
 PARTITION p202203 VALUES LESS THAN ('2022-04-01') ENGINE = InnoDB,
 PARTITION p202204 VALUES LESS THAN ('2022-05-01') ENGINE = InnoDB,
 PARTITION p202205 VALUES LESS THAN ('2022-06-01') ENGINE = InnoDB,
 PARTITION p202206 VALUES LESS THAN ('2022-07-01') ENGINE = InnoDB,
 PARTITION p202207 VALUES LESS THAN ('2022-08-01') ENGINE = InnoDB,
 PARTITION p202208 VALUES LESS THAN ('2022-09-01') ENGINE = InnoDB,
 PARTITION p202209 VALUES LESS THAN ('2022-10-01') ENGINE = InnoDB,
 PARTITION p202210 VALUES LESS THAN ('2022-11-01') ENGINE = InnoDB,
 PARTITION p202211 VALUES LESS THAN ('2022-12-01') ENGINE = InnoDB,
 PARTITION p202212 VALUES LESS THAN ('2023-01-01') ENGINE = InnoDB,
 PARTITION p202301 VALUES LESS THAN ('2023-02-01') ENGINE = InnoDB,
 PARTITION p202302 VALUES LESS THAN ('2023-03-01') ENGINE = InnoDB,
 PARTITION p202303 VALUES LESS THAN ('2023-04-01') ENGINE = InnoDB,
 PARTITION p202304 VALUES LESS THAN ('2023-05-01') ENGINE = InnoDB,
 PARTITION p202305 VALUES LESS THAN ('2023-06-01') ENGINE = InnoDB,
 PARTITION p202306 VALUES LESS THAN ('2023-07-01') ENGINE = InnoDB,
 PARTITION p202307 VALUES LESS THAN ('2023-08-01') ENGINE = InnoDB,
 PARTITION p202308 VALUES LESS THAN ('2023-09-01') ENGINE = InnoDB,
 PARTITION p202309 VALUES LESS THAN ('2023-10-01') ENGINE = InnoDB,
 PARTITION p202310 VALUES LESS THAN ('2023-11-01') ENGINE = InnoDB,
 PARTITION p202311 VALUES LESS THAN ('2023-12-01') ENGINE = InnoDB,
 PARTITION p202312 VALUES LESS THAN ('2024-01-01') ENGINE = InnoDB,
 PARTITION p202401 VALUES LESS THAN ('2024-02-01') ENGINE = InnoDB,
 PARTITION p202402 VALUES LESS THAN ('2024-03-01') ENGINE = InnoDB,
 PARTITION p202403 VALUES LESS THAN ('2024-04-01') ENGINE = InnoDB,
 PARTITION p202404 VALUES LESS THAN ('2024-05-01') ENGINE = InnoDB,
 PARTITION p202405 VALUES LESS THAN ('2024-06-01') ENGINE = InnoDB,
 PARTITION p202406 VALUES LESS THAN ('2024-07-01') ENGINE = InnoDB,
 PARTITION p202407 VALUES LESS THAN ('2024-08-01') ENGINE = InnoDB,
 PARTITION p202408 VALUES LESS THAN ('2024-09-01') ENGINE = InnoDB,
 PARTITION p202409 VALUES LESS THAN ('2024-10-01') ENGINE = InnoDB,
 PARTITION p202410 VALUES LESS THAN ('2024-11-01') ENGINE = InnoDB,
 PARTITION p202411 VALUES LESS THAN ('2024-12-01') ENGINE = InnoDB,
 PARTITION p202412 VALUES LESS THAN ('2025-01-01') ENGINE = InnoDB,
 PARTITION p202501 VALUES LESS THAN ('2025-02-01') ENGINE = InnoDB,
 PARTITION p202502 VALUES LESS THAN ('2025-03-01') ENGINE = InnoDB,
 PARTITION p202503 VALUES LESS THAN ('2025-04-01') ENGINE = InnoDB,
 PARTITION p202504 VALUES LESS THAN ('2025-05-01') ENGINE = InnoDB,
 PARTITION p202505 VALUES LESS THAN ('2025-06-01') ENGINE = InnoDB,
 PARTITION p202506 VALUES LESS THAN ('2025-07-01') ENGINE = InnoDB,
 PARTITION p202507 VALUES LESS THAN ('2025-08-01') ENGINE = InnoDB,
 PARTITION p202508 VALUES LESS THAN ('2025-09-01') ENGINE = InnoDB,
 PARTITION p202509 VALUES LESS THAN ('2025-10-01') ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN ('2025-11-01') ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN ('2025-12-01') ENGINE = InnoDB,
 PARTITION p202512 VALUES LESS THAN ('2026-01-01') ENGINE = InnoDB,
 PARTITION p202601 VALUES LESS THAN ('2026-02-01') ENGINE = InnoDB,
 PARTITION p202602 VALUES LESS THAN ('2026-03-01') ENGINE = InnoDB,
 PARTITION p202603 VALUES LESS THAN ('2026-04-01') ENGINE = InnoDB,
 PARTITION p202604 VALUES LESS THAN ('2026-05-01') ENGINE = InnoDB,
 PARTITION p202605 VALUES LESS THAN ('2026-06-01') ENGINE = InnoDB,
 PARTITION p202606 VALUES LESS THAN ('2026-07-01') ENGINE = InnoDB,
 PARTITION p202607 VALUES LESS THAN ('2026-08-01') ENGINE = InnoDB,
 PARTITION p202608 VALUES LESS THAN ('2026-09-01') ENGINE = InnoDB,
 PARTITION p202609 VALUES LESS THAN ('2026-10-01') ENGINE = InnoDB,
 PARTITION p202610 VALUES LESS THAN ('2026-11-01') ENGINE = InnoDB,
 PARTITION p202611 VALUES LESS THAN ('2026-12-01') ENGINE = InnoDB,
 PARTITION p202612 VALUES LESS THAN ('2027-01-01') ENGINE = InnoDB,
 PARTITION p202701 VALUES LESS THAN ('2027-02-01') ENGINE = InnoDB,
 PARTITION p202702 VALUES LESS THAN ('2027-03-01') ENGINE = InnoDB,
 PARTITION p202703 VALUES LESS THAN ('2027-04-01') ENGINE = InnoDB,
 PARTITION p202704 VALUES LESS THAN ('2027-05-01') ENGINE = InnoDB,
 PARTITION p202705 VALUES LESS THAN ('2027-06-01') ENGINE = InnoDB,
 PARTITION p202706 VALUES LESS THAN ('2027-07-01') ENGINE = InnoDB,
 PARTITION p202707 VALUES LESS THAN ('2027-08-01') ENGINE = InnoDB,
 PARTITION p202708 VALUES LESS THAN ('2027-09-01') ENGINE = InnoDB,
 PARTITION p202709 VALUES LESS THAN ('2027-10-01') ENGINE = InnoDB,
 PARTITION p202710 VALUES LESS THAN ('2027-11-01') ENGINE = InnoDB,
 PARTITION p202711 VALUES LESS THAN ('2027-12-01') ENGINE = InnoDB,
 PARTITION p202712 VALUES LESS THAN ('2028-01-01') ENGINE = InnoDB,
 PARTITION p202801 VALUES LESS THAN ('2028-02-01') ENGINE = InnoDB,
 PARTITION p202802 VALUES LESS THAN ('2028-03-01') ENGINE = InnoDB,
 PARTITION p202803 VALUES LESS THAN ('2028-04-01') ENGINE = InnoDB,
 PARTITION p202804 VALUES LESS THAN ('2028-05-01') ENGINE = InnoDB,
 PARTITION p202805 VALUES LESS THAN ('2028-06-01') ENGINE = InnoDB,
 PARTITION p202806 VALUES LESS THAN ('2028-07-01') ENGINE = InnoDB,
 PARTITION p202807 VALUES LESS THAN ('2028-08-01') ENGINE = InnoDB,
 PARTITION p202808 VALUES LESS THAN ('2028-09-01') ENGINE = InnoDB,
 PARTITION p202809 VALUES LESS THAN ('2028-10-01') ENGINE = InnoDB,
 PARTITION p202810 VALUES LESS THAN ('2028-11-01') ENGINE = InnoDB,
 PARTITION p202811 VALUES LESS THAN ('2028-12-01') ENGINE = InnoDB,
 PARTITION p202812 VALUES LESS THAN ('2029-01-01') ENGINE = InnoDB,
 PARTITION p202901 VALUES LESS THAN ('2029-02-01') ENGINE = InnoDB,
 PARTITION p202902 VALUES LESS THAN ('2029-03-01') ENGINE = InnoDB,
 PARTITION p202903 VALUES LESS THAN ('2029-04-01') ENGINE = InnoDB,
 PARTITION p202904 VALUES LESS THAN ('2029-05-01') ENGINE = InnoDB,
 PARTITION p202905 VALUES LESS THAN ('2029-06-01') ENGINE = InnoDB,
 PARTITION p202906 VALUES LESS THAN ('2029-07-01') ENGINE = InnoDB,
 PARTITION p202907 VALUES LESS THAN ('2029-08-01') ENGINE = InnoDB,
 PARTITION p202908 VALUES LESS THAN ('2029-09-01') ENGINE = InnoDB,
 PARTITION p202909 VALUES LESS THAN ('2029-10-01') ENGINE = InnoDB,
 PARTITION p202910 VALUES LESS THAN ('2029-11-01') ENGINE = InnoDB,
 PARTITION p202911 VALUES LESS THAN ('2029-12-01') ENGINE = InnoDB,
 PARTITION p202912 VALUES LESS THAN ('2030-01-01') ENGINE = InnoDB,
 PARTITION p203001 VALUES LESS THAN ('2030-02-01') ENGINE = InnoDB,
 PARTITION p203002 VALUES LESS THAN ('2030-03-01') ENGINE = InnoDB,
 PARTITION p203003 VALUES LESS THAN ('2030-04-01') ENGINE = InnoDB,
 PARTITION p203004 VALUES LESS THAN ('2030-05-01') ENGINE = InnoDB,
 PARTITION p203005 VALUES LESS THAN ('2030-06-01') ENGINE = InnoDB,
 PARTITION p203006 VALUES LESS THAN ('2030-07-01') ENGINE = InnoDB,
 PARTITION p203007 VALUES LESS THAN ('2030-08-01') ENGINE = InnoDB,
 PARTITION p203008 VALUES LESS THAN ('2030-09-01') ENGINE = InnoDB,
 PARTITION p203009 VALUES LESS THAN ('2030-10-01') ENGINE = InnoDB,
 PARTITION p203010 VALUES LESS THAN ('2030-11-01') ENGINE = InnoDB,
 PARTITION p203011 VALUES LESS THAN ('2030-12-01') ENGINE = InnoDB,
 PARTITION p203012 VALUES LESS THAN ('2031-01-01') ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_product_inventories`
--

DROP TABLE IF EXISTS `log_product_inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_product_inventories` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '商品在庫情報',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `product_id` bigint(20) NOT NULL COMMENT '商品ID',
  `num` int(11) NOT NULL COMMENT '在庫個数',
  `org_num` int(11) NOT NULL COMMENT 'もともとの在庫個数',
  `lock_version` int(11) NOT NULL DEFAULT '0' COMMENT 'バージョン番号',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`,`created_at`),
  KEY `idx_log_product_inventories_2` (`spid`,`id`,`product_id`),
  KEY `idx_log_product_inventories_1` (`spid`,`product_id`,`org_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品在庫情報'
/*!50500 PARTITION BY RANGE  COLUMNS(created_at)
(PARTITION p201709 VALUES LESS THAN ('2017-10-01') ENGINE = InnoDB,
 PARTITION p201710 VALUES LESS THAN ('2017-11-01') ENGINE = InnoDB,
 PARTITION p201711 VALUES LESS THAN ('2017-12-01') ENGINE = InnoDB,
 PARTITION p201712 VALUES LESS THAN ('2018-01-01') ENGINE = InnoDB,
 PARTITION p201801 VALUES LESS THAN ('2018-02-01') ENGINE = InnoDB,
 PARTITION p201802 VALUES LESS THAN ('2018-03-01') ENGINE = InnoDB,
 PARTITION p201803 VALUES LESS THAN ('2018-04-01') ENGINE = InnoDB,
 PARTITION p201804 VALUES LESS THAN ('2018-05-01') ENGINE = InnoDB,
 PARTITION p201805 VALUES LESS THAN ('2018-06-01') ENGINE = InnoDB,
 PARTITION p201806 VALUES LESS THAN ('2018-07-01') ENGINE = InnoDB,
 PARTITION p201807 VALUES LESS THAN ('2018-08-01') ENGINE = InnoDB,
 PARTITION p201808 VALUES LESS THAN ('2018-09-01') ENGINE = InnoDB,
 PARTITION p201809 VALUES LESS THAN ('2018-10-01') ENGINE = InnoDB,
 PARTITION p201810 VALUES LESS THAN ('2018-11-01') ENGINE = InnoDB,
 PARTITION p201811 VALUES LESS THAN ('2018-12-01') ENGINE = InnoDB,
 PARTITION p201812 VALUES LESS THAN ('2019-01-01') ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_product_inventory_deletes`
--

DROP TABLE IF EXISTS `log_product_inventory_deletes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_product_inventory_deletes` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '商品削除履歴',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `product_inventory_id` bigint(20) NOT NULL COMMENT '商品在庫ID',
  `product_id` bigint(20) NOT NULL COMMENT '商品ID',
  `num` int(11) NOT NULL COMMENT '個数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_log_product_inventory_deletes_1` (`spid`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品削除履歴';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_products`
--

DROP TABLE IF EXISTS `log_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_products` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '商品履歴用ID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `product_id` bigint(20) NOT NULL COMMENT '商品ID',
  `num` int(11) NOT NULL COMMENT '個数',
  `description` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`,`created_at`),
  KEY `idx_log_products_1` (`spid`,`created_at`),
  KEY `idx_log_products_2` (`spid`,`product_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品履歴用'
/*!50500 PARTITION BY RANGE  COLUMNS(created_at)
(PARTITION p201709 VALUES LESS THAN ('2017-10-01') ENGINE = InnoDB,
 PARTITION p201710 VALUES LESS THAN ('2017-11-01') ENGINE = InnoDB,
 PARTITION p201711 VALUES LESS THAN ('2017-12-01') ENGINE = InnoDB,
 PARTITION p201712 VALUES LESS THAN ('2018-01-01') ENGINE = InnoDB,
 PARTITION p201801 VALUES LESS THAN ('2018-02-01') ENGINE = InnoDB,
 PARTITION p201802 VALUES LESS THAN ('2018-03-01') ENGINE = InnoDB,
 PARTITION p201803 VALUES LESS THAN ('2018-04-01') ENGINE = InnoDB,
 PARTITION p201804 VALUES LESS THAN ('2018-05-01') ENGINE = InnoDB,
 PARTITION p201805 VALUES LESS THAN ('2018-06-01') ENGINE = InnoDB,
 PARTITION p201806 VALUES LESS THAN ('2018-07-01') ENGINE = InnoDB,
 PARTITION p201807 VALUES LESS THAN ('2018-08-01') ENGINE = InnoDB,
 PARTITION p201808 VALUES LESS THAN ('2018-09-01') ENGINE = InnoDB,
 PARTITION p201809 VALUES LESS THAN ('2018-10-01') ENGINE = InnoDB,
 PARTITION p201810 VALUES LESS THAN ('2018-11-01') ENGINE = InnoDB,
 PARTITION p201811 VALUES LESS THAN ('2018-12-01') ENGINE = InnoDB,
 PARTITION p201812 VALUES LESS THAN ('2019-01-01') ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_push_quest_lot_list_rewards`
--

DROP TABLE IF EXISTS `log_push_quest_lot_list_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_push_quest_lot_list_rewards` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プッシュクエスト報酬受け取りログ',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `push_quest_list_id` int(11) NOT NULL COMMENT 'プッシュクエストリストID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`,`created_at`),
  KEY `idx_log_push_quest_lot_list_rewards_1` (`event_id`,`push_quest_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='プッシュクエスト報酬受け取りログ'
/*!50500 PARTITION BY RANGE  COLUMNS(created_at)
(PARTITION p201512 VALUES LESS THAN ('2016-01-01') ENGINE = InnoDB,
 PARTITION p201601 VALUES LESS THAN ('2016-02-01') ENGINE = InnoDB,
 PARTITION p201602 VALUES LESS THAN ('2016-03-01') ENGINE = InnoDB,
 PARTITION p201603 VALUES LESS THAN ('2016-04-01') ENGINE = InnoDB,
 PARTITION p201604 VALUES LESS THAN ('2016-05-01') ENGINE = InnoDB,
 PARTITION p201605 VALUES LESS THAN ('2016-06-01') ENGINE = InnoDB,
 PARTITION p201606 VALUES LESS THAN ('2016-07-01') ENGINE = InnoDB,
 PARTITION p201607 VALUES LESS THAN ('2016-08-01') ENGINE = InnoDB,
 PARTITION p201608 VALUES LESS THAN ('2016-09-01') ENGINE = InnoDB,
 PARTITION p201609 VALUES LESS THAN ('2016-10-01') ENGINE = InnoDB,
 PARTITION p201610 VALUES LESS THAN ('2016-11-01') ENGINE = InnoDB,
 PARTITION p201611 VALUES LESS THAN ('2016-12-01') ENGINE = InnoDB,
 PARTITION p201612 VALUES LESS THAN ('2017-01-01') ENGINE = InnoDB,
 PARTITION p201701 VALUES LESS THAN ('2017-02-01') ENGINE = InnoDB,
 PARTITION p201702 VALUES LESS THAN ('2017-03-01') ENGINE = InnoDB,
 PARTITION p201703 VALUES LESS THAN ('2017-04-01') ENGINE = InnoDB,
 PARTITION p201704 VALUES LESS THAN ('2017-05-01') ENGINE = InnoDB,
 PARTITION p201705 VALUES LESS THAN ('2017-06-01') ENGINE = InnoDB,
 PARTITION p201706 VALUES LESS THAN ('2017-07-01') ENGINE = InnoDB,
 PARTITION p201707 VALUES LESS THAN ('2017-08-01') ENGINE = InnoDB,
 PARTITION p201708 VALUES LESS THAN ('2017-09-01') ENGINE = InnoDB,
 PARTITION p201709 VALUES LESS THAN ('2017-10-01') ENGINE = InnoDB,
 PARTITION p201710 VALUES LESS THAN ('2017-11-01') ENGINE = InnoDB,
 PARTITION p201711 VALUES LESS THAN ('2017-12-01') ENGINE = InnoDB,
 PARTITION p201712 VALUES LESS THAN ('2018-01-01') ENGINE = InnoDB,
 PARTITION p201801 VALUES LESS THAN ('2018-02-01') ENGINE = InnoDB,
 PARTITION p201802 VALUES LESS THAN ('2018-03-01') ENGINE = InnoDB,
 PARTITION p201803 VALUES LESS THAN ('2018-04-01') ENGINE = InnoDB,
 PARTITION p201804 VALUES LESS THAN ('2018-05-01') ENGINE = InnoDB,
 PARTITION p201805 VALUES LESS THAN ('2018-06-01') ENGINE = InnoDB,
 PARTITION p201806 VALUES LESS THAN ('2018-07-01') ENGINE = InnoDB,
 PARTITION p201807 VALUES LESS THAN ('2018-08-01') ENGINE = InnoDB,
 PARTITION p201808 VALUES LESS THAN ('2018-09-01') ENGINE = InnoDB,
 PARTITION p201809 VALUES LESS THAN ('2018-10-01') ENGINE = InnoDB,
 PARTITION p201810 VALUES LESS THAN ('2018-11-01') ENGINE = InnoDB,
 PARTITION p201811 VALUES LESS THAN ('2018-12-01') ENGINE = InnoDB,
 PARTITION p201812 VALUES LESS THAN ('2019-01-01') ENGINE = InnoDB,
 PARTITION p201901 VALUES LESS THAN ('2019-02-01') ENGINE = InnoDB,
 PARTITION p201902 VALUES LESS THAN ('2019-03-01') ENGINE = InnoDB,
 PARTITION p201903 VALUES LESS THAN ('2019-04-01') ENGINE = InnoDB,
 PARTITION p201904 VALUES LESS THAN ('2019-05-01') ENGINE = InnoDB,
 PARTITION p201905 VALUES LESS THAN ('2019-06-01') ENGINE = InnoDB,
 PARTITION p201906 VALUES LESS THAN ('2019-07-01') ENGINE = InnoDB,
 PARTITION p201907 VALUES LESS THAN ('2019-08-01') ENGINE = InnoDB,
 PARTITION p201908 VALUES LESS THAN ('2019-09-01') ENGINE = InnoDB,
 PARTITION p201909 VALUES LESS THAN ('2019-10-01') ENGINE = InnoDB,
 PARTITION p201910 VALUES LESS THAN ('2019-11-01') ENGINE = InnoDB,
 PARTITION p201911 VALUES LESS THAN ('2019-12-01') ENGINE = InnoDB,
 PARTITION p201912 VALUES LESS THAN ('2020-01-01') ENGINE = InnoDB,
 PARTITION p202001 VALUES LESS THAN ('2020-02-01') ENGINE = InnoDB,
 PARTITION p202002 VALUES LESS THAN ('2020-03-01') ENGINE = InnoDB,
 PARTITION p202003 VALUES LESS THAN ('2020-04-01') ENGINE = InnoDB,
 PARTITION p202004 VALUES LESS THAN ('2020-05-01') ENGINE = InnoDB,
 PARTITION p202005 VALUES LESS THAN ('2020-06-01') ENGINE = InnoDB,
 PARTITION p202006 VALUES LESS THAN ('2020-07-01') ENGINE = InnoDB,
 PARTITION p202007 VALUES LESS THAN ('2020-08-01') ENGINE = InnoDB,
 PARTITION p202008 VALUES LESS THAN ('2020-09-01') ENGINE = InnoDB,
 PARTITION p202009 VALUES LESS THAN ('2020-10-01') ENGINE = InnoDB,
 PARTITION p202010 VALUES LESS THAN ('2020-11-01') ENGINE = InnoDB,
 PARTITION p202011 VALUES LESS THAN ('2020-12-01') ENGINE = InnoDB,
 PARTITION p202012 VALUES LESS THAN ('2021-01-01') ENGINE = InnoDB,
 PARTITION p202101 VALUES LESS THAN ('2021-02-01') ENGINE = InnoDB,
 PARTITION p202102 VALUES LESS THAN ('2021-03-01') ENGINE = InnoDB,
 PARTITION p202103 VALUES LESS THAN ('2021-04-01') ENGINE = InnoDB,
 PARTITION p202104 VALUES LESS THAN ('2021-05-01') ENGINE = InnoDB,
 PARTITION p202105 VALUES LESS THAN ('2021-06-01') ENGINE = InnoDB,
 PARTITION p202106 VALUES LESS THAN ('2021-07-01') ENGINE = InnoDB,
 PARTITION p202107 VALUES LESS THAN ('2021-08-01') ENGINE = InnoDB,
 PARTITION p202108 VALUES LESS THAN ('2021-09-01') ENGINE = InnoDB,
 PARTITION p202109 VALUES LESS THAN ('2021-10-01') ENGINE = InnoDB,
 PARTITION p202110 VALUES LESS THAN ('2021-11-01') ENGINE = InnoDB,
 PARTITION p202111 VALUES LESS THAN ('2021-12-01') ENGINE = InnoDB,
 PARTITION p202112 VALUES LESS THAN ('2022-01-01') ENGINE = InnoDB,
 PARTITION p202201 VALUES LESS THAN ('2022-02-01') ENGINE = InnoDB,
 PARTITION p202202 VALUES LESS THAN ('2022-03-01') ENGINE = InnoDB,
 PARTITION p202203 VALUES LESS THAN ('2022-04-01') ENGINE = InnoDB,
 PARTITION p202204 VALUES LESS THAN ('2022-05-01') ENGINE = InnoDB,
 PARTITION p202205 VALUES LESS THAN ('2022-06-01') ENGINE = InnoDB,
 PARTITION p202206 VALUES LESS THAN ('2022-07-01') ENGINE = InnoDB,
 PARTITION p202207 VALUES LESS THAN ('2022-08-01') ENGINE = InnoDB,
 PARTITION p202208 VALUES LESS THAN ('2022-09-01') ENGINE = InnoDB,
 PARTITION p202209 VALUES LESS THAN ('2022-10-01') ENGINE = InnoDB,
 PARTITION p202210 VALUES LESS THAN ('2022-11-01') ENGINE = InnoDB,
 PARTITION p202211 VALUES LESS THAN ('2022-12-01') ENGINE = InnoDB,
 PARTITION p202212 VALUES LESS THAN ('2023-01-01') ENGINE = InnoDB,
 PARTITION p202301 VALUES LESS THAN ('2023-02-01') ENGINE = InnoDB,
 PARTITION p202302 VALUES LESS THAN ('2023-03-01') ENGINE = InnoDB,
 PARTITION p202303 VALUES LESS THAN ('2023-04-01') ENGINE = InnoDB,
 PARTITION p202304 VALUES LESS THAN ('2023-05-01') ENGINE = InnoDB,
 PARTITION p202305 VALUES LESS THAN ('2023-06-01') ENGINE = InnoDB,
 PARTITION p202306 VALUES LESS THAN ('2023-07-01') ENGINE = InnoDB,
 PARTITION p202307 VALUES LESS THAN ('2023-08-01') ENGINE = InnoDB,
 PARTITION p202308 VALUES LESS THAN ('2023-09-01') ENGINE = InnoDB,
 PARTITION p202309 VALUES LESS THAN ('2023-10-01') ENGINE = InnoDB,
 PARTITION p202310 VALUES LESS THAN ('2023-11-01') ENGINE = InnoDB,
 PARTITION p202311 VALUES LESS THAN ('2023-12-01') ENGINE = InnoDB,
 PARTITION p202312 VALUES LESS THAN ('2024-01-01') ENGINE = InnoDB,
 PARTITION p202401 VALUES LESS THAN ('2024-02-01') ENGINE = InnoDB,
 PARTITION p202402 VALUES LESS THAN ('2024-03-01') ENGINE = InnoDB,
 PARTITION p202403 VALUES LESS THAN ('2024-04-01') ENGINE = InnoDB,
 PARTITION p202404 VALUES LESS THAN ('2024-05-01') ENGINE = InnoDB,
 PARTITION p202405 VALUES LESS THAN ('2024-06-01') ENGINE = InnoDB,
 PARTITION p202406 VALUES LESS THAN ('2024-07-01') ENGINE = InnoDB,
 PARTITION p202407 VALUES LESS THAN ('2024-08-01') ENGINE = InnoDB,
 PARTITION p202408 VALUES LESS THAN ('2024-09-01') ENGINE = InnoDB,
 PARTITION p202409 VALUES LESS THAN ('2024-10-01') ENGINE = InnoDB,
 PARTITION p202410 VALUES LESS THAN ('2024-11-01') ENGINE = InnoDB,
 PARTITION p202411 VALUES LESS THAN ('2024-12-01') ENGINE = InnoDB,
 PARTITION p202412 VALUES LESS THAN ('2025-01-01') ENGINE = InnoDB,
 PARTITION p202501 VALUES LESS THAN ('2025-02-01') ENGINE = InnoDB,
 PARTITION p202502 VALUES LESS THAN ('2025-03-01') ENGINE = InnoDB,
 PARTITION p202503 VALUES LESS THAN ('2025-04-01') ENGINE = InnoDB,
 PARTITION p202504 VALUES LESS THAN ('2025-05-01') ENGINE = InnoDB,
 PARTITION p202505 VALUES LESS THAN ('2025-06-01') ENGINE = InnoDB,
 PARTITION p202506 VALUES LESS THAN ('2025-07-01') ENGINE = InnoDB,
 PARTITION p202507 VALUES LESS THAN ('2025-08-01') ENGINE = InnoDB,
 PARTITION p202508 VALUES LESS THAN ('2025-09-01') ENGINE = InnoDB,
 PARTITION p202509 VALUES LESS THAN ('2025-10-01') ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN ('2025-11-01') ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN ('2025-12-01') ENGINE = InnoDB,
 PARTITION p202512 VALUES LESS THAN ('2026-01-01') ENGINE = InnoDB,
 PARTITION p202601 VALUES LESS THAN ('2026-02-01') ENGINE = InnoDB,
 PARTITION p202602 VALUES LESS THAN ('2026-03-01') ENGINE = InnoDB,
 PARTITION p202603 VALUES LESS THAN ('2026-04-01') ENGINE = InnoDB,
 PARTITION p202604 VALUES LESS THAN ('2026-05-01') ENGINE = InnoDB,
 PARTITION p202605 VALUES LESS THAN ('2026-06-01') ENGINE = InnoDB,
 PARTITION p202606 VALUES LESS THAN ('2026-07-01') ENGINE = InnoDB,
 PARTITION p202607 VALUES LESS THAN ('2026-08-01') ENGINE = InnoDB,
 PARTITION p202608 VALUES LESS THAN ('2026-09-01') ENGINE = InnoDB,
 PARTITION p202609 VALUES LESS THAN ('2026-10-01') ENGINE = InnoDB,
 PARTITION p202610 VALUES LESS THAN ('2026-11-01') ENGINE = InnoDB,
 PARTITION p202611 VALUES LESS THAN ('2026-12-01') ENGINE = InnoDB,
 PARTITION p202612 VALUES LESS THAN ('2027-01-01') ENGINE = InnoDB,
 PARTITION p202701 VALUES LESS THAN ('2027-02-01') ENGINE = InnoDB,
 PARTITION p202702 VALUES LESS THAN ('2027-03-01') ENGINE = InnoDB,
 PARTITION p202703 VALUES LESS THAN ('2027-04-01') ENGINE = InnoDB,
 PARTITION p202704 VALUES LESS THAN ('2027-05-01') ENGINE = InnoDB,
 PARTITION p202705 VALUES LESS THAN ('2027-06-01') ENGINE = InnoDB,
 PARTITION p202706 VALUES LESS THAN ('2027-07-01') ENGINE = InnoDB,
 PARTITION p202707 VALUES LESS THAN ('2027-08-01') ENGINE = InnoDB,
 PARTITION p202708 VALUES LESS THAN ('2027-09-01') ENGINE = InnoDB,
 PARTITION p202709 VALUES LESS THAN ('2027-10-01') ENGINE = InnoDB,
 PARTITION p202710 VALUES LESS THAN ('2027-11-01') ENGINE = InnoDB,
 PARTITION p202711 VALUES LESS THAN ('2027-12-01') ENGINE = InnoDB,
 PARTITION p202712 VALUES LESS THAN ('2028-01-01') ENGINE = InnoDB,
 PARTITION p202801 VALUES LESS THAN ('2028-02-01') ENGINE = InnoDB,
 PARTITION p202802 VALUES LESS THAN ('2028-03-01') ENGINE = InnoDB,
 PARTITION p202803 VALUES LESS THAN ('2028-04-01') ENGINE = InnoDB,
 PARTITION p202804 VALUES LESS THAN ('2028-05-01') ENGINE = InnoDB,
 PARTITION p202805 VALUES LESS THAN ('2028-06-01') ENGINE = InnoDB,
 PARTITION p202806 VALUES LESS THAN ('2028-07-01') ENGINE = InnoDB,
 PARTITION p202807 VALUES LESS THAN ('2028-08-01') ENGINE = InnoDB,
 PARTITION p202808 VALUES LESS THAN ('2028-09-01') ENGINE = InnoDB,
 PARTITION p202809 VALUES LESS THAN ('2028-10-01') ENGINE = InnoDB,
 PARTITION p202810 VALUES LESS THAN ('2028-11-01') ENGINE = InnoDB,
 PARTITION p202811 VALUES LESS THAN ('2028-12-01') ENGINE = InnoDB,
 PARTITION p202812 VALUES LESS THAN ('2029-01-01') ENGINE = InnoDB,
 PARTITION p202901 VALUES LESS THAN ('2029-02-01') ENGINE = InnoDB,
 PARTITION p202902 VALUES LESS THAN ('2029-03-01') ENGINE = InnoDB,
 PARTITION p202903 VALUES LESS THAN ('2029-04-01') ENGINE = InnoDB,
 PARTITION p202904 VALUES LESS THAN ('2029-05-01') ENGINE = InnoDB,
 PARTITION p202905 VALUES LESS THAN ('2029-06-01') ENGINE = InnoDB,
 PARTITION p202906 VALUES LESS THAN ('2029-07-01') ENGINE = InnoDB,
 PARTITION p202907 VALUES LESS THAN ('2029-08-01') ENGINE = InnoDB,
 PARTITION p202908 VALUES LESS THAN ('2029-09-01') ENGINE = InnoDB,
 PARTITION p202909 VALUES LESS THAN ('2029-10-01') ENGINE = InnoDB,
 PARTITION p202910 VALUES LESS THAN ('2029-11-01') ENGINE = InnoDB,
 PARTITION p202911 VALUES LESS THAN ('2029-12-01') ENGINE = InnoDB,
 PARTITION p202912 VALUES LESS THAN ('2030-01-01') ENGINE = InnoDB,
 PARTITION p203001 VALUES LESS THAN ('2030-02-01') ENGINE = InnoDB,
 PARTITION p203002 VALUES LESS THAN ('2030-03-01') ENGINE = InnoDB,
 PARTITION p203003 VALUES LESS THAN ('2030-04-01') ENGINE = InnoDB,
 PARTITION p203004 VALUES LESS THAN ('2030-05-01') ENGINE = InnoDB,
 PARTITION p203005 VALUES LESS THAN ('2030-06-01') ENGINE = InnoDB,
 PARTITION p203006 VALUES LESS THAN ('2030-07-01') ENGINE = InnoDB,
 PARTITION p203007 VALUES LESS THAN ('2030-08-01') ENGINE = InnoDB,
 PARTITION p203008 VALUES LESS THAN ('2030-09-01') ENGINE = InnoDB,
 PARTITION p203009 VALUES LESS THAN ('2030-10-01') ENGINE = InnoDB,
 PARTITION p203010 VALUES LESS THAN ('2030-11-01') ENGINE = InnoDB,
 PARTITION p203011 VALUES LESS THAN ('2030-12-01') ENGINE = InnoDB,
 PARTITION p203012 VALUES LESS THAN ('2031-01-01') ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_push_quest_lot_lists`
--

DROP TABLE IF EXISTS `log_push_quest_lot_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_push_quest_lot_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プッシュクエスト獲得ログ',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `push_quest_list_id` int(11) NOT NULL COMMENT 'プッシュクエストリストID',
  `lot_list_id` int(11) NOT NULL COMMENT '抽選ID',
  `lot_num` int(11) NOT NULL COMMENT '抽選回数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`,`created_at`),
  KEY `idx_log_push_quest_lot_lists_1` (`event_id`,`lot_list_id`,`push_quest_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='プッシュクエスト獲得ログ'
/*!50500 PARTITION BY RANGE  COLUMNS(created_at)
(PARTITION p201512 VALUES LESS THAN ('2016-01-01') ENGINE = InnoDB,
 PARTITION p201601 VALUES LESS THAN ('2016-02-01') ENGINE = InnoDB,
 PARTITION p201602 VALUES LESS THAN ('2016-03-01') ENGINE = InnoDB,
 PARTITION p201603 VALUES LESS THAN ('2016-04-01') ENGINE = InnoDB,
 PARTITION p201604 VALUES LESS THAN ('2016-05-01') ENGINE = InnoDB,
 PARTITION p201605 VALUES LESS THAN ('2016-06-01') ENGINE = InnoDB,
 PARTITION p201606 VALUES LESS THAN ('2016-07-01') ENGINE = InnoDB,
 PARTITION p201607 VALUES LESS THAN ('2016-08-01') ENGINE = InnoDB,
 PARTITION p201608 VALUES LESS THAN ('2016-09-01') ENGINE = InnoDB,
 PARTITION p201609 VALUES LESS THAN ('2016-10-01') ENGINE = InnoDB,
 PARTITION p201610 VALUES LESS THAN ('2016-11-01') ENGINE = InnoDB,
 PARTITION p201611 VALUES LESS THAN ('2016-12-01') ENGINE = InnoDB,
 PARTITION p201612 VALUES LESS THAN ('2017-01-01') ENGINE = InnoDB,
 PARTITION p201701 VALUES LESS THAN ('2017-02-01') ENGINE = InnoDB,
 PARTITION p201702 VALUES LESS THAN ('2017-03-01') ENGINE = InnoDB,
 PARTITION p201703 VALUES LESS THAN ('2017-04-01') ENGINE = InnoDB,
 PARTITION p201704 VALUES LESS THAN ('2017-05-01') ENGINE = InnoDB,
 PARTITION p201705 VALUES LESS THAN ('2017-06-01') ENGINE = InnoDB,
 PARTITION p201706 VALUES LESS THAN ('2017-07-01') ENGINE = InnoDB,
 PARTITION p201707 VALUES LESS THAN ('2017-08-01') ENGINE = InnoDB,
 PARTITION p201708 VALUES LESS THAN ('2017-09-01') ENGINE = InnoDB,
 PARTITION p201709 VALUES LESS THAN ('2017-10-01') ENGINE = InnoDB,
 PARTITION p201710 VALUES LESS THAN ('2017-11-01') ENGINE = InnoDB,
 PARTITION p201711 VALUES LESS THAN ('2017-12-01') ENGINE = InnoDB,
 PARTITION p201712 VALUES LESS THAN ('2018-01-01') ENGINE = InnoDB,
 PARTITION p201801 VALUES LESS THAN ('2018-02-01') ENGINE = InnoDB,
 PARTITION p201802 VALUES LESS THAN ('2018-03-01') ENGINE = InnoDB,
 PARTITION p201803 VALUES LESS THAN ('2018-04-01') ENGINE = InnoDB,
 PARTITION p201804 VALUES LESS THAN ('2018-05-01') ENGINE = InnoDB,
 PARTITION p201805 VALUES LESS THAN ('2018-06-01') ENGINE = InnoDB,
 PARTITION p201806 VALUES LESS THAN ('2018-07-01') ENGINE = InnoDB,
 PARTITION p201807 VALUES LESS THAN ('2018-08-01') ENGINE = InnoDB,
 PARTITION p201808 VALUES LESS THAN ('2018-09-01') ENGINE = InnoDB,
 PARTITION p201809 VALUES LESS THAN ('2018-10-01') ENGINE = InnoDB,
 PARTITION p201810 VALUES LESS THAN ('2018-11-01') ENGINE = InnoDB,
 PARTITION p201811 VALUES LESS THAN ('2018-12-01') ENGINE = InnoDB,
 PARTITION p201812 VALUES LESS THAN ('2019-01-01') ENGINE = InnoDB,
 PARTITION p201901 VALUES LESS THAN ('2019-02-01') ENGINE = InnoDB,
 PARTITION p201902 VALUES LESS THAN ('2019-03-01') ENGINE = InnoDB,
 PARTITION p201903 VALUES LESS THAN ('2019-04-01') ENGINE = InnoDB,
 PARTITION p201904 VALUES LESS THAN ('2019-05-01') ENGINE = InnoDB,
 PARTITION p201905 VALUES LESS THAN ('2019-06-01') ENGINE = InnoDB,
 PARTITION p201906 VALUES LESS THAN ('2019-07-01') ENGINE = InnoDB,
 PARTITION p201907 VALUES LESS THAN ('2019-08-01') ENGINE = InnoDB,
 PARTITION p201908 VALUES LESS THAN ('2019-09-01') ENGINE = InnoDB,
 PARTITION p201909 VALUES LESS THAN ('2019-10-01') ENGINE = InnoDB,
 PARTITION p201910 VALUES LESS THAN ('2019-11-01') ENGINE = InnoDB,
 PARTITION p201911 VALUES LESS THAN ('2019-12-01') ENGINE = InnoDB,
 PARTITION p201912 VALUES LESS THAN ('2020-01-01') ENGINE = InnoDB,
 PARTITION p202001 VALUES LESS THAN ('2020-02-01') ENGINE = InnoDB,
 PARTITION p202002 VALUES LESS THAN ('2020-03-01') ENGINE = InnoDB,
 PARTITION p202003 VALUES LESS THAN ('2020-04-01') ENGINE = InnoDB,
 PARTITION p202004 VALUES LESS THAN ('2020-05-01') ENGINE = InnoDB,
 PARTITION p202005 VALUES LESS THAN ('2020-06-01') ENGINE = InnoDB,
 PARTITION p202006 VALUES LESS THAN ('2020-07-01') ENGINE = InnoDB,
 PARTITION p202007 VALUES LESS THAN ('2020-08-01') ENGINE = InnoDB,
 PARTITION p202008 VALUES LESS THAN ('2020-09-01') ENGINE = InnoDB,
 PARTITION p202009 VALUES LESS THAN ('2020-10-01') ENGINE = InnoDB,
 PARTITION p202010 VALUES LESS THAN ('2020-11-01') ENGINE = InnoDB,
 PARTITION p202011 VALUES LESS THAN ('2020-12-01') ENGINE = InnoDB,
 PARTITION p202012 VALUES LESS THAN ('2021-01-01') ENGINE = InnoDB,
 PARTITION p202101 VALUES LESS THAN ('2021-02-01') ENGINE = InnoDB,
 PARTITION p202102 VALUES LESS THAN ('2021-03-01') ENGINE = InnoDB,
 PARTITION p202103 VALUES LESS THAN ('2021-04-01') ENGINE = InnoDB,
 PARTITION p202104 VALUES LESS THAN ('2021-05-01') ENGINE = InnoDB,
 PARTITION p202105 VALUES LESS THAN ('2021-06-01') ENGINE = InnoDB,
 PARTITION p202106 VALUES LESS THAN ('2021-07-01') ENGINE = InnoDB,
 PARTITION p202107 VALUES LESS THAN ('2021-08-01') ENGINE = InnoDB,
 PARTITION p202108 VALUES LESS THAN ('2021-09-01') ENGINE = InnoDB,
 PARTITION p202109 VALUES LESS THAN ('2021-10-01') ENGINE = InnoDB,
 PARTITION p202110 VALUES LESS THAN ('2021-11-01') ENGINE = InnoDB,
 PARTITION p202111 VALUES LESS THAN ('2021-12-01') ENGINE = InnoDB,
 PARTITION p202112 VALUES LESS THAN ('2022-01-01') ENGINE = InnoDB,
 PARTITION p202201 VALUES LESS THAN ('2022-02-01') ENGINE = InnoDB,
 PARTITION p202202 VALUES LESS THAN ('2022-03-01') ENGINE = InnoDB,
 PARTITION p202203 VALUES LESS THAN ('2022-04-01') ENGINE = InnoDB,
 PARTITION p202204 VALUES LESS THAN ('2022-05-01') ENGINE = InnoDB,
 PARTITION p202205 VALUES LESS THAN ('2022-06-01') ENGINE = InnoDB,
 PARTITION p202206 VALUES LESS THAN ('2022-07-01') ENGINE = InnoDB,
 PARTITION p202207 VALUES LESS THAN ('2022-08-01') ENGINE = InnoDB,
 PARTITION p202208 VALUES LESS THAN ('2022-09-01') ENGINE = InnoDB,
 PARTITION p202209 VALUES LESS THAN ('2022-10-01') ENGINE = InnoDB,
 PARTITION p202210 VALUES LESS THAN ('2022-11-01') ENGINE = InnoDB,
 PARTITION p202211 VALUES LESS THAN ('2022-12-01') ENGINE = InnoDB,
 PARTITION p202212 VALUES LESS THAN ('2023-01-01') ENGINE = InnoDB,
 PARTITION p202301 VALUES LESS THAN ('2023-02-01') ENGINE = InnoDB,
 PARTITION p202302 VALUES LESS THAN ('2023-03-01') ENGINE = InnoDB,
 PARTITION p202303 VALUES LESS THAN ('2023-04-01') ENGINE = InnoDB,
 PARTITION p202304 VALUES LESS THAN ('2023-05-01') ENGINE = InnoDB,
 PARTITION p202305 VALUES LESS THAN ('2023-06-01') ENGINE = InnoDB,
 PARTITION p202306 VALUES LESS THAN ('2023-07-01') ENGINE = InnoDB,
 PARTITION p202307 VALUES LESS THAN ('2023-08-01') ENGINE = InnoDB,
 PARTITION p202308 VALUES LESS THAN ('2023-09-01') ENGINE = InnoDB,
 PARTITION p202309 VALUES LESS THAN ('2023-10-01') ENGINE = InnoDB,
 PARTITION p202310 VALUES LESS THAN ('2023-11-01') ENGINE = InnoDB,
 PARTITION p202311 VALUES LESS THAN ('2023-12-01') ENGINE = InnoDB,
 PARTITION p202312 VALUES LESS THAN ('2024-01-01') ENGINE = InnoDB,
 PARTITION p202401 VALUES LESS THAN ('2024-02-01') ENGINE = InnoDB,
 PARTITION p202402 VALUES LESS THAN ('2024-03-01') ENGINE = InnoDB,
 PARTITION p202403 VALUES LESS THAN ('2024-04-01') ENGINE = InnoDB,
 PARTITION p202404 VALUES LESS THAN ('2024-05-01') ENGINE = InnoDB,
 PARTITION p202405 VALUES LESS THAN ('2024-06-01') ENGINE = InnoDB,
 PARTITION p202406 VALUES LESS THAN ('2024-07-01') ENGINE = InnoDB,
 PARTITION p202407 VALUES LESS THAN ('2024-08-01') ENGINE = InnoDB,
 PARTITION p202408 VALUES LESS THAN ('2024-09-01') ENGINE = InnoDB,
 PARTITION p202409 VALUES LESS THAN ('2024-10-01') ENGINE = InnoDB,
 PARTITION p202410 VALUES LESS THAN ('2024-11-01') ENGINE = InnoDB,
 PARTITION p202411 VALUES LESS THAN ('2024-12-01') ENGINE = InnoDB,
 PARTITION p202412 VALUES LESS THAN ('2025-01-01') ENGINE = InnoDB,
 PARTITION p202501 VALUES LESS THAN ('2025-02-01') ENGINE = InnoDB,
 PARTITION p202502 VALUES LESS THAN ('2025-03-01') ENGINE = InnoDB,
 PARTITION p202503 VALUES LESS THAN ('2025-04-01') ENGINE = InnoDB,
 PARTITION p202504 VALUES LESS THAN ('2025-05-01') ENGINE = InnoDB,
 PARTITION p202505 VALUES LESS THAN ('2025-06-01') ENGINE = InnoDB,
 PARTITION p202506 VALUES LESS THAN ('2025-07-01') ENGINE = InnoDB,
 PARTITION p202507 VALUES LESS THAN ('2025-08-01') ENGINE = InnoDB,
 PARTITION p202508 VALUES LESS THAN ('2025-09-01') ENGINE = InnoDB,
 PARTITION p202509 VALUES LESS THAN ('2025-10-01') ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN ('2025-11-01') ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN ('2025-12-01') ENGINE = InnoDB,
 PARTITION p202512 VALUES LESS THAN ('2026-01-01') ENGINE = InnoDB,
 PARTITION p202601 VALUES LESS THAN ('2026-02-01') ENGINE = InnoDB,
 PARTITION p202602 VALUES LESS THAN ('2026-03-01') ENGINE = InnoDB,
 PARTITION p202603 VALUES LESS THAN ('2026-04-01') ENGINE = InnoDB,
 PARTITION p202604 VALUES LESS THAN ('2026-05-01') ENGINE = InnoDB,
 PARTITION p202605 VALUES LESS THAN ('2026-06-01') ENGINE = InnoDB,
 PARTITION p202606 VALUES LESS THAN ('2026-07-01') ENGINE = InnoDB,
 PARTITION p202607 VALUES LESS THAN ('2026-08-01') ENGINE = InnoDB,
 PARTITION p202608 VALUES LESS THAN ('2026-09-01') ENGINE = InnoDB,
 PARTITION p202609 VALUES LESS THAN ('2026-10-01') ENGINE = InnoDB,
 PARTITION p202610 VALUES LESS THAN ('2026-11-01') ENGINE = InnoDB,
 PARTITION p202611 VALUES LESS THAN ('2026-12-01') ENGINE = InnoDB,
 PARTITION p202612 VALUES LESS THAN ('2027-01-01') ENGINE = InnoDB,
 PARTITION p202701 VALUES LESS THAN ('2027-02-01') ENGINE = InnoDB,
 PARTITION p202702 VALUES LESS THAN ('2027-03-01') ENGINE = InnoDB,
 PARTITION p202703 VALUES LESS THAN ('2027-04-01') ENGINE = InnoDB,
 PARTITION p202704 VALUES LESS THAN ('2027-05-01') ENGINE = InnoDB,
 PARTITION p202705 VALUES LESS THAN ('2027-06-01') ENGINE = InnoDB,
 PARTITION p202706 VALUES LESS THAN ('2027-07-01') ENGINE = InnoDB,
 PARTITION p202707 VALUES LESS THAN ('2027-08-01') ENGINE = InnoDB,
 PARTITION p202708 VALUES LESS THAN ('2027-09-01') ENGINE = InnoDB,
 PARTITION p202709 VALUES LESS THAN ('2027-10-01') ENGINE = InnoDB,
 PARTITION p202710 VALUES LESS THAN ('2027-11-01') ENGINE = InnoDB,
 PARTITION p202711 VALUES LESS THAN ('2027-12-01') ENGINE = InnoDB,
 PARTITION p202712 VALUES LESS THAN ('2028-01-01') ENGINE = InnoDB,
 PARTITION p202801 VALUES LESS THAN ('2028-02-01') ENGINE = InnoDB,
 PARTITION p202802 VALUES LESS THAN ('2028-03-01') ENGINE = InnoDB,
 PARTITION p202803 VALUES LESS THAN ('2028-04-01') ENGINE = InnoDB,
 PARTITION p202804 VALUES LESS THAN ('2028-05-01') ENGINE = InnoDB,
 PARTITION p202805 VALUES LESS THAN ('2028-06-01') ENGINE = InnoDB,
 PARTITION p202806 VALUES LESS THAN ('2028-07-01') ENGINE = InnoDB,
 PARTITION p202807 VALUES LESS THAN ('2028-08-01') ENGINE = InnoDB,
 PARTITION p202808 VALUES LESS THAN ('2028-09-01') ENGINE = InnoDB,
 PARTITION p202809 VALUES LESS THAN ('2028-10-01') ENGINE = InnoDB,
 PARTITION p202810 VALUES LESS THAN ('2028-11-01') ENGINE = InnoDB,
 PARTITION p202811 VALUES LESS THAN ('2028-12-01') ENGINE = InnoDB,
 PARTITION p202812 VALUES LESS THAN ('2029-01-01') ENGINE = InnoDB,
 PARTITION p202901 VALUES LESS THAN ('2029-02-01') ENGINE = InnoDB,
 PARTITION p202902 VALUES LESS THAN ('2029-03-01') ENGINE = InnoDB,
 PARTITION p202903 VALUES LESS THAN ('2029-04-01') ENGINE = InnoDB,
 PARTITION p202904 VALUES LESS THAN ('2029-05-01') ENGINE = InnoDB,
 PARTITION p202905 VALUES LESS THAN ('2029-06-01') ENGINE = InnoDB,
 PARTITION p202906 VALUES LESS THAN ('2029-07-01') ENGINE = InnoDB,
 PARTITION p202907 VALUES LESS THAN ('2029-08-01') ENGINE = InnoDB,
 PARTITION p202908 VALUES LESS THAN ('2029-09-01') ENGINE = InnoDB,
 PARTITION p202909 VALUES LESS THAN ('2029-10-01') ENGINE = InnoDB,
 PARTITION p202910 VALUES LESS THAN ('2029-11-01') ENGINE = InnoDB,
 PARTITION p202911 VALUES LESS THAN ('2029-12-01') ENGINE = InnoDB,
 PARTITION p202912 VALUES LESS THAN ('2030-01-01') ENGINE = InnoDB,
 PARTITION p203001 VALUES LESS THAN ('2030-02-01') ENGINE = InnoDB,
 PARTITION p203002 VALUES LESS THAN ('2030-03-01') ENGINE = InnoDB,
 PARTITION p203003 VALUES LESS THAN ('2030-04-01') ENGINE = InnoDB,
 PARTITION p203004 VALUES LESS THAN ('2030-05-01') ENGINE = InnoDB,
 PARTITION p203005 VALUES LESS THAN ('2030-06-01') ENGINE = InnoDB,
 PARTITION p203006 VALUES LESS THAN ('2030-07-01') ENGINE = InnoDB,
 PARTITION p203007 VALUES LESS THAN ('2030-08-01') ENGINE = InnoDB,
 PARTITION p203008 VALUES LESS THAN ('2030-09-01') ENGINE = InnoDB,
 PARTITION p203009 VALUES LESS THAN ('2030-10-01') ENGINE = InnoDB,
 PARTITION p203010 VALUES LESS THAN ('2030-11-01') ENGINE = InnoDB,
 PARTITION p203011 VALUES LESS THAN ('2030-12-01') ENGINE = InnoDB,
 PARTITION p203012 VALUES LESS THAN ('2031-01-01') ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_stamps`
--

DROP TABLE IF EXISTS `log_stamps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_stamps` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '仕入れ待ちログID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `stamp_id` int(11) NOT NULL COMMENT 'スタンプID',
  `count_value` int(11) NOT NULL COMMENT '獲得数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`,`created_at`),
  KEY `idx_log_stamps_1` (`event_id`,`stamp_id`,`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='スタンプログ'
/*!50500 PARTITION BY RANGE  COLUMNS(created_at)
(PARTITION p201512 VALUES LESS THAN ('2016-01-01') ENGINE = InnoDB,
 PARTITION p201601 VALUES LESS THAN ('2016-02-01') ENGINE = InnoDB,
 PARTITION p201602 VALUES LESS THAN ('2016-03-01') ENGINE = InnoDB,
 PARTITION p201603 VALUES LESS THAN ('2016-04-01') ENGINE = InnoDB,
 PARTITION p201604 VALUES LESS THAN ('2016-05-01') ENGINE = InnoDB,
 PARTITION p201605 VALUES LESS THAN ('2016-06-01') ENGINE = InnoDB,
 PARTITION p201606 VALUES LESS THAN ('2016-07-01') ENGINE = InnoDB,
 PARTITION p201607 VALUES LESS THAN ('2016-08-01') ENGINE = InnoDB,
 PARTITION p201608 VALUES LESS THAN ('2016-09-01') ENGINE = InnoDB,
 PARTITION p201609 VALUES LESS THAN ('2016-10-01') ENGINE = InnoDB,
 PARTITION p201610 VALUES LESS THAN ('2016-11-01') ENGINE = InnoDB,
 PARTITION p201611 VALUES LESS THAN ('2016-12-01') ENGINE = InnoDB,
 PARTITION p201612 VALUES LESS THAN ('2017-01-01') ENGINE = InnoDB,
 PARTITION p201701 VALUES LESS THAN ('2017-02-01') ENGINE = InnoDB,
 PARTITION p201702 VALUES LESS THAN ('2017-03-01') ENGINE = InnoDB,
 PARTITION p201703 VALUES LESS THAN ('2017-04-01') ENGINE = InnoDB,
 PARTITION p201704 VALUES LESS THAN ('2017-05-01') ENGINE = InnoDB,
 PARTITION p201705 VALUES LESS THAN ('2017-06-01') ENGINE = InnoDB,
 PARTITION p201706 VALUES LESS THAN ('2017-07-01') ENGINE = InnoDB,
 PARTITION p201707 VALUES LESS THAN ('2017-08-01') ENGINE = InnoDB,
 PARTITION p201708 VALUES LESS THAN ('2017-09-01') ENGINE = InnoDB,
 PARTITION p201709 VALUES LESS THAN ('2017-10-01') ENGINE = InnoDB,
 PARTITION p201710 VALUES LESS THAN ('2017-11-01') ENGINE = InnoDB,
 PARTITION p201711 VALUES LESS THAN ('2017-12-01') ENGINE = InnoDB,
 PARTITION p201712 VALUES LESS THAN ('2018-01-01') ENGINE = InnoDB,
 PARTITION p201801 VALUES LESS THAN ('2018-02-01') ENGINE = InnoDB,
 PARTITION p201802 VALUES LESS THAN ('2018-03-01') ENGINE = InnoDB,
 PARTITION p201803 VALUES LESS THAN ('2018-04-01') ENGINE = InnoDB,
 PARTITION p201804 VALUES LESS THAN ('2018-05-01') ENGINE = InnoDB,
 PARTITION p201805 VALUES LESS THAN ('2018-06-01') ENGINE = InnoDB,
 PARTITION p201806 VALUES LESS THAN ('2018-07-01') ENGINE = InnoDB,
 PARTITION p201807 VALUES LESS THAN ('2018-08-01') ENGINE = InnoDB,
 PARTITION p201808 VALUES LESS THAN ('2018-09-01') ENGINE = InnoDB,
 PARTITION p201809 VALUES LESS THAN ('2018-10-01') ENGINE = InnoDB,
 PARTITION p201810 VALUES LESS THAN ('2018-11-01') ENGINE = InnoDB,
 PARTITION p201811 VALUES LESS THAN ('2018-12-01') ENGINE = InnoDB,
 PARTITION p201812 VALUES LESS THAN ('2019-01-01') ENGINE = InnoDB,
 PARTITION p201901 VALUES LESS THAN ('2019-02-01') ENGINE = InnoDB,
 PARTITION p201902 VALUES LESS THAN ('2019-03-01') ENGINE = InnoDB,
 PARTITION p201903 VALUES LESS THAN ('2019-04-01') ENGINE = InnoDB,
 PARTITION p201904 VALUES LESS THAN ('2019-05-01') ENGINE = InnoDB,
 PARTITION p201905 VALUES LESS THAN ('2019-06-01') ENGINE = InnoDB,
 PARTITION p201906 VALUES LESS THAN ('2019-07-01') ENGINE = InnoDB,
 PARTITION p201907 VALUES LESS THAN ('2019-08-01') ENGINE = InnoDB,
 PARTITION p201908 VALUES LESS THAN ('2019-09-01') ENGINE = InnoDB,
 PARTITION p201909 VALUES LESS THAN ('2019-10-01') ENGINE = InnoDB,
 PARTITION p201910 VALUES LESS THAN ('2019-11-01') ENGINE = InnoDB,
 PARTITION p201911 VALUES LESS THAN ('2019-12-01') ENGINE = InnoDB,
 PARTITION p201912 VALUES LESS THAN ('2020-01-01') ENGINE = InnoDB,
 PARTITION p202001 VALUES LESS THAN ('2020-02-01') ENGINE = InnoDB,
 PARTITION p202002 VALUES LESS THAN ('2020-03-01') ENGINE = InnoDB,
 PARTITION p202003 VALUES LESS THAN ('2020-04-01') ENGINE = InnoDB,
 PARTITION p202004 VALUES LESS THAN ('2020-05-01') ENGINE = InnoDB,
 PARTITION p202005 VALUES LESS THAN ('2020-06-01') ENGINE = InnoDB,
 PARTITION p202006 VALUES LESS THAN ('2020-07-01') ENGINE = InnoDB,
 PARTITION p202007 VALUES LESS THAN ('2020-08-01') ENGINE = InnoDB,
 PARTITION p202008 VALUES LESS THAN ('2020-09-01') ENGINE = InnoDB,
 PARTITION p202009 VALUES LESS THAN ('2020-10-01') ENGINE = InnoDB,
 PARTITION p202010 VALUES LESS THAN ('2020-11-01') ENGINE = InnoDB,
 PARTITION p202011 VALUES LESS THAN ('2020-12-01') ENGINE = InnoDB,
 PARTITION p202012 VALUES LESS THAN ('2021-01-01') ENGINE = InnoDB,
 PARTITION p202101 VALUES LESS THAN ('2021-02-01') ENGINE = InnoDB,
 PARTITION p202102 VALUES LESS THAN ('2021-03-01') ENGINE = InnoDB,
 PARTITION p202103 VALUES LESS THAN ('2021-04-01') ENGINE = InnoDB,
 PARTITION p202104 VALUES LESS THAN ('2021-05-01') ENGINE = InnoDB,
 PARTITION p202105 VALUES LESS THAN ('2021-06-01') ENGINE = InnoDB,
 PARTITION p202106 VALUES LESS THAN ('2021-07-01') ENGINE = InnoDB,
 PARTITION p202107 VALUES LESS THAN ('2021-08-01') ENGINE = InnoDB,
 PARTITION p202108 VALUES LESS THAN ('2021-09-01') ENGINE = InnoDB,
 PARTITION p202109 VALUES LESS THAN ('2021-10-01') ENGINE = InnoDB,
 PARTITION p202110 VALUES LESS THAN ('2021-11-01') ENGINE = InnoDB,
 PARTITION p202111 VALUES LESS THAN ('2021-12-01') ENGINE = InnoDB,
 PARTITION p202112 VALUES LESS THAN ('2022-01-01') ENGINE = InnoDB,
 PARTITION p202201 VALUES LESS THAN ('2022-02-01') ENGINE = InnoDB,
 PARTITION p202202 VALUES LESS THAN ('2022-03-01') ENGINE = InnoDB,
 PARTITION p202203 VALUES LESS THAN ('2022-04-01') ENGINE = InnoDB,
 PARTITION p202204 VALUES LESS THAN ('2022-05-01') ENGINE = InnoDB,
 PARTITION p202205 VALUES LESS THAN ('2022-06-01') ENGINE = InnoDB,
 PARTITION p202206 VALUES LESS THAN ('2022-07-01') ENGINE = InnoDB,
 PARTITION p202207 VALUES LESS THAN ('2022-08-01') ENGINE = InnoDB,
 PARTITION p202208 VALUES LESS THAN ('2022-09-01') ENGINE = InnoDB,
 PARTITION p202209 VALUES LESS THAN ('2022-10-01') ENGINE = InnoDB,
 PARTITION p202210 VALUES LESS THAN ('2022-11-01') ENGINE = InnoDB,
 PARTITION p202211 VALUES LESS THAN ('2022-12-01') ENGINE = InnoDB,
 PARTITION p202212 VALUES LESS THAN ('2023-01-01') ENGINE = InnoDB,
 PARTITION p202301 VALUES LESS THAN ('2023-02-01') ENGINE = InnoDB,
 PARTITION p202302 VALUES LESS THAN ('2023-03-01') ENGINE = InnoDB,
 PARTITION p202303 VALUES LESS THAN ('2023-04-01') ENGINE = InnoDB,
 PARTITION p202304 VALUES LESS THAN ('2023-05-01') ENGINE = InnoDB,
 PARTITION p202305 VALUES LESS THAN ('2023-06-01') ENGINE = InnoDB,
 PARTITION p202306 VALUES LESS THAN ('2023-07-01') ENGINE = InnoDB,
 PARTITION p202307 VALUES LESS THAN ('2023-08-01') ENGINE = InnoDB,
 PARTITION p202308 VALUES LESS THAN ('2023-09-01') ENGINE = InnoDB,
 PARTITION p202309 VALUES LESS THAN ('2023-10-01') ENGINE = InnoDB,
 PARTITION p202310 VALUES LESS THAN ('2023-11-01') ENGINE = InnoDB,
 PARTITION p202311 VALUES LESS THAN ('2023-12-01') ENGINE = InnoDB,
 PARTITION p202312 VALUES LESS THAN ('2024-01-01') ENGINE = InnoDB,
 PARTITION p202401 VALUES LESS THAN ('2024-02-01') ENGINE = InnoDB,
 PARTITION p202402 VALUES LESS THAN ('2024-03-01') ENGINE = InnoDB,
 PARTITION p202403 VALUES LESS THAN ('2024-04-01') ENGINE = InnoDB,
 PARTITION p202404 VALUES LESS THAN ('2024-05-01') ENGINE = InnoDB,
 PARTITION p202405 VALUES LESS THAN ('2024-06-01') ENGINE = InnoDB,
 PARTITION p202406 VALUES LESS THAN ('2024-07-01') ENGINE = InnoDB,
 PARTITION p202407 VALUES LESS THAN ('2024-08-01') ENGINE = InnoDB,
 PARTITION p202408 VALUES LESS THAN ('2024-09-01') ENGINE = InnoDB,
 PARTITION p202409 VALUES LESS THAN ('2024-10-01') ENGINE = InnoDB,
 PARTITION p202410 VALUES LESS THAN ('2024-11-01') ENGINE = InnoDB,
 PARTITION p202411 VALUES LESS THAN ('2024-12-01') ENGINE = InnoDB,
 PARTITION p202412 VALUES LESS THAN ('2025-01-01') ENGINE = InnoDB,
 PARTITION p202501 VALUES LESS THAN ('2025-02-01') ENGINE = InnoDB,
 PARTITION p202502 VALUES LESS THAN ('2025-03-01') ENGINE = InnoDB,
 PARTITION p202503 VALUES LESS THAN ('2025-04-01') ENGINE = InnoDB,
 PARTITION p202504 VALUES LESS THAN ('2025-05-01') ENGINE = InnoDB,
 PARTITION p202505 VALUES LESS THAN ('2025-06-01') ENGINE = InnoDB,
 PARTITION p202506 VALUES LESS THAN ('2025-07-01') ENGINE = InnoDB,
 PARTITION p202507 VALUES LESS THAN ('2025-08-01') ENGINE = InnoDB,
 PARTITION p202508 VALUES LESS THAN ('2025-09-01') ENGINE = InnoDB,
 PARTITION p202509 VALUES LESS THAN ('2025-10-01') ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN ('2025-11-01') ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN ('2025-12-01') ENGINE = InnoDB,
 PARTITION p202512 VALUES LESS THAN ('2026-01-01') ENGINE = InnoDB,
 PARTITION p202601 VALUES LESS THAN ('2026-02-01') ENGINE = InnoDB,
 PARTITION p202602 VALUES LESS THAN ('2026-03-01') ENGINE = InnoDB,
 PARTITION p202603 VALUES LESS THAN ('2026-04-01') ENGINE = InnoDB,
 PARTITION p202604 VALUES LESS THAN ('2026-05-01') ENGINE = InnoDB,
 PARTITION p202605 VALUES LESS THAN ('2026-06-01') ENGINE = InnoDB,
 PARTITION p202606 VALUES LESS THAN ('2026-07-01') ENGINE = InnoDB,
 PARTITION p202607 VALUES LESS THAN ('2026-08-01') ENGINE = InnoDB,
 PARTITION p202608 VALUES LESS THAN ('2026-09-01') ENGINE = InnoDB,
 PARTITION p202609 VALUES LESS THAN ('2026-10-01') ENGINE = InnoDB,
 PARTITION p202610 VALUES LESS THAN ('2026-11-01') ENGINE = InnoDB,
 PARTITION p202611 VALUES LESS THAN ('2026-12-01') ENGINE = InnoDB,
 PARTITION p202612 VALUES LESS THAN ('2027-01-01') ENGINE = InnoDB,
 PARTITION p202701 VALUES LESS THAN ('2027-02-01') ENGINE = InnoDB,
 PARTITION p202702 VALUES LESS THAN ('2027-03-01') ENGINE = InnoDB,
 PARTITION p202703 VALUES LESS THAN ('2027-04-01') ENGINE = InnoDB,
 PARTITION p202704 VALUES LESS THAN ('2027-05-01') ENGINE = InnoDB,
 PARTITION p202705 VALUES LESS THAN ('2027-06-01') ENGINE = InnoDB,
 PARTITION p202706 VALUES LESS THAN ('2027-07-01') ENGINE = InnoDB,
 PARTITION p202707 VALUES LESS THAN ('2027-08-01') ENGINE = InnoDB,
 PARTITION p202708 VALUES LESS THAN ('2027-09-01') ENGINE = InnoDB,
 PARTITION p202709 VALUES LESS THAN ('2027-10-01') ENGINE = InnoDB,
 PARTITION p202710 VALUES LESS THAN ('2027-11-01') ENGINE = InnoDB,
 PARTITION p202711 VALUES LESS THAN ('2027-12-01') ENGINE = InnoDB,
 PARTITION p202712 VALUES LESS THAN ('2028-01-01') ENGINE = InnoDB,
 PARTITION p202801 VALUES LESS THAN ('2028-02-01') ENGINE = InnoDB,
 PARTITION p202802 VALUES LESS THAN ('2028-03-01') ENGINE = InnoDB,
 PARTITION p202803 VALUES LESS THAN ('2028-04-01') ENGINE = InnoDB,
 PARTITION p202804 VALUES LESS THAN ('2028-05-01') ENGINE = InnoDB,
 PARTITION p202805 VALUES LESS THAN ('2028-06-01') ENGINE = InnoDB,
 PARTITION p202806 VALUES LESS THAN ('2028-07-01') ENGINE = InnoDB,
 PARTITION p202807 VALUES LESS THAN ('2028-08-01') ENGINE = InnoDB,
 PARTITION p202808 VALUES LESS THAN ('2028-09-01') ENGINE = InnoDB,
 PARTITION p202809 VALUES LESS THAN ('2028-10-01') ENGINE = InnoDB,
 PARTITION p202810 VALUES LESS THAN ('2028-11-01') ENGINE = InnoDB,
 PARTITION p202811 VALUES LESS THAN ('2028-12-01') ENGINE = InnoDB,
 PARTITION p202812 VALUES LESS THAN ('2029-01-01') ENGINE = InnoDB,
 PARTITION p202901 VALUES LESS THAN ('2029-02-01') ENGINE = InnoDB,
 PARTITION p202902 VALUES LESS THAN ('2029-03-01') ENGINE = InnoDB,
 PARTITION p202903 VALUES LESS THAN ('2029-04-01') ENGINE = InnoDB,
 PARTITION p202904 VALUES LESS THAN ('2029-05-01') ENGINE = InnoDB,
 PARTITION p202905 VALUES LESS THAN ('2029-06-01') ENGINE = InnoDB,
 PARTITION p202906 VALUES LESS THAN ('2029-07-01') ENGINE = InnoDB,
 PARTITION p202907 VALUES LESS THAN ('2029-08-01') ENGINE = InnoDB,
 PARTITION p202908 VALUES LESS THAN ('2029-09-01') ENGINE = InnoDB,
 PARTITION p202909 VALUES LESS THAN ('2029-10-01') ENGINE = InnoDB,
 PARTITION p202910 VALUES LESS THAN ('2029-11-01') ENGINE = InnoDB,
 PARTITION p202911 VALUES LESS THAN ('2029-12-01') ENGINE = InnoDB,
 PARTITION p202912 VALUES LESS THAN ('2030-01-01') ENGINE = InnoDB,
 PARTITION p203001 VALUES LESS THAN ('2030-02-01') ENGINE = InnoDB,
 PARTITION p203002 VALUES LESS THAN ('2030-03-01') ENGINE = InnoDB,
 PARTITION p203003 VALUES LESS THAN ('2030-04-01') ENGINE = InnoDB,
 PARTITION p203004 VALUES LESS THAN ('2030-05-01') ENGINE = InnoDB,
 PARTITION p203005 VALUES LESS THAN ('2030-06-01') ENGINE = InnoDB,
 PARTITION p203006 VALUES LESS THAN ('2030-07-01') ENGINE = InnoDB,
 PARTITION p203007 VALUES LESS THAN ('2030-08-01') ENGINE = InnoDB,
 PARTITION p203008 VALUES LESS THAN ('2030-09-01') ENGINE = InnoDB,
 PARTITION p203009 VALUES LESS THAN ('2030-10-01') ENGINE = InnoDB,
 PARTITION p203010 VALUES LESS THAN ('2030-11-01') ENGINE = InnoDB,
 PARTITION p203011 VALUES LESS THAN ('2030-12-01') ENGINE = InnoDB,
 PARTITION p203012 VALUES LESS THAN ('2031-01-01') ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_store_favorites`
--

DROP TABLE IF EXISTS `log_store_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_store_favorites` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '店ログログID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `to_spid` bigint(20) NOT NULL COMMENT '相手SPID',
  `crud_kind` varchar(255) NOT NULL COMMENT 'CRUD種別',
  `log_msg` varchar(255) DEFAULT NULL COMMENT 'ログメッセージ',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_log_store_favorites_1` (`spid`,`to_spid`),
  KEY `idx_log_store_favorites_2` (`to_spid`,`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='店ログログ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_store_friends`
--

DROP TABLE IF EXISTS `log_store_friends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_store_friends` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '店ともログID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `to_spid` bigint(20) NOT NULL COMMENT '相手SPID',
  `crud_kind` varchar(255) NOT NULL COMMENT 'CRUD種別',
  `log_msg` varchar(255) DEFAULT NULL COMMENT 'ログメッセージ',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_log_store_friends_1` (`spid`,`to_spid`),
  KEY `idx_log_store_friends_2` (`to_spid`,`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='店ともログ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_t_event_points`
--

DROP TABLE IF EXISTS `log_t_event_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_t_event_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'イベントポイント',
  `calc_date` datetime NOT NULL COMMENT '集計日時',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `event_point` bigint(20) NOT NULL COMMENT 'ポイント数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_log_t_event_points_1` (`calc_date`,`event_id`,`point_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベントポイント';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_tpoint_summary_executeds`
--

DROP TABLE IF EXISTS `log_tpoint_summary_executeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_tpoint_summary_executeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Tポイントサマリー生成実行ログ',
  `tpoint_kind_id` int(11) NOT NULL COMMENT 'Tポイント種別ID',
  `tpoint_period_id` int(11) NOT NULL COMMENT 'Tポイント期間ID',
  `execute_at` datetime NOT NULL COMMENT '実行日時',
  `status` int(11) NOT NULL COMMENT '実行状態',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_log_tpoint_summary_executeds_1` (`tpoint_kind_id`,`tpoint_period_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tポイントサマリー生成実行ログ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_useragents`
--

DROP TABLE IF EXISTS `log_useragents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_useragents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'UserAgentログID',
  `player_id` varchar(9) NOT NULL COMMENT 'TOGID',
  `useragent` varchar(512) NOT NULL COMMENT 'UserAgent',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_log_useragents_1` (`player_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='UserAgentログ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_alliance_reward_rotations`
--

DROP TABLE IF EXISTS `master_alliance_reward_rotations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_alliance_reward_rotations` (
  `id` int(11) NOT NULL COMMENT 'アライアンス報酬循環ID',
  `alliance_id` int(11) NOT NULL COMMENT 'アライアンスID',
  `rotation_start` int(11) NOT NULL COMMENT '循環回数開始値',
  `rotation_end` int(11) NOT NULL COMMENT '循環回数終了値',
  `accumulation_start` int(11) NOT NULL COMMENT '循環内累積回数開始値',
  `accumulation_end` int(11) NOT NULL COMMENT '循環内累積回数終了値',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `present_subject` varchar(200) DEFAULT NULL COMMENT 'プレゼント名目',
  `start_at` datetime NOT NULL COMMENT '開始日時',
  `end_at` datetime NOT NULL COMMENT '終了日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_alliance_reward_rotations_1` (`alliance_id`,`rotation_start`,`accumulation_start`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='アライアンス報酬循環マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_alliance_rewards`
--

DROP TABLE IF EXISTS `master_alliance_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_alliance_rewards` (
  `id` int(11) NOT NULL COMMENT 'アライアンス報酬ID',
  `alliance_id` int(11) NOT NULL COMMENT 'アライアンスID',
  `accumulation_kind` int(11) NOT NULL COMMENT '累積種別',
  `accumulation_num` int(11) NOT NULL COMMENT '累積回数',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `present_subject` varchar(40) DEFAULT NULL COMMENT 'プレゼント名目',
  `start_at` date NOT NULL COMMENT '開始日',
  `end_at` date NOT NULL COMMENT '終了日',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_alliance_rewards_1` (`alliance_id`,`start_at`,`end_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='アライアンス報酬マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_alliance_specific_rotations`
--

DROP TABLE IF EXISTS `master_alliance_specific_rotations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_alliance_specific_rotations` (
  `id` int(11) NOT NULL COMMENT 'アライアンス報酬ID',
  `alliance_id` int(11) NOT NULL COMMENT 'アライアンスID',
  `max_daily_num` int(11) NOT NULL COMMENT '最大日次回数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_master_alliance_specific_rotations_1` (`alliance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='アライアンス特定回数循環マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_alliances`
--

DROP TABLE IF EXISTS `master_alliances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_alliances` (
  `id` int(11) NOT NULL COMMENT 'アライアンスID',
  `name` varchar(80) NOT NULL COMMENT 'アライアンス名',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `start_at` date NOT NULL COMMENT '開始日',
  `end_at` date NOT NULL COMMENT '終了日',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_alliances_1` (`start_at`,`end_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_announce_kinds`
--

DROP TABLE IF EXISTS `master_announce_kinds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_announce_kinds` (
  `id` int(11) NOT NULL COMMENT '告知種別ID',
  `name` varchar(80) NOT NULL COMMENT '告知種別名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_announce_view_kinds`
--

DROP TABLE IF EXISTS `master_announce_view_kinds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_announce_view_kinds` (
  `id` int(11) NOT NULL COMMENT '告知表示種別ID',
  `name` varchar(80) NOT NULL COMMENT '告知表示種別名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_announces`
--

DROP TABLE IF EXISTS `master_announces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_announces` (
  `id` int(11) NOT NULL COMMENT '告知ID',
  `event_id` int(11) NOT NULL DEFAULT '-1' COMMENT 'イベントID',
  `announce_kind_id` int(11) NOT NULL DEFAULT '0' COMMENT '告知種別',
  `announce_view_kind_id` int(11) NOT NULL DEFAULT '0' COMMENT '告知表示種別',
  `redirect_kind_id` smallint(6) DEFAULT NULL COMMENT 'リダイレクト種別',
  `start_at` datetime DEFAULT NULL COMMENT '開始日時',
  `end_at` datetime DEFAULT NULL COMMENT '終了日時',
  `redirect_to` varchar(200) DEFAULT NULL COMMENT 'リダイレクト先',
  `description` text NOT NULL COMMENT '詳細',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='告知マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_avatar_coordinate_lists`
--

DROP TABLE IF EXISTS `master_avatar_coordinate_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_avatar_coordinate_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'アバターコーディネイトリストマスタ',
  `avatar_coordinate_id` int(11) NOT NULL COMMENT 'コーディネイトID',
  `avatar_id` int(11) NOT NULL COMMENT 'アバターID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_master_avatar_coordinate_lists_1` (`avatar_coordinate_id`,`avatar_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='アバターコーディネイトリストマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_avatar_coordinates`
--

DROP TABLE IF EXISTS `master_avatar_coordinates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_avatar_coordinates` (
  `id` int(11) NOT NULL COMMENT 'コーディネイトID',
  `name` varchar(80) NOT NULL COMMENT 'コーディネイト名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='アバターコーディネイトマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_avatar_gender_defaults`
--

DROP TABLE IF EXISTS `master_avatar_gender_defaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_avatar_gender_defaults` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '性別別初期アバターマスタ',
  `gender_id` int(11) NOT NULL COMMENT '性別ID',
  `avatar_id` int(11) NOT NULL COMMENT 'アバターID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_master_avatar_gender_defaults_1` (`gender_id`,`avatar_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='性別別初期アバターマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_avatar_inventory_defaults`
--

DROP TABLE IF EXISTS `master_avatar_inventory_defaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_avatar_inventory_defaults` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `avatar_id` bigint(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_master_avatar_inventory_defaults_1` (`avatar_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_avatar_parts`
--

DROP TABLE IF EXISTS `master_avatar_parts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_avatar_parts` (
  `id` int(11) NOT NULL,
  `is_require` tinyint(4) NOT NULL DEFAULT '1' COMMENT '設置必須フラグ',
  `name` varchar(80) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_avatars`
--

DROP TABLE IF EXISTS `master_avatars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_avatars` (
  `id` int(11) NOT NULL,
  `avatar_parts_id` int(11) NOT NULL,
  `avatar_coordinate_id` int(11) NOT NULL DEFAULT '-1' COMMENT 'コーディネートID',
  `partner_company_id` int(11) NOT NULL DEFAULT '-1' COMMENT '協賛企業ID',
  `rarity_id` int(11) NOT NULL,
  `gender_id` int(11) NOT NULL DEFAULT '-1' COMMENT '対象性別',
  `release_at` datetime NOT NULL COMMENT '公開日時',
  `name` varchar(80) NOT NULL,
  `description` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_avatars_1` (`avatar_parts_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_banner_conditions`
--

DROP TABLE IF EXISTS `master_banner_conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_banner_conditions` (
  `id` bigint(20) NOT NULL COMMENT 'バナー表示条件ID',
  `banner_id` int(11) NOT NULL COMMENT 'バナーID',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_banner_conditions_1` (`banner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='バナー表示条件';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_banners`
--

DROP TABLE IF EXISTS `master_banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_banners` (
  `id` int(11) NOT NULL COMMENT 'バナー管理マスタID',
  `image_path` varchar(100) NOT NULL COMMENT '画像パス',
  `link_to` varchar(200) NOT NULL COMMENT 'リンク先',
  `width` int(11) NOT NULL COMMENT 'width',
  `height` int(11) NOT NULL COMMENT 'hight',
  `view_kind` int(11) DEFAULT '0' COMMENT '表示種別',
  `start_at` datetime NOT NULL COMMENT '表示開始日時',
  `end_at` datetime NOT NULL COMMENT '表示日時',
  PRIMARY KEY (`id`),
  KEY `idx_master_banners_1` (`start_at`,`end_at`,`view_kind`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='バナー管理マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_campaign_kinds`
--

DROP TABLE IF EXISTS `master_campaign_kinds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_campaign_kinds` (
  `id` int(11) NOT NULL COMMENT 'キャンペーン種別',
  `name` varchar(40) NOT NULL COMMENT '名前',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='キャンペーン種別マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_campaigns`
--

DROP TABLE IF EXISTS `master_campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_campaigns` (
  `id` int(11) NOT NULL COMMENT 'キャンペーンID',
  `campaig_kind_id` int(11) NOT NULL COMMENT 'キャンペーン種別ID',
  `up_rate` float NOT NULL COMMENT '倍率',
  `start_at` datetime NOT NULL COMMENT '開始日時',
  `end_at` datetime NOT NULL COMMENT '終了日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_campaigns_1` (`campaig_kind_id`,`start_at`,`end_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='キャンペーンマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_cat_kinds`
--

DROP TABLE IF EXISTS `master_cat_kinds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_cat_kinds` (
  `id` int(11) NOT NULL COMMENT 'ねこ種別ID',
  `rarity_id` int(11) NOT NULL COMMENT 'レアリティ',
  `name` varchar(40) NOT NULL COMMENT 'ねこ種別名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ねこ種別マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_cat_lots`
--

DROP TABLE IF EXISTS `master_cat_lots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_cat_lots` (
  `id` int(11) NOT NULL COMMENT 'ねこ出現ID',
  `cat_buf_id` int(11) NOT NULL COMMENT 'バフID',
  `start_time` time NOT NULL COMMENT '出現対象開始時間',
  `end_time` time NOT NULL COMMENT '出現対象終了時間',
  `cat_min` int(11) NOT NULL COMMENT '出現数下限',
  `cat_max` int(11) NOT NULL COMMENT '出現数上限',
  `weight` int(11) NOT NULL COMMENT 'ウエイト値',
  `lot_group_id` int(11) NOT NULL COMMENT '抽選単位ID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_cat_lots_1` (`start_time`,`end_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ねこ抽選マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_cats`
--

DROP TABLE IF EXISTS `master_cats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_cats` (
  `id` int(11) NOT NULL COMMENT 'ねこID',
  `cat_kind_id` int(11) NOT NULL COMMENT 'ねこ種別ID',
  `point_min` int(11) NOT NULL COMMENT 'ねこP獲得下限',
  `point_max` int(11) NOT NULL COMMENT 'ねこP獲得上限',
  `name` varchar(40) NOT NULL COMMENT 'ねこの名前',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ねこマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_classid_package_lists`
--

DROP TABLE IF EXISTS `master_classid_package_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_classid_package_lists` (
  `id` int(11) NOT NULL COMMENT 'CLASSIDパッケージリストID',
  `classid_package_id` int(11) NOT NULL COMMENT 'CLASSIDパッケージID',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_classid_package_lists_1` (`classid_package_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='CLASSIDパッケージリストマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_classid_packages`
--

DROP TABLE IF EXISTS `master_classid_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_classid_packages` (
  `id` int(11) NOT NULL COMMENT 'CLASSIDパッケージID',
  `name` varchar(40) NOT NULL COMMENT 'CLASSIDパッケージ名',
  `description` text NOT NULL COMMENT 'CLASSIDパッケージ説明',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='CLASSIDパッケージマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_clerk_effects`
--

DROP TABLE IF EXISTS `master_clerk_effects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_clerk_effects` (
  `id` int(11) NOT NULL COMMENT '効果ID',
  `clerk_id` int(11) NOT NULL COMMENT '販売員ID',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `description` text NOT NULL COMMENT '説明文',
  `effect_contents` text NOT NULL COMMENT '効果発動時のテキスト',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_clerk_effects_1` (`clerk_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='販売員効果マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_clerk_rarities`
--

DROP TABLE IF EXISTS `master_clerk_rarities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_clerk_rarities` (
  `id` int(11) NOT NULL COMMENT 'レアリティID',
  `adjust_rate` int(11) NOT NULL COMMENT '補正値',
  `help_adjust_rate` int(11) NOT NULL COMMENT '支援補正値',
  `name` varchar(10) NOT NULL COMMENT '名前',
  `description` varchar(40) NOT NULL COMMENT '説明文',
  `help_description` varchar(40) NOT NULL COMMENT '支援時説明文',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='販売員レアリティ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_clerks`
--

DROP TABLE IF EXISTS `master_clerks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_clerks` (
  `id` int(11) NOT NULL COMMENT '販売員ID',
  `rarity_id` int(11) NOT NULL COMMENT 'レアリティ',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `name` varchar(40) NOT NULL COMMENT '名前',
  `description` varchar(100) DEFAULT NULL COMMENT '説明文',
  `start_at` datetime NOT NULL COMMENT '表示開始日時',
  `end_at` datetime NOT NULL COMMENT '表示日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_clerks_1` (`start_at`,`end_at`,`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='販売員マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_collection_rewards`
--

DROP TABLE IF EXISTS `master_collection_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_collection_rewards` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `condition_value` int(11) NOT NULL COMMENT '獲得数',
  `loop_condition_value` int(11) NOT NULL COMMENT 'ループ付与条件',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `present_subject` tinytext NOT NULL COMMENT 'プレゼント名目',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='図鑑報酬マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_container_categories`
--

DROP TABLE IF EXISTS `master_container_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_container_categories` (
  `id` int(11) NOT NULL,
  `layer` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_container_effects`
--

DROP TABLE IF EXISTS `master_container_effects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_container_effects` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '什器効果マスタ',
  `container_id` bigint(20) NOT NULL COMMENT '什器ID',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `description` varchar(80) DEFAULT NULL COMMENT '効果説明文',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_container_effects_1` (`container_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='什器効果マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_container_growth_lists`
--

DROP TABLE IF EXISTS `master_container_growth_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_container_growth_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `container_id` bigint(20) NOT NULL COMMENT '什器ID',
  `lv` smallint(6) NOT NULL COMMENT 'レベル',
  `store_point` int(11) NOT NULL COMMENT '必要ストアポイント',
  `wait_time` int(11) NOT NULL COMMENT '必要な時間（秒）',
  `growth_id` int(11) NOT NULL COMMENT '什器レベルアップ成長ID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_container_growth_lists_1` (`container_id`,`lv`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_container_growths`
--

DROP TABLE IF EXISTS `master_container_growths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_container_growths` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `growth_id` int(11) NOT NULL COMMENT '成長ID',
  `weight` int(11) NOT NULL COMMENT 'ウエイト',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_container_growths_1` (`growth_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_container_inventory_defaults`
--

DROP TABLE IF EXISTS `master_container_inventory_defaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_container_inventory_defaults` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `container_id` bigint(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_container_inventory_defaults_1` (`container_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_container_overlays`
--

DROP TABLE IF EXISTS `master_container_overlays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_container_overlays` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '什器規格マスタ',
  `container_spec_id` int(11) NOT NULL COMMENT '什器規格ID',
  `target_container_spec_id` int(11) NOT NULL COMMENT '対象什器規格ID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_container_overlays_1` (`container_spec_id`,`target_container_spec_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='什器規格マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_container_product_specs`
--

DROP TABLE IF EXISTS `master_container_product_specs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_container_product_specs` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '什器格納可能商品規格マスタ',
  `container_spec_id` int(11) NOT NULL COMMENT '什器規格ID',
  `no` int(11) NOT NULL DEFAULT '0' COMMENT '設置箇所',
  `product_spec_id` int(11) NOT NULL COMMENT '商品規格ID',
  `limit_num` int(11) NOT NULL COMMENT '格納可能商品規格上限',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_container_product_specs_1` (`container_spec_id`),
  KEY `idx_master_container_product_specs_2` (`product_spec_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='什器格納可能商品規格マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_container_quality_effects`
--

DROP TABLE IF EXISTS `master_container_quality_effects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_container_quality_effects` (
  `id` int(11) NOT NULL COMMENT 'クオリティ効果ID',
  `container_rarity_id` int(11) NOT NULL COMMENT '什器レアリティ',
  `product_rarity_id` int(11) NOT NULL COMMENT '商品レアリティ',
  `quality` int(11) NOT NULL COMMENT 'クオリティ',
  `store_point` int(11) NOT NULL COMMENT 'ストポイント',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_master_container_quality_effects_1` (`container_rarity_id`,`product_rarity_id`,`quality`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='什器クオリティ効果マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_container_quality_exps`
--

DROP TABLE IF EXISTS `master_container_quality_exps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_container_quality_exps` (
  `id` int(11) NOT NULL COMMENT 'クオリティ経験値ID',
  `rarity_id` int(11) NOT NULL COMMENT 'レアリティ',
  `quality` int(11) NOT NULL COMMENT 'クオリティ',
  `exp` int(11) NOT NULL COMMENT '必要経験値',
  `time` int(11) NOT NULL COMMENT '必要時間',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_master_container_quality_exps_1` (`rarity_id`,`quality`),
  KEY `idx_master_container_quality_exps_2` (`rarity_id`,`exp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='什器クオリティ必要経験値マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_container_quality_rewards`
--

DROP TABLE IF EXISTS `master_container_quality_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_container_quality_rewards` (
  `id` int(11) NOT NULL COMMENT 'クオリティ達成報酬ID',
  `rarity_id` int(11) NOT NULL COMMENT 'レアリティ',
  `quality` int(11) NOT NULL COMMENT 'クオリティ',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_container_quality_rewards_1` (`rarity_id`,`quality`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='什器クオリティ達成報酬';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_container_rarities`
--

DROP TABLE IF EXISTS `master_container_rarities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_container_rarities` (
  `id` int(11) NOT NULL COMMENT 'レアリティ',
  `default_max_quality` int(11) NOT NULL COMMENT 'デフォルトクオリティ上限',
  `max_quality` int(11) NOT NULL COMMENT 'クオリティ上限',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='什器レアリティマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_container_specs`
--

DROP TABLE IF EXISTS `master_container_specs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_container_specs` (
  `id` int(11) NOT NULL,
  `width` int(11) NOT NULL DEFAULT '1',
  `height` int(11) NOT NULL DEFAULT '1',
  `depth` int(11) NOT NULL DEFAULT '1',
  `is_layer_only` tinyint(4) NOT NULL DEFAULT '0' COMMENT '什器on什器専用',
  `name` varchar(40) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_container_specs_1` (`is_layer_only`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_container_spots`
--

DROP TABLE IF EXISTS `master_container_spots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_container_spots` (
  `id` int(11) NOT NULL,
  `is_grid_object` int(11) NOT NULL DEFAULT '0',
  `name` varchar(40) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_container_spots_1` (`is_grid_object`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_containers`
--

DROP TABLE IF EXISTS `master_containers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_containers` (
  `id` bigint(20) NOT NULL COMMENT '什器ID',
  `container_spot_id` int(11) NOT NULL COMMENT '設置箇所ID',
  `container_spec_id` int(11) NOT NULL COMMENT '什器規格ID',
  `container_category_id` int(11) NOT NULL COMMENT '什器カテゴリID',
  `partner_company_id` int(11) NOT NULL COMMENT '協賛企業ID',
  `max_add_effects` smallint(6) NOT NULL DEFAULT '1' COMMENT '最大効果数',
  `rarity_id` int(11) NOT NULL COMMENT 'レアリティID',
  `region_id` int(11) NOT NULL COMMENT '地域ID',
  `store_name_id` int(11) NOT NULL COMMENT 'ストア名ID',
  `store_genre_id` int(11) NOT NULL COMMENT 'ストアジャンルID',
  `sell_price` int(11) NOT NULL COMMENT '売却価格',
  `dealer_store_point` int(11) NOT NULL COMMENT '仕入れ時必要ストアポイント',
  `dealer_guest_point` int(11) NOT NULL COMMENT '仕入れ時必要ゲストポイント',
  `dealer_wait_time` int(11) NOT NULL COMMENT '仕入れ待ち時間',
  `quality_exp` int(11) NOT NULL COMMENT 'クオリティ獲得経験値',
  `is_quality_item` smallint(6) NOT NULL DEFAULT '0' COMMENT 'リメイク什器か',
  `start_at` datetime DEFAULT NULL COMMENT 'データ有効開始日時',
  `end_at` datetime DEFAULT NULL COMMENT 'データ有効終了日時',
  `name` varchar(80) NOT NULL COMMENT '什器名',
  `name_kana` varchar(160) NOT NULL COMMENT '什器名カナ',
  `description` text NOT NULL COMMENT '什器説明',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_containers_1` (`container_spec_id`),
  KEY `idx_master_containers_2` (`container_spot_id`,`rarity_id`),
  KEY `idx_master_containers_3` (`container_spot_id`,`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='什器マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_dealer_containers`
--

DROP TABLE IF EXISTS `master_dealer_containers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_dealer_containers` (
  `id` bigint(20) NOT NULL COMMENT '問屋什器ID',
  `dealer_id` int(11) NOT NULL COMMENT '問屋ID',
  `container_id` bigint(20) NOT NULL COMMENT '什器ID',
  `num` int(11) NOT NULL COMMENT '個数',
  `buy_price` int(11) NOT NULL COMMENT '価格',
  `buy_store_point` int(11) NOT NULL COMMENT '必要ストアポイント',
  `buy_guest_point` int(11) NOT NULL COMMENT '必要ゲストポイント',
  `wait_time` int(11) NOT NULL COMMENT '仕入れ待ち時間',
  `start_at` datetime DEFAULT '0000-00-00 00:00:00' COMMENT '仕入可能開始日時',
  `end_at` datetime DEFAULT '0000-00-00 00:00:00' COMMENT '仕入可能終了日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_dealer_containers_1` (`dealer_id`,`container_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='問屋什器マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_dealer_effects`
--

DROP TABLE IF EXISTS `master_dealer_effects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_dealer_effects` (
  `id` bigint(20) NOT NULL COMMENT '仕入れ効果',
  `dealer_id` bigint(20) NOT NULL COMMENT '問屋ID',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `start_at` datetime NOT NULL COMMENT '開始日時',
  `end_at` datetime NOT NULL COMMENT '終了日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_dealer_effects_1` (`dealer_id`,`start_at`,`end_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='仕入れ効果マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_dealer_product_category_effects`
--

DROP TABLE IF EXISTS `master_dealer_product_category_effects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_dealer_product_category_effects` (
  `id` int(11) NOT NULL COMMENT '抽選ID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `product_category_id` int(11) NOT NULL COMMENT '商品カテゴリ',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `start_at` datetime NOT NULL COMMENT '開始日',
  `end_at` datetime NOT NULL COMMENT '終了日',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_dealer_product_category_effects_1` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品カテゴリ仕入れ効果マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_dealer_products`
--

DROP TABLE IF EXISTS `master_dealer_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_dealer_products` (
  `id` bigint(20) NOT NULL COMMENT '問屋商品ID',
  `dealer_id` int(11) NOT NULL COMMENT '問屋ID',
  `product_id` bigint(20) NOT NULL COMMENT '商品ID',
  `num` int(11) NOT NULL COMMENT '個数',
  `buy_price` int(11) NOT NULL COMMENT '価格',
  `buy_store_point` int(11) NOT NULL COMMENT '必要ストアポイント',
  `buy_guest_point` int(11) NOT NULL COMMENT '必要ゲストポイント',
  `wait_time` int(11) NOT NULL COMMENT '仕入れ待ち時間',
  `start_at` datetime DEFAULT '0000-00-00 00:00:00' COMMENT '仕入可能開始日時',
  `end_at` datetime DEFAULT '0000-00-00 00:00:00' COMMENT '仕入可能終了日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_dealer_products_1` (`dealer_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='問屋商品マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_dealer_subject_unlock_conditions`
--

DROP TABLE IF EXISTS `master_dealer_subject_unlock_conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_dealer_subject_unlock_conditions` (
  `id` bigint(20) NOT NULL COMMENT '問屋解放条件ID',
  `dealer_id` int(11) NOT NULL COMMENT '問屋ID',
  `subject_kind` int(11) NOT NULL COMMENT '取扱種別',
  `subject_dealer_id` bigint(20) NOT NULL COMMENT '問屋商品ID or 問屋什器ID',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_dealer_subject_unlock_conditions_1` (`dealer_id`,`subject_kind`,`subject_dealer_id`),
  KEY `idx_master_dealer_subject_unlock_conditions_2` (`class_id`,`arg1`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='問屋解放条件';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_dealers`
--

DROP TABLE IF EXISTS `master_dealers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_dealers` (
  `id` int(11) NOT NULL COMMENT '問屋ID',
  `kind` int(11) NOT NULL COMMENT '問屋種別',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `is_lock` smallint(6) NOT NULL COMMENT '初回ロック',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `name` varchar(80) NOT NULL COMMENT '問屋名',
  `event_adjust_rate` int(11) NOT NULL DEFAULT '-1' COMMENT 'イベント補正値',
  `start_at` datetime NOT NULL COMMENT '開始日時',
  `end_at` datetime NOT NULL COMMENT '終了日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='問屋マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_dispatch_lot_kinds`
--

DROP TABLE IF EXISTS `master_dispatch_lot_kinds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_dispatch_lot_kinds` (
  `id` int(11) NOT NULL COMMENT '種別ID',
  `name` varchar(10) NOT NULL COMMENT '名前',
  `description` text NOT NULL COMMENT '説明文',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='派遣結果抽選種別';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_dispatch_lot_lists`
--

DROP TABLE IF EXISTS `master_dispatch_lot_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_dispatch_lot_lists` (
  `id` int(11) NOT NULL COMMENT '抽選リストID',
  `lot_id` int(11) NOT NULL COMMENT '抽選ID',
  `weight` int(11) NOT NULL COMMENT 'ウエイト',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `description` text NOT NULL COMMENT '説明文',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_dispatch_lot_lists_1` (`lot_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='結果抽選リスト';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_dispatch_lots`
--

DROP TABLE IF EXISTS `master_dispatch_lots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_dispatch_lots` (
  `id` int(11) NOT NULL COMMENT '抽選ID',
  `dispatch_id` int(11) NOT NULL COMMENT '派遣マスタID',
  `lot_kind_id` int(11) NOT NULL COMMENT '抽選種別',
  `weight` int(11) NOT NULL COMMENT 'ウエイト値',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_dispatch_lots_1` (`dispatch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='派遣結果抽選マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_dispatches`
--

DROP TABLE IF EXISTS `master_dispatches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_dispatches` (
  `id` int(11) NOT NULL COMMENT '派遣マスタID',
  `next_id` int(11) NOT NULL COMMENT '次の派遣マスタID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `is_first` int(11) NOT NULL COMMENT '最初の派遣先かのフラグ',
  `is_fever` int(11) NOT NULL COMMENT 'フィーバー用のデータか',
  `fever_time` int(11) NOT NULL COMMENT 'フィーバー時間',
  `wait_time` int(11) NOT NULL COMMENT '待ち時間',
  `fever_rate` int(11) NOT NULL COMMENT 'フィーバー確率',
  `lot_num` int(11) NOT NULL COMMENT '抽選回数',
  `get_max_point` int(11) NOT NULL COMMENT '最大獲得ポイント数(表示用)',
  `start_at` datetime NOT NULL COMMENT '表示開始日時',
  `end_at` datetime NOT NULL COMMENT '表示日時',
  `name` varchar(40) NOT NULL COMMENT '名前',
  `description` text COMMENT '説明文',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_dispatches_1` (`start_at`,`end_at`,`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='派遣マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_enquete_answers`
--

DROP TABLE IF EXISTS `master_enquete_answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_enquete_answers` (
  `id` int(11) NOT NULL COMMENT 'アンケート回答ID',
  `enquete_id` int(11) NOT NULL COMMENT 'アンケートID',
  `enquete_question_id` int(11) NOT NULL COMMENT '設問ID',
  `answer` text NOT NULL COMMENT '回答',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_enquete_answers_1` (`enquete_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='アンケート回答マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_enquete_questions`
--

DROP TABLE IF EXISTS `master_enquete_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_enquete_questions` (
  `id` int(11) NOT NULL COMMENT 'アンケート設問ID',
  `enquete_id` int(11) NOT NULL COMMENT 'アンケートID',
  `answer_kind_id` int(11) NOT NULL COMMENT '回答形式',
  `required_flag` smallint(6) NOT NULL COMMENT '必須フラグ',
  `question` text COMMENT '設問',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_enquete_questions_1` (`enquete_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='アンケート設問';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_enquete_rewards`
--

DROP TABLE IF EXISTS `master_enquete_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_enquete_rewards` (
  `id` bigint(20) NOT NULL COMMENT 'アンケート報酬ID',
  `enquete_id` int(11) NOT NULL COMMENT 'アンケートID',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `present_subject` varchar(40) DEFAULT NULL COMMENT 'プレゼント名目',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_enquete_rewards_1` (`enquete_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='アンケート報酬';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_enquetes`
--

DROP TABLE IF EXISTS `master_enquetes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_enquetes` (
  `id` int(11) NOT NULL COMMENT 'アンケートID',
  `name` varchar(40) NOT NULL COMMENT 'アンケート名',
  `start_at` datetime NOT NULL COMMENT '開始日時',
  `end_at` datetime NOT NULL COMMENT '終了日時',
  `answer_limit` int(11) NOT NULL COMMENT '回答回数上限',
  `description` text COMMENT '説明',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_enquetes_1` (`start_at`,`end_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='アンケートマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_event_daily_ranking_rewards`
--

DROP TABLE IF EXISTS `master_event_daily_ranking_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_event_daily_ranking_rewards` (
  `id` int(11) NOT NULL COMMENT 'デイリーランキング報酬ID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `reward_kind_id` int(11) NOT NULL COMMENT '付与種別',
  `ranking_min` int(11) NOT NULL COMMENT 'ランキングmin',
  `ranking_max` int(11) NOT NULL COMMENT 'ランキングmax',
  `start_at` datetime NOT NULL COMMENT '付与対象開始日',
  `end_at` datetime NOT NULL COMMENT '付与対象終了日',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `present_subject` varchar(40) DEFAULT NULL COMMENT 'プレゼント名目',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_event_daily_ranking_rewards_1` (`event_id`,`point_id`,`ranking_min`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベントデイリーランキング報酬';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_event_drop_item_growth_rewards`
--

DROP TABLE IF EXISTS `master_event_drop_item_growth_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_event_drop_item_growth_rewards` (
  `id` int(11) NOT NULL COMMENT '抽選ID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `growth_id` int(11) NOT NULL COMMENT '成長テーブルID',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `present_subject` varchar(40) DEFAULT NULL COMMENT 'プレゼント名目',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_event_drop_item_growth_rewards_1` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ドロップアイテム成長報酬';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_event_drop_item_growths`
--

DROP TABLE IF EXISTS `master_event_drop_item_growths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_event_drop_item_growths` (
  `id` int(11) NOT NULL COMMENT '成長テーブルID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `drop_item_id` int(11) NOT NULL COMMENT 'ドロップアイテムID',
  `growth_point_min` int(11) NOT NULL COMMENT '成長ポイントmin',
  `growth_point_max` int(11) NOT NULL COMMENT '成長ポイントmax',
  `description` text NOT NULL COMMENT '説明',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_event_drop_item_growths_1` (`event_id`,`drop_item_id`,`growth_point_min`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベントドロップアイテム成長テーブル';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_event_drop_item_rarity_rewards`
--

DROP TABLE IF EXISTS `master_event_drop_item_rarity_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_event_drop_item_rarity_rewards` (
  `id` int(11) NOT NULL COMMENT '抽選ID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `drop_item_id` int(11) NOT NULL COMMENT 'ドロッップアイテムID',
  `rarity_id` int(11) NOT NULL COMMENT 'レアリティID',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `present_subject` varchar(40) DEFAULT NULL COMMENT 'プレゼント名目',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_event_drop_item_rarity_rewards_1` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベントドロップアイテムレアリティ獲得報酬';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_event_drop_items`
--

DROP TABLE IF EXISTS `master_event_drop_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_event_drop_items` (
  `id` int(11) NOT NULL COMMENT 'ドロップアイテムID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `is_change` int(11) NOT NULL DEFAULT '0' COMMENT 'アイテムでID変更可能か',
  `name` tinytext NOT NULL COMMENT 'ドロップアイテム名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_event_drop_items_1` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベント用ドロップアイテムマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_event_fevers`
--

DROP TABLE IF EXISTS `master_event_fevers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_event_fevers` (
  `id` int(11) NOT NULL COMMENT 'イベントフィーバーID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `fever_time` int(11) NOT NULL COMMENT 'フィーバー時間',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `description` text NOT NULL COMMENT '説明文',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_event_fevers_1` (`event_id`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベントフィーバーマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_event_kinds`
--

DROP TABLE IF EXISTS `master_event_kinds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_event_kinds` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_event_lists`
--

DROP TABLE IF EXISTS `master_event_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_event_lists` (
  `id` int(11) NOT NULL COMMENT 'イベント詳細ID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `start_at` datetime NOT NULL COMMENT '開始日',
  `end_at` datetime NOT NULL COMMENT '終了日',
  `name` varchar(40) NOT NULL COMMENT 'イベント詳細名',
  `description` text COMMENT '説明',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_event_lists_1` (`event_id`,`start_at`,`end_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベント詳細';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_event_point_effects`
--

DROP TABLE IF EXISTS `master_event_point_effects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_event_point_effects` (
  `id` int(11) NOT NULL COMMENT 'イベントポイント効果ID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `effect_kind_id` int(11) NOT NULL COMMENT '効果発同種別',
  `add_rate` int(11) NOT NULL COMMENT '獲得量アップ値',
  `weight` int(11) NOT NULL COMMENT '抽選確率',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_event_point_effects_1` (`event_id`,`effect_kind_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベントポイント効果';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_event_point_lot_groups`
--

DROP TABLE IF EXISTS `master_event_point_lot_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_event_point_lot_groups` (
  `id` int(11) NOT NULL COMMENT 'イベントポイントガチャグループID',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `lot_group_id` int(11) NOT NULL COMMENT 'ガチャグループID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_master_event_point_lot_groups_1` (`point_id`,`lot_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベントポイントガチャグループマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_event_point_rewards`
--

DROP TABLE IF EXISTS `master_event_point_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_event_point_rewards` (
  `id` int(11) NOT NULL COMMENT 'イベントポイント達成報酬ID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `reward_type` int(11) NOT NULL DEFAULT '0' COMMENT '付与種別',
  `condition_value` bigint(20) NOT NULL COMMENT 'ポイント数',
  `loop_condition_value` bigint(20) NOT NULL COMMENT 'ループ付与条件数',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `present_subject` varchar(40) DEFAULT NULL COMMENT 'プレゼント名目',
  `description` text COMMENT '説明',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_event_point_rewards_1` (`event_id`,`point_id`,`condition_value`),
  KEY `idx_master_event_point_rewards_2` (`event_id`,`point_id`,`reward_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベントポイント達成報酬';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_event_points`
--

DROP TABLE IF EXISTS `master_event_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_event_points` (
  `id` int(11) NOT NULL COMMENT 'イベントポイントID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_master_event_points_1` (`event_id`,`point_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベントポイントマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_event_products`
--

DROP TABLE IF EXISTS `master_event_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_event_products` (
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `product_id` bigint(20) NOT NULL COMMENT '商品ID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベント商品マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_event_ranking_rewards`
--

DROP TABLE IF EXISTS `master_event_ranking_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_event_ranking_rewards` (
  `id` int(11) NOT NULL COMMENT 'ランキング報酬ID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `ranking_min` int(11) NOT NULL COMMENT 'ランキングmin',
  `ranking_max` int(11) NOT NULL COMMENT 'ランキングmax',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `present_subject` varchar(40) DEFAULT NULL COMMENT 'プレゼント名目',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_event_ranking_rewards_1` (`event_id`,`ranking_min`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベントランキング報酬';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_event_rarities`
--

DROP TABLE IF EXISTS `master_event_rarities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_event_rarities` (
  `id` int(11) NOT NULL COMMENT 'レアリティID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `name` varchar(80) NOT NULL COMMENT 'レアリティ名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_event_rarities_1` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベント用レアリティマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_event_rarity_complete_rewards`
--

DROP TABLE IF EXISTS `master_event_rarity_complete_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_event_rarity_complete_rewards` (
  `id` int(11) NOT NULL COMMENT 'コンプ報酬ID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `rarity_id` int(11) NOT NULL COMMENT 'レアリティID',
  `complete_num_min` int(11) NOT NULL COMMENT 'コンプ回数min',
  `complete_num_max` int(11) NOT NULL COMMENT 'コンプ回数max',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `present_subject` varchar(40) DEFAULT NULL COMMENT 'プレゼント名目',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_event_rarity_complete_rewards_1` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベント用レアリティコンプ報酬マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_event_shops`
--

DROP TABLE IF EXISTS `master_event_shops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_event_shops` (
  `id` int(11) NOT NULL COMMENT 'イベントショップID',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `price` int(11) NOT NULL COMMENT '価格',
  `accumulation_max` int(11) NOT NULL COMMENT '累積最大購入個数',
  `sort_order` int(11) DEFAULT NULL COMMENT 'ソート順(昇順)',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `present_subject` varchar(40) DEFAULT NULL COMMENT 'プレゼント名目',
  `start_at` datetime NOT NULL COMMENT '開始日時',
  `end_at` datetime NOT NULL COMMENT '終了日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_event_shops_1` (`point_id`,`start_at`,`end_at`,`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベントショップマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_event_team_point_rewards`
--

DROP TABLE IF EXISTS `master_event_team_point_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_event_team_point_rewards` (
  `id` bigint(20) NOT NULL COMMENT 'チームポイント報酬ID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `condition_value` bigint(20) NOT NULL COMMENT 'ポイント数',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `present_subject` varchar(40) DEFAULT NULL COMMENT 'プレゼント名目',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_event_team_point_rewards_1` (`event_id`,`point_id`,`condition_value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベントチームポイント報酬';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_event_team_points`
--

DROP TABLE IF EXISTS `master_event_team_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_event_team_points` (
  `id` int(11) NOT NULL COMMENT 'イベントチームポイントID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `event_list_id` int(11) NOT NULL COMMENT 'イベント詳細ID',
  `event_team_id` int(11) NOT NULL COMMENT 'イベンチームID',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_event_team_points_1` (`event_id`,`event_list_id`,`event_team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベントチームポイントマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_event_teams`
--

DROP TABLE IF EXISTS `master_event_teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_event_teams` (
  `id` int(11) NOT NULL COMMENT 'イベントチームID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `name` varchar(40) NOT NULL COMMENT 'チーム名',
  `description` text COMMENT '説明',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_event_teams_1` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベントチームマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_events`
--

DROP TABLE IF EXISTS `master_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_events` (
  `id` int(11) NOT NULL,
  `event_kind_id` int(11) NOT NULL,
  `alliance_id` int(11) DEFAULT NULL COMMENT 'アライアンスID',
  `is_valid` tinyint(4) NOT NULL DEFAULT '1',
  `start_at` datetime NOT NULL,
  `end_at` datetime NOT NULL,
  `name` varchar(40) NOT NULL COMMENT 'イベント名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_feed_kinds`
--

DROP TABLE IF EXISTS `master_feed_kinds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_feed_kinds` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `route_to` varchar(80) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_feed_targets`
--

DROP TABLE IF EXISTS `master_feed_targets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_feed_targets` (
  `id` int(11) NOT NULL,
  `feed_id` int(11) NOT NULL,
  `spid` bigint(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_feed_targets_2` (`spid`),
  KEY `idx_master_feed_targets_3` (`feed_id`,`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_feeds`
--

DROP TABLE IF EXISTS `master_feeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_feeds` (
  `id` int(11) NOT NULL,
  `feed_kind_id` int(11) NOT NULL,
  `target` int(11) NOT NULL,
  `start_at` datetime NOT NULL,
  `subject` varchar(40) NOT NULL COMMENT '題目',
  `body` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_feeds_1` (`target`,`start_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_genders`
--

DROP TABLE IF EXISTS `master_genders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_genders` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_guild_avatar_gender_defaults`
--

DROP TABLE IF EXISTS `master_guild_avatar_gender_defaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_guild_avatar_gender_defaults` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '組合デフォルトアバタマスタ',
  `gender_id` int(11) NOT NULL COMMENT '性別ID',
  `avatar_id` bigint(20) NOT NULL COMMENT 'アバターID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_guild_avatar_gender_defaults_1` (`gender_id`),
  KEY `idx_master_guild_avatar_gender_defaults_2` (`avatar_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合デフォルトアバタマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_guild_avatar_inventory_defaults`
--

DROP TABLE IF EXISTS `master_guild_avatar_inventory_defaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_guild_avatar_inventory_defaults` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '組合デフォルトアバタマスタ',
  `avatar_id` bigint(20) NOT NULL COMMENT 'アバターID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_guild_avatar_inventory_defaults_1` (`avatar_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合デフォルトアバタマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_guild_budge_defaults`
--

DROP TABLE IF EXISTS `master_guild_budge_defaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_guild_budge_defaults` (
  `id` int(11) NOT NULL COMMENT '所持ID',
  `budge_id` int(11) NOT NULL COMMENT '組合バッジID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合バッジデフォルト所持マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_guild_budges`
--

DROP TABLE IF EXISTS `master_guild_budges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_guild_budges` (
  `id` int(11) NOT NULL COMMENT '組合バッジID',
  `kind` int(11) NOT NULL COMMENT '組合バッジ種別',
  `name` varchar(255) NOT NULL COMMENT '名前',
  `description` text NOT NULL COMMENT '説明',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合バッジマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_guild_contribution_rewards`
--

DROP TABLE IF EXISTS `master_guild_contribution_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_guild_contribution_rewards` (
  `id` int(11) NOT NULL COMMENT '組合貢献度報酬ID',
  `threshold` int(11) NOT NULL COMMENT '貢献度閾値',
  `priority` int(11) NOT NULL DEFAULT '0' COMMENT '優先度',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合貢献度報酬マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_guild_growths`
--

DROP TABLE IF EXISTS `master_guild_growths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_guild_growths` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `lv` tinyint(4) NOT NULL COMMENT '対象レベル',
  `exp` int(11) NOT NULL COMMENT '必要経験値',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合レベルアップマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_guild_quest_conditions`
--

DROP TABLE IF EXISTS `master_guild_quest_conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_guild_quest_conditions` (
  `id` int(11) NOT NULL COMMENT '組合クエストリストID',
  `quest_list_id` int(11) NOT NULL COMMENT '組合クエストリストID',
  `counter_kind_id` int(11) NOT NULL COMMENT 'カウンタ種別ID',
  `target_id` bigint(20) NOT NULL COMMENT '対象ID',
  `count_value` int(11) NOT NULL COMMENT '条件値',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合クエスト達成条件マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_guild_quest_lists`
--

DROP TABLE IF EXISTS `master_guild_quest_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_guild_quest_lists` (
  `id` int(11) NOT NULL COMMENT '組合クエストリストID',
  `quest_id` int(11) NOT NULL COMMENT '組合クエストID',
  `lv_min` int(11) NOT NULL COMMENT '対象レベル最小',
  `lv_max` int(11) NOT NULL COMMENT '対象レベル最大',
  `weight` int(11) NOT NULL DEFAULT '1' COMMENT 'ウエイト値',
  `start_at` datetime NOT NULL COMMENT '開始日時',
  `end_at` datetime NOT NULL COMMENT '終了日時',
  `name` varchar(255) NOT NULL COMMENT '名前',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_guild_quest_lists_1` (`quest_id`),
  KEY `idx_master_guild_quest_lists_2` (`start_at`,`end_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合クエストリストマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_guild_quest_rewards`
--

DROP TABLE IF EXISTS `master_guild_quest_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_guild_quest_rewards` (
  `id` int(11) NOT NULL COMMENT '組合クエストリストID',
  `quest_list_id` int(11) NOT NULL COMMENT '組合クエストリストID',
  `priority` int(11) NOT NULL DEFAULT '0' COMMENT '優先度',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合クエスト達成報酬マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_guild_quests`
--

DROP TABLE IF EXISTS `master_guild_quests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_guild_quests` (
  `id` int(11) NOT NULL COMMENT '組合クエストID',
  `event_id` int(11) NOT NULL DEFAULT '-1' COMMENT 'イベントID',
  `start_at` datetime NOT NULL COMMENT '開始日時',
  `end_at` datetime NOT NULL COMMENT '終了日時',
  `name` varchar(255) NOT NULL COMMENT '名前',
  `description` text COMMENT '説明',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_guild_quests_1` (`event_id`),
  KEY `idx_master_guild_quests_2` (`start_at`,`end_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合クエストマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_guild_shop_rewards`
--

DROP TABLE IF EXISTS `master_guild_shop_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_guild_shop_rewards` (
  `id` int(11) NOT NULL COMMENT '組合商店報酬マスタID',
  `guild_shop_id` int(11) NOT NULL COMMENT '組合商店マスタID',
  `priority` int(11) NOT NULL DEFAULT '0' COMMENT '優先度',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_guild_shop_rewards_1` (`guild_shop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合商店報酬マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_guild_shops`
--

DROP TABLE IF EXISTS `master_guild_shops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_guild_shops` (
  `id` int(11) NOT NULL COMMENT '組合商店マスタID',
  `lv_min` mediumint(9) NOT NULL COMMENT '対象組合レベル最小',
  `lv_max` mediumint(9) NOT NULL COMMENT '対象組合レベル最大',
  `store_point` bigint(20) NOT NULL COMMENT '必要ストアポイント',
  `add_contrib` int(11) NOT NULL COMMENT '付与する貢献度',
  `start_at` datetime NOT NULL COMMENT '開始日時',
  `end_at` datetime NOT NULL COMMENT '終了日時',
  `name` varchar(255) NOT NULL COMMENT '商品名',
  `description` text COMMENT '商品説明説明',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_guild_shops_1` (`lv_min`,`lv_max`),
  KEY `idx_master_guild_shops_2` (`start_at`,`end_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合商店マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_invite_effects`
--

DROP TABLE IF EXISTS `master_invite_effects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_invite_effects` (
  `id` int(11) NOT NULL,
  `invite_id` int(11) NOT NULL,
  `invite_complete_num` int(11) NOT NULL,
  `class_id` varchar(40) NOT NULL,
  `arg1` varchar(40) DEFAULT NULL,
  `arg2` varchar(40) DEFAULT NULL,
  `arg3` varchar(40) DEFAULT NULL,
  `arg4` varchar(40) DEFAULT NULL,
  `arg5` varchar(40) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_invites`
--

DROP TABLE IF EXISTS `master_invites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_invites` (
  `id` int(11) NOT NULL,
  `start_at` datetime NOT NULL,
  `end_at` datetime NOT NULL,
  `name` varchar(40) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_item_effects`
--

DROP TABLE IF EXISTS `master_item_effects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_item_effects` (
  `id` int(11) NOT NULL COMMENT 'アイテム効果ID',
  `item_id` int(11) NOT NULL COMMENT 'アイテムID',
  `use_num` int(11) NOT NULL DEFAULT '1' COMMENT '使用数',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='アイテム効果マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_item_responses`
--

DROP TABLE IF EXISTS `master_item_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_item_responses` (
  `id` int(11) NOT NULL COMMENT 'アイテム応答ID',
  `item_id` int(11) NOT NULL COMMENT 'アイテムID',
  `present_box_kind` int(11) NOT NULL COMMENT 'プレゼントBOX種別',
  `result_format_kind` int(11) NOT NULL COMMENT '結果書式種別',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_master_item_responses_1` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='アイテム応答マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_items`
--

DROP TABLE IF EXISTS `master_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_items` (
  `id` int(11) NOT NULL COMMENT 'アイテムID',
  `event_id` int(11) NOT NULL DEFAULT '-1' COMMENT 'イベントID',
  `route_to` varchar(255) DEFAULT NULL COMMENT '使用可能箇所',
  `name` varchar(40) NOT NULL COMMENT 'アイテム名',
  `description` text NOT NULL COMMENT 'アイテム詳細',
  `start_at` datetime NOT NULL COMMENT '開始日',
  `end_at` datetime NOT NULL COMMENT '終了日',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='アイテムマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_like_condition_effects`
--

DROP TABLE IF EXISTS `master_like_condition_effects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_like_condition_effects` (
  `id` int(11) NOT NULL,
  `like_condition_id` int(11) NOT NULL,
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_like_conditions`
--

DROP TABLE IF EXISTS `master_like_conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_like_conditions` (
  `id` int(11) NOT NULL,
  `like_kind_id` int(11) NOT NULL,
  `num` int(11) NOT NULL,
  `start_at` datetime NOT NULL,
  `end_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_like_kinds`
--

DROP TABLE IF EXISTS `master_like_kinds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_like_kinds` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_login_dailies`
--

DROP TABLE IF EXISTS `master_login_dailies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_login_dailies` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `target_daily_num` int(11) DEFAULT '0' COMMENT 'ログイン報酬種別',
  `name` varchar(255) DEFAULT '0' COMMENT '対象日数',
  `login_kind` int(11) DEFAULT '0' COMMENT 'ログイン報酬種別',
  `start_at` datetime NOT NULL COMMENT '開始日',
  `end_at` datetime NOT NULL COMMENT '終了日',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_login_dailies_1` (`start_at`,`end_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='デイリーログインマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_login_daily_effects`
--

DROP TABLE IF EXISTS `master_login_daily_effects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_login_daily_effects` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `login_daily_id` int(11) NOT NULL COMMENT 'デイリーログインID',
  `login_num` int(11) DEFAULT NULL COMMENT 'ログイン回数',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASS_ID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASS_ID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'デイリーログイン報酬マスタ',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'デイリーログイン報酬マスタ',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'デイリーログイン報酬マスタ',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'デイリーログイン報酬マスタ',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_login_daily_effects_1` (`login_daily_id`,`login_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='デイリーログイン報酬マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_login_daily_kinds`
--

DROP TABLE IF EXISTS `master_login_daily_kinds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_login_daily_kinds` (
  `id` int(11) NOT NULL COMMENT 'ログイン報酬種別ID',
  `name` varchar(100) NOT NULL COMMENT '種別名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ログイン報酬種別マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_lot_accumulation_lists`
--

DROP TABLE IF EXISTS `master_lot_accumulation_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_lot_accumulation_lists` (
  `id` int(11) NOT NULL COMMENT 'まとめガチャリストID',
  `lot_accumulation_id` int(11) NOT NULL COMMENT 'まとめガチャID',
  `lot_id` int(11) NOT NULL COMMENT 'ガチャID',
  `weight` int(11) NOT NULL DEFAULT '1' COMMENT 'ウエイト',
  `start_at` datetime DEFAULT NULL COMMENT '適用開始日時',
  `end_at` datetime DEFAULT NULL COMMENT '適用終了日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_lot_accumulation_lists_1` (`lot_accumulation_id`,`start_at`,`end_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='まとめガチャリストマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_lot_accumulations`
--

DROP TABLE IF EXISTS `master_lot_accumulations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_lot_accumulations` (
  `id` int(11) NOT NULL COMMENT 'まとめガチャID',
  `name` varchar(40) NOT NULL COMMENT 'まとめガチャ名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='まとめガチャマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_lot_box_limits`
--

DROP TABLE IF EXISTS `master_lot_box_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_lot_box_limits` (
  `id` int(11) NOT NULL COMMENT 'ボックスガチャ上限ID',
  `lot_box_id` int(11) NOT NULL COMMENT 'ボックスガチャID',
  `lot_list_id` int(11) NOT NULL COMMENT 'ガチャリストID',
  `limit_num` int(11) NOT NULL COMMENT '抽選上限数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_lot_box_limits_1` (`lot_box_id`,`lot_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ボックスガチャ上限マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_lot_boxes`
--

DROP TABLE IF EXISTS `master_lot_boxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_lot_boxes` (
  `id` int(11) NOT NULL COMMENT 'ボックスガチャID',
  `lot_id` int(11) NOT NULL COMMENT 'ガチャID',
  `name` varchar(40) NOT NULL COMMENT 'ボックスガチャ名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ボックスガチャマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_lot_groups`
--

DROP TABLE IF EXISTS `master_lot_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_lot_groups` (
  `id` int(11) NOT NULL COMMENT 'ガチャグループID',
  `lot_id` int(11) NOT NULL COMMENT 'ガチャID',
  `weight` int(11) NOT NULL COMMENT 'ウエイト',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_lot_groups_1` (`lot_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ガチャグループマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_lot_lists`
--

DROP TABLE IF EXISTS `master_lot_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_lot_lists` (
  `id` int(11) NOT NULL COMMENT 'ガチャリストID',
  `lot_group_id` int(11) NOT NULL DEFAULT '-1' COMMENT 'ガチャグループID',
  `weight` int(11) NOT NULL COMMENT 'ウエイト',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_lot_lists_1` (`lot_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ガチャリストマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_lots`
--

DROP TABLE IF EXISTS `master_lots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_lots` (
  `id` int(11) NOT NULL COMMENT 'ガチャID',
  `name` varchar(40) NOT NULL COMMENT 'ガチャ名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ガチャマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_npc_avatar_coordinates`
--

DROP TABLE IF EXISTS `master_npc_avatar_coordinates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_npc_avatar_coordinates` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'NPCアバターコーディネイトマスタ',
  `npc_id` int(11) NOT NULL COMMENT 'NPC-ID',
  `avatar_coordinate_id` int(11) NOT NULL COMMENT 'アバターコーディネイトID',
  `weight` int(11) NOT NULL DEFAULT '1' COMMENT 'ウエイト値',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_master_npc_avatar_coordinates_1` (`npc_id`,`avatar_coordinate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='NPCアバターコーディネイトマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_npc_buy_actions`
--

DROP TABLE IF EXISTS `master_npc_buy_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_npc_buy_actions` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'NPC購入処理',
  `npc_id` int(11) NOT NULL COMMENT 'NPC-ID',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_npc_buy_actions_1` (`npc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='NPC購入処理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_npc_buy_conditions`
--

DROP TABLE IF EXISTS `master_npc_buy_conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_npc_buy_conditions` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'NPC購入条件マスタ',
  `npc_id` int(11) NOT NULL COMMENT 'NPC-ID',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_npc_buy_conditions_1` (`npc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='NPC購入条件マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_npc_buys`
--

DROP TABLE IF EXISTS `master_npc_buys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_npc_buys` (
  `id` int(11) NOT NULL COMMENT 'NPC購入ID',
  `npc_id` int(11) NOT NULL COMMENT 'NPC-ID',
  `buy_num` int(11) NOT NULL COMMENT '購入数',
  `weight` int(11) NOT NULL COMMENT 'ウエイト値',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_master_npc_buys_1` (`npc_id`,`buy_num`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='NPC購入マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_npc_coming_condition_bulk_args`
--

DROP TABLE IF EXISTS `master_npc_coming_condition_bulk_args`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_npc_coming_condition_bulk_args` (
  `id` int(11) NOT NULL COMMENT 'NPC来訪条件一括引数ID',
  `npc_coming_condition_bulk_id` int(11) NOT NULL COMMENT 'NPC来訪条件一括ID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_npc_coming_condition_bulk_args_1` (`npc_coming_condition_bulk_id`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='NPC来訪条件一括引数マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_npc_coming_conditions`
--

DROP TABLE IF EXISTS `master_npc_coming_conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_npc_coming_conditions` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'NPC来訪条件マスタ',
  `npc_id` int(11) NOT NULL COMMENT 'NPC来訪ID',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_npc_coming_conditions_1` (`npc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='NPC来訪条件マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_npc_comings`
--

DROP TABLE IF EXISTS `master_npc_comings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_npc_comings` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'NPC来訪マスタ',
  `npc_id` int(11) NOT NULL COMMENT 'NPC-ID',
  `hour` int(11) NOT NULL COMMENT 'NPC来訪時間帯',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_master_npc_comings_1` (`npc_id`,`hour`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='NPC来訪マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_npc_kinds`
--

DROP TABLE IF EXISTS `master_npc_kinds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_npc_kinds` (
  `id` int(11) NOT NULL COMMENT 'NPC種別ID',
  `name` varchar(40) NOT NULL COMMENT 'NPC名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='NPC種別マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_npc_review_kinds`
--

DROP TABLE IF EXISTS `master_npc_review_kinds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_npc_review_kinds` (
  `id` int(11) NOT NULL,
  `is_buyact` tinyint(4) DEFAULT '0' COMMENT '購入アクションを行うか',
  `name` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='レビュー種別';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_npc_reviews`
--

DROP TABLE IF EXISTS `master_npc_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_npc_reviews` (
  `id` int(11) NOT NULL COMMENT 'NPCレビュー条件ID',
  `review_kind_id` int(11) NOT NULL COMMENT 'レビュー種別ID',
  `review_format` text NOT NULL COMMENT 'レビューフォーマット',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='NPCレビューマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_npcs`
--

DROP TABLE IF EXISTS `master_npcs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_npcs` (
  `id` int(11) NOT NULL COMMENT 'NPCID',
  `npc_kind_id` int(11) NOT NULL COMMENT 'NPC種別ID',
  `npc_method` int(11) NOT NULL COMMENT 'NPC動作ID',
  `force_additional_purchase_num` smallint(6) NOT NULL DEFAULT '-1' COMMENT '強制又買い数',
  `guest_point_min` int(11) NOT NULL COMMENT '取得可能ゲストポイントレンジ最小',
  `guest_point_max` int(11) NOT NULL COMMENT '取得可能ゲストポイントレンジ最大',
  `start_at` datetime NOT NULL COMMENT 'NPC適用開始日時',
  `end_at` datetime NOT NULL COMMENT 'NPC適用終了日時',
  `name` varchar(40) NOT NULL COMMENT 'NPC名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_npcs_1` (`npc_method`,`start_at`,`end_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='NPCマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_partner_companies`
--

DROP TABLE IF EXISTS `master_partner_companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_partner_companies` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_point_effects`
--

DROP TABLE IF EXISTS `master_point_effects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_point_effects` (
  `id` int(11) NOT NULL COMMENT 'ポイント効果ID',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `name` varchar(40) NOT NULL COMMENT 'ポイント効果名',
  `price` int(11) NOT NULL COMMENT '価格',
  `item_effect_id` int(11) NOT NULL COMMENT 'アイテム効果ID',
  `present_subject` varchar(255) DEFAULT NULL COMMENT 'プレゼント名目',
  `start_at` datetime NOT NULL COMMENT '開始日時',
  `end_at` datetime NOT NULL COMMENT '終了日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_point_effects_1` (`point_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ポイント効果マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_points`
--

DROP TABLE IF EXISTS `master_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_points` (
  `id` int(11) NOT NULL COMMENT 'ポイントID',
  `event_id` int(11) NOT NULL DEFAULT '-1' COMMENT 'イベントID',
  `point_kind_id` int(11) NOT NULL COMMENT 'ポイント種別ID',
  `name` varchar(80) NOT NULL COMMENT 'ポイント名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_points_1` (`event_id`,`point_kind_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ポイントマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_present_distributions`
--

DROP TABLE IF EXISTS `master_present_distributions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_present_distributions` (
  `id` int(11) NOT NULL COMMENT '配信ID',
  `start_timestamp` bigint(20) NOT NULL COMMENT '配信開始',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='運営からのプレゼント配信マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_present_pool_kinds`
--

DROP TABLE IF EXISTS `master_present_pool_kinds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_present_pool_kinds` (
  `id` int(11) NOT NULL COMMENT '保管種別ID',
  `name` varchar(40) NOT NULL COMMENT '保管種別名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレゼント保管種別マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_product_categories`
--

DROP TABLE IF EXISTS `master_product_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_product_categories` (
  `id` int(11) NOT NULL,
  `layer` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_product_categories_1` (`parent_id`),
  KEY `idx_master_product_categories_2` (`layer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_product_category_effects`
--

DROP TABLE IF EXISTS `master_product_category_effects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_product_category_effects` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '商品カテゴリ効果マスタ',
  `product_category_id` bigint(20) NOT NULL COMMENT '商品カテゴリID',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_product_category_effects_1` (`product_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品カテゴリ効果マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_product_containers`
--

DROP TABLE IF EXISTS `master_product_containers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_product_containers` (
  `id` int(11) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `container_id` bigint(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_product_effects`
--

DROP TABLE IF EXISTS `master_product_effects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_product_effects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) NOT NULL COMMENT '商品ID',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_product_effects_1` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_product_inventory_defaults`
--

DROP TABLE IF EXISTS `master_product_inventory_defaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_product_inventory_defaults` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) NOT NULL,
  `num` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_product_inventory_defaults_1` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_product_sell_effect_times`
--

DROP TABLE IF EXISTS `master_product_sell_effect_times`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_product_sell_effect_times` (
  `id` bigint(20) NOT NULL COMMENT '商品販売効果ID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `group_id` int(11) NOT NULL COMMENT 'グループID',
  `product_id` bigint(20) NOT NULL COMMENT '商品ID',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `start_at` time NOT NULL COMMENT '開始時間',
  `end_at` time NOT NULL COMMENT '終了時間',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_product_sell_effect_times_1` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品販売効果時間帯マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_product_sell_effects`
--

DROP TABLE IF EXISTS `master_product_sell_effects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_product_sell_effects` (
  `id` bigint(20) NOT NULL COMMENT '商品販売効果ID',
  `product_id` bigint(20) NOT NULL COMMENT '商品販売効果ID',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `start_at` datetime NOT NULL COMMENT '開始日時',
  `end_at` datetime NOT NULL COMMENT '終了日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_product_sell_effects_1` (`product_id`,`start_at`,`end_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品販売効果マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_product_sell_rewards`
--

DROP TABLE IF EXISTS `master_product_sell_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_product_sell_rewards` (
  `id` bigint(20) NOT NULL COMMENT '商品販売報酬ID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `group_id` int(11) NOT NULL COMMENT 'グループID',
  `product_id` bigint(20) NOT NULL COMMENT '商品ID',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `present_subject` varchar(40) DEFAULT NULL COMMENT 'プレゼント名目',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_product_sell_rewards_1` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品販売報酬';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_product_specs`
--

DROP TABLE IF EXISTS `master_product_specs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_product_specs` (
  `id` int(11) NOT NULL,
  `layer` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `description` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_products`
--

DROP TABLE IF EXISTS `master_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_products` (
  `id` bigint(20) NOT NULL COMMENT 'ID',
  `product_category_id` int(11) NOT NULL COMMENT '商品カテゴリID',
  `product_spec_id` int(11) NOT NULL COMMENT '商品規格ID',
  `partner_company_id` int(11) NOT NULL DEFAULT '-1' COMMENT '協賛企業ID',
  `rarity_id` int(11) NOT NULL COMMENT 'レアリティID',
  `sell_price` int(11) NOT NULL COMMENT '売却額',
  `dealer_store_point` int(11) NOT NULL COMMENT '必要ストアポイント',
  `dealer_guest_point` int(11) NOT NULL COMMENT '必要ゲストポイント',
  `dealer_wait_time` int(11) NOT NULL COMMENT '仕入れ待ち時間',
  `ask_num_max` int(11) NOT NULL COMMENT '販売個数最大',
  `ask_price_min` int(11) NOT NULL COMMENT '販売個数最小',
  `ask_price_max` int(11) NOT NULL COMMENT '販売価格最大',
  `ask_price_div` int(11) NOT NULL COMMENT '販売価格刻み',
  `add_motivation` int(11) NOT NULL DEFAULT '0' COMMENT '加算するやる気値（ベース値）',
  `release_at` datetime NOT NULL COMMENT '公開日',
  `is_player_buy` int(11) DEFAULT NULL COMMENT 'プレイヤー購入可能フラグ',
  `name` varchar(40) NOT NULL COMMENT '名前',
  `name_kana` varchar(80) NOT NULL COMMENT 'カナ',
  `description` text NOT NULL COMMENT '詳細',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_products_1` (`rarity_id`,`product_category_id`),
  KEY `idx_master_products_2` (`product_category_id`),
  KEY `idx_master_products_3` (`name_kana`,`product_category_id`),
  KEY `idx_master_products_4` (`rarity_id`,`product_spec_id`),
  KEY `idx_master_products_5` (`product_spec_id`),
  KEY `idx_master_products_6` (`name_kana`,`product_spec_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_push_quest_clear_lot_rewards`
--

DROP TABLE IF EXISTS `master_push_quest_clear_lot_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_push_quest_clear_lot_rewards` (
  `id` int(11) NOT NULL COMMENT 'クリア報酬抽選ID',
  `push_quest_id` int(11) NOT NULL COMMENT 'プッシュクエストID',
  `weight` int(11) NOT NULL COMMENT '確率',
  `is_correct` int(11) NOT NULL COMMENT 'あたりフラグ',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `present_subject` tinytext NOT NULL COMMENT 'プレゼント名目',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_push_quest_clear_lot_rewards_1` (`push_quest_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プッシュクエストクリア報酬抽選';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_push_quest_clear_rewards`
--

DROP TABLE IF EXISTS `master_push_quest_clear_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_push_quest_clear_rewards` (
  `id` int(11) NOT NULL COMMENT 'クリア報酬ID',
  `push_quest_id` int(11) NOT NULL COMMENT 'プッシュクエストID',
  `clear_num` int(11) NOT NULL COMMENT 'クリア回数',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `present_subject` tinytext NOT NULL COMMENT 'プレゼント名目',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_push_quest_clear_rewards_1` (`push_quest_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プッシュクエストクリア報酬';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_push_quest_drop_items`
--

DROP TABLE IF EXISTS `master_push_quest_drop_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_push_quest_drop_items` (
  `id` int(11) NOT NULL COMMENT 'ドロップアイテムID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `name` varchar(40) NOT NULL COMMENT '名前',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_push_quest_drop_items_1` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='クエストドロップアイテムマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_push_quest_list_clear_rewards`
--

DROP TABLE IF EXISTS `master_push_quest_list_clear_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_push_quest_list_clear_rewards` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `push_quest_list_id` int(11) NOT NULL COMMENT 'プッシュクエストリストID',
  `clear_num` int(11) NOT NULL COMMENT 'プッシュクエストID',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `present_subject` tinytext NOT NULL COMMENT 'プレゼント名目',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_push_quest_list_clear_rewards_1` (`push_quest_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プッシュクエストリストクリア報酬';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_push_quest_lists`
--

DROP TABLE IF EXISTS `master_push_quest_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_push_quest_lists` (
  `id` int(11) NOT NULL COMMENT 'プッシュクエストリストID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `push_quest_id` int(11) NOT NULL COMMENT 'プッシュクエストID',
  `next_push_quest_list_id` int(11) NOT NULL COMMENT '次のプッシュクエストリストID',
  `use_point` int(11) NOT NULL COMMENT '消費ポイント',
  `progress_num` int(11) NOT NULL COMMENT '実行回数',
  `name` varchar(40) NOT NULL COMMENT '名前',
  `description` text COMMENT '説明',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_push_quest_lists_1` (`event_id`,`push_quest_id`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プッシュクエストリストマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_push_quest_lot_complete_rewards`
--

DROP TABLE IF EXISTS `master_push_quest_lot_complete_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_push_quest_lot_complete_rewards` (
  `id` int(11) NOT NULL COMMENT 'コンプ報酬ID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `push_quest_id` int(11) NOT NULL COMMENT 'プッシュクエストID',
  `push_quest_list_id` int(11) NOT NULL COMMENT 'プッシュクエストリストID',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `present_subject` tinytext NOT NULL COMMENT 'プレゼント名目',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_push_quest_lot_complete_rewards_1` (`event_id`,`push_quest_id`,`push_quest_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プッシュクエストコンプ報酬';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_push_quest_lot_lists`
--

DROP TABLE IF EXISTS `master_push_quest_lot_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_push_quest_lot_lists` (
  `id` int(11) NOT NULL COMMENT '抽選リストID',
  `push_quest_list_id` int(11) NOT NULL COMMENT 'プッシュクエストリストID',
  `lot_kind_id` smallint(6) NOT NULL COMMENT '抽選種別',
  `weight` int(11) NOT NULL COMMENT 'ウエイト',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `description` text NOT NULL COMMENT '説明文',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_push_quest_lot_lists_1` (`push_quest_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プッシュクエスト抽選マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_push_quests`
--

DROP TABLE IF EXISTS `master_push_quests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_push_quests` (
  `id` int(11) NOT NULL COMMENT 'プッシュクエストID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `next_push_quest_id` int(11) NOT NULL COMMENT '次のプッシュクエストID',
  `list_loop_flag` smallint(6) NOT NULL COMMENT 'ステージループ有無',
  `init_open` smallint(6) NOT NULL COMMENT '初期解放フラグ',
  `start_at` datetime NOT NULL COMMENT '表示開始日時',
  `end_at` datetime NOT NULL COMMENT '表示終了日時',
  `name` varchar(40) NOT NULL COMMENT '名前',
  `description` text COMMENT '説明',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_push_quests_1` (`start_at`,`end_at`,`event_id`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プッシュクエストマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_quest_conditions`
--

DROP TABLE IF EXISTS `master_quest_conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_quest_conditions` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `quest_list_id` int(11) NOT NULL COMMENT 'クエスト一覧ID',
  `counter_kind_id` int(11) NOT NULL COMMENT 'カウンタID',
  `target_id` bigint(20) NOT NULL DEFAULT '-1' COMMENT '対象ID',
  `count_value` int(11) NOT NULL COMMENT '必要数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_quest_conditions_1` (`quest_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_quest_lists`
--

DROP TABLE IF EXISTS `master_quest_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_quest_lists` (
  `id` int(11) NOT NULL COMMENT 'クエスト一覧ID',
  `next_id` int(11) NOT NULL DEFAULT '-1' COMMENT '次のクエストID',
  `quest_id` int(11) NOT NULL COMMENT 'クエストID',
  `is_first` int(11) NOT NULL DEFAULT '0' COMMENT '最初のクエストID',
  `start_at` datetime NOT NULL COMMENT '公開開始日',
  `end_at` datetime NOT NULL COMMENT '公開終了日',
  `name` varchar(80) NOT NULL COMMENT 'クエスト名',
  `description` text COMMENT '詳細',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_quest_lists_1` (`quest_id`,`start_at`,`end_at`),
  KEY `idx_master_quest_lists_2` (`is_first`,`start_at`,`end_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='クエスト一覧マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_quest_rewards`
--

DROP TABLE IF EXISTS `master_quest_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_quest_rewards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quest_list_id` int(11) NOT NULL COMMENT 'クエスト一覧ID',
  `reward_priority` smallint(6) NOT NULL COMMENT '付与優先度',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_quest_rewards_1` (`quest_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_quest_valid_times`
--

DROP TABLE IF EXISTS `master_quest_valid_times`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_quest_valid_times` (
  `id` bigint(20) NOT NULL COMMENT 'クエスト有効時間ID',
  `quest_list_id` int(11) NOT NULL COMMENT 'クエストID',
  `start_at` time NOT NULL COMMENT '開始時間',
  `end_at` time NOT NULL COMMENT '終了時間',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_quest_valid_times_1` (`quest_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='クエスト有効時間';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_quests`
--

DROP TABLE IF EXISTS `master_quests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_quests` (
  `id` int(11) NOT NULL COMMENT 'クエストID',
  `name` varchar(80) NOT NULL COMMENT 'クエスト名',
  `view_kind_id` int(11) NOT NULL COMMENT '表示種別',
  `event_id` int(11) NOT NULL DEFAULT '-1' COMMENT 'イベントID',
  `start_at` datetime NOT NULL COMMENT '公開開始日',
  `end_at` datetime NOT NULL COMMENT '公開終了日',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_quests_1` (`start_at`,`end_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='クエストマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_quote_coefficients`
--

DROP TABLE IF EXISTS `master_quote_coefficients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_quote_coefficients` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '気配係数マスタ',
  `player_kind` int(11) NOT NULL COMMENT 'プレイヤー種別',
  `target_kind` int(11) NOT NULL COMMENT '対象種別',
  `target_id` bigint(20) NOT NULL COMMENT '対象ID',
  `priority` int(11) NOT NULL COMMENT '優先度',
  `month` int(11) DEFAULT NULL COMMENT '月',
  `day_of_week` int(11) DEFAULT NULL COMMENT '曜日',
  `hour` int(11) DEFAULT NULL COMMENT '時',
  `start_at` datetime NOT NULL COMMENT '開始日時',
  `end_at` datetime NOT NULL COMMENT '終了日時',
  `coefficient` int(11) NOT NULL COMMENT '係数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_master_quote_coefficients_1` (`player_kind`,`target_kind`,`target_id`,`priority`,`month`,`day_of_week`,`hour`,`start_at`,`end_at`),
  KEY `idx_master_quote_coefficients_2` (`player_kind`,`target_kind`,`target_id`,`priority`,`day_of_week`,`hour`,`start_at`,`end_at`),
  KEY `idx_master_quote_coefficients_3` (`player_kind`,`target_kind`,`target_id`,`priority`,`month`,`start_at`,`end_at`),
  KEY `idx_master_quote_coefficients_4` (`player_kind`,`target_kind`,`target_id`,`priority`,`day_of_week`,`start_at`,`end_at`),
  KEY `idx_master_quote_coefficients_5` (`player_kind`,`target_kind`,`target_id`,`priority`,`hour`,`start_at`,`end_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='気配係数マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_quote_descriptions`
--

DROP TABLE IF EXISTS `master_quote_descriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_quote_descriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '気配説明マスタ',
  `target_kind` int(11) NOT NULL COMMENT '対象種別',
  `target_id` bigint(20) NOT NULL COMMENT '対象ID',
  `start_at` datetime NOT NULL COMMENT '開始日時',
  `end_at` datetime NOT NULL COMMENT '終了日時',
  `description` text NOT NULL COMMENT '気配説明',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_master_quote_descriptions_1` (`target_kind`,`target_id`,`start_at`,`end_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='気配説明マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_quote_thresholds`
--

DROP TABLE IF EXISTS `master_quote_thresholds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_quote_thresholds` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '気配閾値マスタ',
  `target_kind` int(11) NOT NULL COMMENT '対象種別',
  `target_id` bigint(20) NOT NULL COMMENT '対象ID',
  `quote_value` int(11) NOT NULL COMMENT '気配値',
  `start_at` datetime NOT NULL COMMENT '開始日時',
  `end_at` datetime NOT NULL COMMENT '終了日時',
  `threshold` int(11) NOT NULL COMMENT '閾値',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_master_quote_thresholds_1` (`target_kind`,`target_id`,`quote_value`,`start_at`,`end_at`),
  KEY `idx_master_quote_thresholds_2` (`target_kind`,`start_at`,`end_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='気配閾値マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_raid_levels`
--

DROP TABLE IF EXISTS `master_raid_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_raid_levels` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `raid_id` int(11) NOT NULL COMMENT 'レイドレベルID',
  `next_raid_level_id` int(11) DEFAULT '-1' COMMENT '次のレベルID',
  `is_first_level` tinyint(4) DEFAULT '0' COMMENT '最初のレベルかどうかのフラグ',
  `lv` smallint(6) NOT NULL COMMENT 'レベル',
  `hp` mediumint(9) NOT NULL COMMENT 'HP',
  `appear_time_sec` mediumint(9) NOT NULL COMMENT '制限時間(秒)',
  `reward_subject_num` tinyint(4) NOT NULL COMMENT '報酬付与対象人数',
  `trg_point_id` int(11) NOT NULL COMMENT '条件となるポイントID',
  `trg_point_value` int(11) NOT NULL COMMENT '条件ポイント数',
  `name` varchar(255) NOT NULL COMMENT 'レイドボス名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_raid_levels_1` (`raid_id`,`is_first_level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='マスターレイドレベルデータ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_raid_play_get_cookies`
--

DROP TABLE IF EXISTS `master_raid_play_get_cookies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_raid_play_get_cookies` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `raid_play_id` int(11) NOT NULL COMMENT 'レイドプレイレベルID',
  `weight` int(11) NOT NULL COMMENT '確率',
  `get_cookies` smallint(6) NOT NULL COMMENT '必要クッキー',
  `get_max` tinyint(4) NOT NULL DEFAULT '-1' COMMENT '取得限界',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_raid_play_get_cookies_1` (`raid_play_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='マスターレイドインゲームデータ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_raid_plays`
--

DROP TABLE IF EXISTS `master_raid_plays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_raid_plays` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `raid_level_id` int(11) NOT NULL COMMENT 'レイドレベルID',
  `route_id` tinyint(4) NOT NULL COMMENT 'ルートID',
  `require_ap` tinyint(4) NOT NULL COMMENT '必要コスト',
  `drop_min` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'ドロップ数最小',
  `drop_max` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'ドロップ数最大',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_master_raid_plays_1` (`raid_level_id`,`route_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='マスターレイドインゲームデータ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_raid_rewards`
--

DROP TABLE IF EXISTS `master_raid_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_raid_rewards` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `raid_level_id` int(11) NOT NULL COMMENT 'レイドレベルID',
  `rank_min` tinyint(4) NOT NULL COMMENT '付与ランク最小',
  `rank_max` tinyint(4) NOT NULL COMMENT '付与ランク最大',
  `reward_type` tinyint(4) NOT NULL COMMENT '報酬タイプ',
  `priority` int(11) NOT NULL COMMENT '優先度',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_raid_rewards_1` (`raid_level_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='マスターレイド報酬データ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_raids`
--

DROP TABLE IF EXISTS `master_raids`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_raids` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `start_at` datetime NOT NULL COMMENT '開始日',
  `end_at` datetime NOT NULL COMMENT '開始日',
  `name` varchar(255) NOT NULL COMMENT 'レイド名',
  `description` text COMMENT 'レイド詳細',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_raids_1` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='マスターレイドデータ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_rarities`
--

DROP TABLE IF EXISTS `master_rarities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_rarities` (
  `id` int(11) NOT NULL,
  `name` tinytext NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_regions`
--

DROP TABLE IF EXISTS `master_regions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_regions` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_shop_categories`
--

DROP TABLE IF EXISTS `master_shop_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_shop_categories` (
  `id` int(11) NOT NULL,
  `layer` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_shop_category_sales`
--

DROP TABLE IF EXISTS `master_shop_category_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_shop_category_sales` (
  `id` int(11) NOT NULL COMMENT 'ショップカテゴリセールID',
  `shop_category_id` int(11) NOT NULL COMMENT 'ショップカテゴリID',
  `start_at` datetime NOT NULL COMMENT 'セール開始日時',
  `end_at` datetime NOT NULL COMMENT 'セール終了日時',
  `description` text COMMENT '説明',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_shop_category_sales_1` (`start_at`,`end_at`,`shop_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ショップカテゴリセールマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_shop_group_unit_kinds`
--

DROP TABLE IF EXISTS `master_shop_group_unit_kinds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_shop_group_unit_kinds` (
  `id` int(11) NOT NULL COMMENT 'グループ種別ID',
  `banner_view_kind_id` int(11) NOT NULL DEFAULT '-1' COMMENT 'バナー表示種別',
  `name` varchar(40) NOT NULL COMMENT 'グループ名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ショップグループ種別マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_shop_group_units`
--

DROP TABLE IF EXISTS `master_shop_group_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_shop_group_units` (
  `id` int(11) NOT NULL COMMENT 'グループユニットID',
  `shop_group_id` int(11) NOT NULL COMMENT 'ショップグループID',
  `shop_group_unit_kind_id` int(11) NOT NULL COMMENT 'グループ種別ID',
  `start_at` datetime NOT NULL COMMENT '開始日時',
  `end_at` datetime NOT NULL COMMENT '終了日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ショップグループユニットマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_shops`
--

DROP TABLE IF EXISTS `master_shops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_shops` (
  `id` int(11) NOT NULL COMMENT 'ショップID',
  `event_id` int(11) NOT NULL DEFAULT '-1' COMMENT 'イベントID',
  `item_id` int(11) NOT NULL COMMENT 'アイテムID',
  `group_id` int(11) NOT NULL DEFAULT '-1' COMMENT 'グルーピングID',
  `shop_category_id` int(11) NOT NULL COMMENT 'ショップカテゴリID',
  `point_id` int(11) NOT NULL,
  `buy_price` int(11) NOT NULL COMMENT '販売価格',
  `is_num_selectable` tinyint(4) NOT NULL DEFAULT '1' COMMENT '個数選択可能か',
  `is_executable` tinyint(4) NOT NULL DEFAULT '0' COMMENT '購入後即実行',
  `buy_limit` int(11) NOT NULL DEFAULT '-1' COMMENT '購入制限',
  `buy_limit_kind` smallint(6) NOT NULL COMMENT '購入制限種別shubetu',
  `buy_limit_priority` int(11) NOT NULL COMMENT '購入制限優先順位',
  `buy_interval` int(11) NOT NULL COMMENT '購入可能間隔',
  `is_beginner` smallint(6) NOT NULL DEFAULT '0' COMMENT '初心者フラグ',
  `start_at` datetime DEFAULT NULL COMMENT '販売開始日時',
  `end_at` datetime DEFAULT NULL COMMENT '販売終了日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `present_comment` varchar(100) DEFAULT NULL COMMENT 'プレゼント格納用コメント',
  PRIMARY KEY (`id`),
  KEY `idx_master_shops_1` (`item_id`),
  KEY `idx_master_shops_2` (`shop_category_id`),
  KEY `idx_master_shops_3` (`start_at`,`end_at`,`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ショップマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_stamp_rewards`
--

DROP TABLE IF EXISTS `master_stamp_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_stamp_rewards` (
  `id` int(11) NOT NULL COMMENT 'スタンプ報酬ID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `stamp_id` int(11) NOT NULL COMMENT 'スタンプID',
  `condition_value` int(11) NOT NULL COMMENT '付与条件数',
  `loop_condition_value` int(11) NOT NULL COMMENT 'ループ付与条件数',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `present_subject` varchar(40) DEFAULT NULL COMMENT 'プレゼント名目',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_stamp_rewards_1` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='スタンプ報酬マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_stamps`
--

DROP TABLE IF EXISTS `master_stamps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_stamps` (
  `id` bigint(20) NOT NULL COMMENT 'スタンプID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `stamp_num` int(11) NOT NULL COMMENT '1シートのスタンプ数',
  `start_at` datetime NOT NULL COMMENT '開始時間',
  `end_at` datetime NOT NULL COMMENT '終了時間',
  `name` tinytext NOT NULL COMMENT 'スタンプ名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_stamps_1` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='スタンプ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_store_genres`
--

DROP TABLE IF EXISTS `master_store_genres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_store_genres` (
  `id` int(11) NOT NULL,
  `layer` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_store_image_ranking_rewards`
--

DROP TABLE IF EXISTS `master_store_image_ranking_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_store_image_ranking_rewards` (
  `id` bigint(20) NOT NULL COMMENT 'ランキング報酬ID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `ranking_min` int(11) NOT NULL COMMENT 'ランキングmin',
  `ranking_max` int(11) NOT NULL COMMENT 'ランキングmax',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `present_subject` varchar(40) DEFAULT NULL COMMENT 'プレゼント名目',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_store_image_ranking_rewards_1` (`event_id`,`ranking_min`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='店舗外観ランキング報酬';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_store_names`
--

DROP TABLE IF EXISTS `master_store_names`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_store_names` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_title_conditions`
--

DROP TABLE IF EXISTS `master_title_conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_title_conditions` (
  `id` int(11) NOT NULL,
  `title_id` int(11) NOT NULL,
  `done_id` int(11) NOT NULL,
  `class_id` varchar(40) NOT NULL,
  `arg1` varchar(40) DEFAULT NULL,
  `arg2` varchar(40) DEFAULT NULL,
  `arg3` varchar(40) DEFAULT NULL,
  `arg4` varchar(40) DEFAULT NULL,
  `arg5` varchar(40) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_title_conditions_1` (`title_id`),
  KEY `idx_master_title_conditions_2` (`done_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_title_kinds`
--

DROP TABLE IF EXISTS `master_title_kinds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_title_kinds` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_title_prereqs`
--

DROP TABLE IF EXISTS `master_title_prereqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_title_prereqs` (
  `id` bigint(20) NOT NULL COMMENT '称号必要条件ID',
  `title_id` int(11) NOT NULL COMMENT '称号ID',
  `prereq_title_id` int(11) NOT NULL COMMENT '必要条件とする称号ID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_master_title_prereqs_1` (`title_id`,`prereq_title_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='称号必要条件マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_titles`
--

DROP TABLE IF EXISTS `master_titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_titles` (
  `id` int(11) NOT NULL,
  `title_kind_id` int(11) NOT NULL,
  `name` varchar(24) NOT NULL COMMENT '称号名',
  `description` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_titles_1` (`title_kind_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_tpoint_caps`
--

DROP TABLE IF EXISTS `master_tpoint_caps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_tpoint_caps` (
  `id` int(11) NOT NULL COMMENT 'Tポイント上限ID',
  `cap_cnt` int(11) NOT NULL COMMENT '上限回数',
  `fallback_point` int(11) NOT NULL COMMENT 'フォールバックTポイント数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tポイント上限マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_tpoint_kinds`
--

DROP TABLE IF EXISTS `master_tpoint_kinds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_tpoint_kinds` (
  `id` int(11) NOT NULL COMMENT 'Tポイント種別ID',
  `name` varchar(80) NOT NULL COMMENT 'Tポイント種別名',
  `start_at` datetime NOT NULL COMMENT '開始日時',
  `end_at` datetime NOT NULL COMMENT '終了日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_tpoint_kinds_1` (`start_at`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tポイント種別マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_tpoint_periods`
--

DROP TABLE IF EXISTS `master_tpoint_periods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_tpoint_periods` (
  `id` int(11) NOT NULL COMMENT 'Tポイント期間ID',
  `tpoint_kind_id` int(11) NOT NULL COMMENT 'Tポイント種別ID',
  `start_at` datetime NOT NULL COMMENT '開始日時',
  `end_at` datetime NOT NULL COMMENT '終了日時',
  `add_at_str` varchar(40) NOT NULL COMMENT 'ポイント付与日文言',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_tpoint_periods_1` (`tpoint_kind_id`,`start_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tポイント期間マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_treasure_rewards`
--

DROP TABLE IF EXISTS `master_treasure_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_treasure_rewards` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `treasure_id` int(11) NOT NULL COMMENT '宝箱ID',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `present_subject` varchar(255) DEFAULT NULL COMMENT 'プレゼント件名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_treasure_rewards_1` (`treasure_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='宝箱報酬マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_treasures`
--

DROP TABLE IF EXISTS `master_treasures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_treasures` (
  `id` int(11) NOT NULL COMMENT '宝箱ID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `name` varchar(40) NOT NULL COMMENT '宝箱名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_treasures_1` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='宝箱マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_tutorial_ondemands`
--

DROP TABLE IF EXISTS `master_tutorial_ondemands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_tutorial_ondemands` (
  `id` int(11) NOT NULL COMMENT 'フラグID',
  `view_kind_id` int(11) NOT NULL COMMENT '表示種別',
  `route_to` varchar(40) NOT NULL COMMENT 'ルーティング',
  `name` varchar(80) NOT NULL COMMENT 'フラグ名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_master_tutorial_ondemands_1` (`view_kind_id`,`route_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='チュートリアル都度管理マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_tutorial_rewards`
--

DROP TABLE IF EXISTS `master_tutorial_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_tutorial_rewards` (
  `id` int(11) NOT NULL COMMENT 'チュートリアル報酬ID',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `start_at` datetime NOT NULL COMMENT '開始日時',
  `end_at` datetime NOT NULL COMMENT '終了日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='チュートリアル報酬マスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_tutorials`
--

DROP TABLE IF EXISTS `master_tutorials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_tutorials` (
  `id` int(11) NOT NULL COMMENT 'チュートリアルID',
  `next_tutorial_id` int(11) NOT NULL DEFAULT '-1' COMMENT '次のチュートリアルID',
  `route_to` varchar(40) NOT NULL COMMENT 'ルーティング',
  `name` varchar(40) NOT NULL COMMENT 'チュートリアル名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_master_tutorials_1` (`route_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='チュートリアルマスタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `master_update_infos`
--

DROP TABLE IF EXISTS `master_update_infos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_update_infos` (
  `id` int(11) NOT NULL COMMENT 'アップデート情報ID',
  `subject` varchar(40) NOT NULL COMMENT 'タイトル',
  `body` text NOT NULL COMMENT '本文',
  `start_at` datetime NOT NULL COMMENT '表示開始日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='アップデート情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_alliance_accumulation_counters`
--

DROP TABLE IF EXISTS `player_alliance_accumulation_counters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_alliance_accumulation_counters` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーアライアンス累積カウンターID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `alliance_id` int(11) NOT NULL COMMENT 'アライアンスID',
  `accumulation_kind` int(11) NOT NULL COMMENT '累積種別',
  `accumulation_num` int(11) NOT NULL COMMENT '累積回数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_alliance_accumulation_counters_1` (`spid`,`alliance_id`,`accumulation_kind`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーアライアンス累積カウンター';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_alliance_counters`
--

DROP TABLE IF EXISTS `player_alliance_counters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_alliance_counters` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーアライアンスカウンターID',
  `spid` bigint(20) NOT NULL,
  `alliance_id` int(11) NOT NULL COMMENT 'アライアンスID',
  `accumulation_kind` int(11) NOT NULL COMMENT '累積種別',
  `accumulation_num` int(11) NOT NULL COMMENT '累積回数',
  `daily_num` int(11) DEFAULT NULL COMMENT '日次回数',
  `use_at` date NOT NULL COMMENT '使用日',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_alliance_counters_1` (`spid`,`alliance_id`,`accumulation_kind`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーアライアンスカウンター';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_alliance_daily_counters`
--

DROP TABLE IF EXISTS `player_alliance_daily_counters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_alliance_daily_counters` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーアライアンス日次カウンターID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `alliance_id` int(11) NOT NULL COMMENT 'アライアンスID',
  `huseDate` date NOT NULL COMMENT '履歴受付年月日',
  `hpresentCnt` int(11) NOT NULL COMMENT '提示回数',
  `hpt` int(11) NOT NULL COMMENT '利用ポイント数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_alliance_daily_counters_1` (`spid`,`alliance_id`,`huseDate`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーアライアンス日次カウンター';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_announces`
--

DROP TABLE IF EXISTS `player_announces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_announces` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `announce_id` int(11) NOT NULL COMMENT '告知ID',
  `read_at` datetime NOT NULL COMMENT '閲覧日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_announces_1` (`spid`,`announce_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_avatar_inventories`
--

DROP TABLE IF EXISTS `player_avatar_inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_avatar_inventories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `avatar_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_avatar_inventories_1` (`spid`,`avatar_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_avatar_settings`
--

DROP TABLE IF EXISTS `player_avatar_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_avatar_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'アバター設定種別データ',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `active_avatar_kind_id` int(11) NOT NULL COMMENT '設定種別ID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_avatar_settings_1` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='アバター設定種別データ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_avatars`
--

DROP TABLE IF EXISTS `player_avatars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_avatars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `avatar_id` int(11) NOT NULL,
  `parent_avatar_id` int(11) NOT NULL DEFAULT '-1' COMMENT 'セットアバターのID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_avatars_1` (`spid`,`avatar_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_banners`
--

DROP TABLE IF EXISTS `player_banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーバナー閲覧状況',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `read_at` datetime NOT NULL COMMENT '閲覧日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_banners_1` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーバナー閲覧状況';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_cat_points`
--

DROP TABLE IF EXISTS `player_cat_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_cat_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーねこの鈴',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `value` bigint(20) NOT NULL COMMENT '所持数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_cat_points_1` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーねこの鈴';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_cats`
--

DROP TABLE IF EXISTS `player_cats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_cats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `no` int(11) NOT NULL DEFAULT '0',
  `lot_at` datetime NOT NULL,
  `max_num` int(11) NOT NULL,
  `get_num` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_cats_1` (`spid`,`no`),
  KEY `idx_player_cats_2` (`spid`,`lot_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_clerk_inventories`
--

DROP TABLE IF EXISTS `player_clerk_inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_clerk_inventories` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤー販売員',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `clerk_id` int(11) NOT NULL COMMENT '販売員マスタID',
  `num` int(11) NOT NULL COMMENT '販売員数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_clerk_inventories_1` (`spid`,`clerk_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤー販売員';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_collection_rewards`
--

DROP TABLE IF EXISTS `player_collection_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_collection_rewards` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤー図鑑報酬受け取り状況',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `reward_id` int(11) NOT NULL COMMENT '報酬ID',
  `num` int(11) NOT NULL COMMENT '付与回数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_collection_rewards_1` (`spid`,`reward_id`),
  KEY `idx_player_collection_rewards_2` (`reward_id`,`num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤー図鑑報酬受け取り状況';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_collections`
--

DROP TABLE IF EXISTS `player_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_collections` (
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `collection_num` int(11) NOT NULL COMMENT '図鑑登録数',
  `product_num` int(11) NOT NULL COMMENT '商品登録数',
  `container_num` int(11) NOT NULL COMMENT '什器登録数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`spid`),
  KEY `idx_player_collections_1` (`collection_num`,`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤー図鑑';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_configs`
--

DROP TABLE IF EXISTS `player_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `config_id` varchar(40) NOT NULL,
  `value` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_configs_1` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_container_collections`
--

DROP TABLE IF EXISTS `player_container_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_container_collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `container_id` bigint(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_container_collections_1` (`spid`,`container_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_container_displays`
--

DROP TABLE IF EXISTS `player_container_displays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_container_displays` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤー什器陳列情報',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `store_id` int(11) NOT NULL COMMENT 'ストアID',
  `container_inventory_id` int(11) NOT NULL COMMENT '什器在庫ID',
  `x` smallint(6) NOT NULL DEFAULT '0' COMMENT 'X座標',
  `y` smallint(6) NOT NULL DEFAULT '0' COMMENT 'Y座標',
  `layer` int(11) NOT NULL DEFAULT '0' COMMENT 'レイヤー番号',
  `is_reverse` tinyint(4) NOT NULL DEFAULT '0' COMMENT '反転の有無',
  `lock_version` int(11) NOT NULL DEFAULT '0' COMMENT 'バージョン番号',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_container_displays_1` (`spid`,`store_id`,`container_inventory_id`),
  KEY `idx_player_container_displays_2` (`container_inventory_id`,`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤー什器陳列情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_container_effects`
--

DROP TABLE IF EXISTS `player_container_effects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_container_effects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `container_inventory_id` int(11) NOT NULL COMMENT '対象inventoryId',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_container_effects_1` (`spid`,`container_inventory_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_container_growths`
--

DROP TABLE IF EXISTS `player_container_growths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_container_growths` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `container_inventory_id` int(11) NOT NULL COMMENT '什器在庫ID',
  `status` smallint(6) NOT NULL COMMENT 'ステータス',
  `next_lv` int(11) NOT NULL COMMENT '次のレベル',
  `growth_id` int(11) NOT NULL COMMENT '成長ID',
  `growth_at` datetime NOT NULL COMMENT 'レベルアップ予定日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_container_growths_1` (`spid`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_container_inventories`
--

DROP TABLE IF EXISTS `player_container_inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_container_inventories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `container_id` bigint(20) NOT NULL,
  `lv` int(11) NOT NULL DEFAULT '1' COMMENT 'レベル',
  `quality` int(11) NOT NULL DEFAULT '1' COMMENT 'クオリティ',
  `quality_exp` int(11) NOT NULL DEFAULT '0' COMMENT 'クオリティ経験値',
  `quality_max` int(11) NOT NULL DEFAULT '0' COMMENT 'クオリティ上限',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_container_inventories_1` (`spid`,`container_id`),
  KEY `idx_player_container_inventories_2` (`container_id`,`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_container_synth_waits`
--

DROP TABLE IF EXISTS `player_container_synth_waits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_container_synth_waits` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤー什器合成待ちリスト',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `container_inventory_id` int(11) NOT NULL COMMENT '什器在庫ID',
  `add_exp` int(11) NOT NULL COMMENT '獲得経験値',
  `is_success` smallint(6) NOT NULL COMMENT '大成功フラグ',
  `complete_at` datetime NOT NULL COMMENT '完了日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_container_synth_waits_1` (`spid`,`container_inventory_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤー什器合成待ちリスト';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_counters`
--

DROP TABLE IF EXISTS `player_counters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_counters` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `target_id` bigint(20) NOT NULL COMMENT '対象ID',
  `counter_kind_id` int(11) NOT NULL COMMENT 'カウンタ種別',
  `counter_period_id` int(11) NOT NULL COMMENT '期間種別',
  `start_at` datetime NOT NULL COMMENT '開始日',
  `count_value` int(11) NOT NULL COMMENT '値',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_counters_2` (`spid`,`counter_kind_id`,`counter_period_id`,`start_at`),
  KEY `idx_player_counters_1` (`counter_kind_id`,`counter_period_id`,`start_at`,`target_id`,`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーカウンタ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_deal_containers`
--

DROP TABLE IF EXISTS `player_deal_containers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_deal_containers` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤー仕入れ什器',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `deal_span_id` int(11) NOT NULL COMMENT '仕入れスパンID',
  `dealer_container_id` bigint(20) NOT NULL COMMENT '問屋什器ID',
  `num` int(11) NOT NULL DEFAULT '0' COMMENT '仕入れ個数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_deal_containers_1` (`spid`,`deal_span_id`,`dealer_container_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤー仕入れ什器';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_deal_products`
--

DROP TABLE IF EXISTS `player_deal_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_deal_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤー仕入れ商品',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `deal_span_id` int(11) NOT NULL COMMENT '仕入れスパンID',
  `dealer_product_id` bigint(20) NOT NULL COMMENT '問屋商品ID',
  `num` int(11) NOT NULL DEFAULT '0' COMMENT '仕入れ個数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_deal_products_1` (`spid`,`deal_span_id`,`dealer_product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤー仕入れ商品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_deal_subject_unlock_lists`
--

DROP TABLE IF EXISTS `player_deal_subject_unlock_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_deal_subject_unlock_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤー問屋種別アンロックリスト',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `unlock_condition_id` int(11) NOT NULL COMMENT '問屋解放条件ID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_deal_subject_unlock_lists_1` (`spid`,`unlock_condition_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤー問屋種別アンロックリスト';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_deal_subject_unlocks`
--

DROP TABLE IF EXISTS `player_deal_subject_unlocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_deal_subject_unlocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤー問屋種別アンロック情報',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `dealer_id` int(11) NOT NULL COMMENT '問屋ID',
  `subject_kind` int(11) NOT NULL COMMENT '取扱種別',
  `subject_dealer_id` bigint(20) NOT NULL COMMENT '問屋商品ID or 問屋什器ID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_deal_subject_unlocks_1` (`spid`,`dealer_id`,`subject_kind`,`subject_dealer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤー問屋種別アンロック情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_deal_unlocks`
--

DROP TABLE IF EXISTS `player_deal_unlocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_deal_unlocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤー仕入れアンロック情報',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `dealer_id` int(11) NOT NULL COMMENT '問屋ID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_deal_unlocks_1` (`spid`,`dealer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤー仕入れアンロック情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_deal_wait_lists`
--

DROP TABLE IF EXISTS `player_deal_wait_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_deal_wait_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `deal_wait_id` int(11) NOT NULL COMMENT '仕入れ待ち枠ID',
  `dealer_id` int(11) NOT NULL COMMENT '問屋ID',
  `dealer_kind` int(11) NOT NULL COMMENT '問屋種別',
  `target_id` bigint(20) NOT NULL COMMENT '問屋什器ID or 問屋商品ID',
  `set_num` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_deal_wait_lists_1` (`spid`,`deal_wait_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_deal_waits`
--

DROP TABLE IF EXISTS `player_deal_waits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_deal_waits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `complete_at` datetime NOT NULL COMMENT '完了日時',
  `is_complete` tinyint(4) NOT NULL COMMENT '完了フラグ',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_deal_waits_1` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_diary_configs`
--

DROP TABLE IF EXISTS `player_diary_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_diary_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤー日記設定',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `visible_all` tinyint(4) NOT NULL COMMENT '全員公開設定',
  `visible_friend` tinyint(4) NOT NULL COMMENT '店とも公開設定',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_diary_configs_1` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤー日記設定';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_diary_contents`
--

DROP TABLE IF EXISTS `player_diary_contents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_diary_contents` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '日記内容ID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `subject` varchar(50) NOT NULL COMMENT '件名',
  `body` varchar(1100) NOT NULL COMMENT '本文',
  `content_created_at` datetime NOT NULL COMMENT '日記内容生成日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`,`created_at`),
  KEY `idx_player_diary_contents_1` (`spid`,`content_created_at`),
  KEY `idx_player_diary_contents_2` (`content_created_at`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='プレイヤー日記内容'
/*!50500 PARTITION BY RANGE  COLUMNS(created_at)
(PARTITION p201512 VALUES LESS THAN ('2016-01-01') ENGINE = InnoDB,
 PARTITION p201601 VALUES LESS THAN ('2016-02-01') ENGINE = InnoDB,
 PARTITION p201602 VALUES LESS THAN ('2016-03-01') ENGINE = InnoDB,
 PARTITION p201603 VALUES LESS THAN ('2016-04-01') ENGINE = InnoDB,
 PARTITION p201604 VALUES LESS THAN ('2016-05-01') ENGINE = InnoDB,
 PARTITION p201605 VALUES LESS THAN ('2016-06-01') ENGINE = InnoDB,
 PARTITION p201606 VALUES LESS THAN ('2016-07-01') ENGINE = InnoDB,
 PARTITION p201607 VALUES LESS THAN ('2016-08-01') ENGINE = InnoDB,
 PARTITION p201608 VALUES LESS THAN ('2016-09-01') ENGINE = InnoDB,
 PARTITION p201609 VALUES LESS THAN ('2016-10-01') ENGINE = InnoDB,
 PARTITION p201610 VALUES LESS THAN ('2016-11-01') ENGINE = InnoDB,
 PARTITION p201611 VALUES LESS THAN ('2016-12-01') ENGINE = InnoDB,
 PARTITION p201612 VALUES LESS THAN ('2017-01-01') ENGINE = InnoDB,
 PARTITION p201701 VALUES LESS THAN ('2017-02-01') ENGINE = InnoDB,
 PARTITION p201702 VALUES LESS THAN ('2017-03-01') ENGINE = InnoDB,
 PARTITION p201703 VALUES LESS THAN ('2017-04-01') ENGINE = InnoDB,
 PARTITION p201704 VALUES LESS THAN ('2017-05-01') ENGINE = InnoDB,
 PARTITION p201705 VALUES LESS THAN ('2017-06-01') ENGINE = InnoDB,
 PARTITION p201706 VALUES LESS THAN ('2017-07-01') ENGINE = InnoDB,
 PARTITION p201707 VALUES LESS THAN ('2017-08-01') ENGINE = InnoDB,
 PARTITION p201708 VALUES LESS THAN ('2017-09-01') ENGINE = InnoDB,
 PARTITION p201709 VALUES LESS THAN ('2017-10-01') ENGINE = InnoDB,
 PARTITION p201710 VALUES LESS THAN ('2017-11-01') ENGINE = InnoDB,
 PARTITION p201711 VALUES LESS THAN ('2017-12-01') ENGINE = InnoDB,
 PARTITION p201712 VALUES LESS THAN ('2018-01-01') ENGINE = InnoDB,
 PARTITION p201801 VALUES LESS THAN ('2018-02-01') ENGINE = InnoDB,
 PARTITION p201802 VALUES LESS THAN ('2018-03-01') ENGINE = InnoDB,
 PARTITION p201803 VALUES LESS THAN ('2018-04-01') ENGINE = InnoDB,
 PARTITION p201804 VALUES LESS THAN ('2018-05-01') ENGINE = InnoDB,
 PARTITION p201805 VALUES LESS THAN ('2018-06-01') ENGINE = InnoDB,
 PARTITION p201806 VALUES LESS THAN ('2018-07-01') ENGINE = InnoDB,
 PARTITION p201807 VALUES LESS THAN ('2018-08-01') ENGINE = InnoDB,
 PARTITION p201808 VALUES LESS THAN ('2018-09-01') ENGINE = InnoDB,
 PARTITION p201809 VALUES LESS THAN ('2018-10-01') ENGINE = InnoDB,
 PARTITION p201810 VALUES LESS THAN ('2018-11-01') ENGINE = InnoDB,
 PARTITION p201811 VALUES LESS THAN ('2018-12-01') ENGINE = InnoDB,
 PARTITION p201812 VALUES LESS THAN ('2019-01-01') ENGINE = InnoDB,
 PARTITION p201901 VALUES LESS THAN ('2019-02-01') ENGINE = InnoDB,
 PARTITION p201902 VALUES LESS THAN ('2019-03-01') ENGINE = InnoDB,
 PARTITION p201903 VALUES LESS THAN ('2019-04-01') ENGINE = InnoDB,
 PARTITION p201904 VALUES LESS THAN ('2019-05-01') ENGINE = InnoDB,
 PARTITION p201905 VALUES LESS THAN ('2019-06-01') ENGINE = InnoDB,
 PARTITION p201906 VALUES LESS THAN ('2019-07-01') ENGINE = InnoDB,
 PARTITION p201907 VALUES LESS THAN ('2019-08-01') ENGINE = InnoDB,
 PARTITION p201908 VALUES LESS THAN ('2019-09-01') ENGINE = InnoDB,
 PARTITION p201909 VALUES LESS THAN ('2019-10-01') ENGINE = InnoDB,
 PARTITION p201910 VALUES LESS THAN ('2019-11-01') ENGINE = InnoDB,
 PARTITION p201911 VALUES LESS THAN ('2019-12-01') ENGINE = InnoDB,
 PARTITION p201912 VALUES LESS THAN ('2020-01-01') ENGINE = InnoDB,
 PARTITION p202001 VALUES LESS THAN ('2020-02-01') ENGINE = InnoDB,
 PARTITION p202002 VALUES LESS THAN ('2020-03-01') ENGINE = InnoDB,
 PARTITION p202003 VALUES LESS THAN ('2020-04-01') ENGINE = InnoDB,
 PARTITION p202004 VALUES LESS THAN ('2020-05-01') ENGINE = InnoDB,
 PARTITION p202005 VALUES LESS THAN ('2020-06-01') ENGINE = InnoDB,
 PARTITION p202006 VALUES LESS THAN ('2020-07-01') ENGINE = InnoDB,
 PARTITION p202007 VALUES LESS THAN ('2020-08-01') ENGINE = InnoDB,
 PARTITION p202008 VALUES LESS THAN ('2020-09-01') ENGINE = InnoDB,
 PARTITION p202009 VALUES LESS THAN ('2020-10-01') ENGINE = InnoDB,
 PARTITION p202010 VALUES LESS THAN ('2020-11-01') ENGINE = InnoDB,
 PARTITION p202011 VALUES LESS THAN ('2020-12-01') ENGINE = InnoDB,
 PARTITION p202012 VALUES LESS THAN ('2021-01-01') ENGINE = InnoDB,
 PARTITION p202101 VALUES LESS THAN ('2021-02-01') ENGINE = InnoDB,
 PARTITION p202102 VALUES LESS THAN ('2021-03-01') ENGINE = InnoDB,
 PARTITION p202103 VALUES LESS THAN ('2021-04-01') ENGINE = InnoDB,
 PARTITION p202104 VALUES LESS THAN ('2021-05-01') ENGINE = InnoDB,
 PARTITION p202105 VALUES LESS THAN ('2021-06-01') ENGINE = InnoDB,
 PARTITION p202106 VALUES LESS THAN ('2021-07-01') ENGINE = InnoDB,
 PARTITION p202107 VALUES LESS THAN ('2021-08-01') ENGINE = InnoDB,
 PARTITION p202108 VALUES LESS THAN ('2021-09-01') ENGINE = InnoDB,
 PARTITION p202109 VALUES LESS THAN ('2021-10-01') ENGINE = InnoDB,
 PARTITION p202110 VALUES LESS THAN ('2021-11-01') ENGINE = InnoDB,
 PARTITION p202111 VALUES LESS THAN ('2021-12-01') ENGINE = InnoDB,
 PARTITION p202112 VALUES LESS THAN ('2022-01-01') ENGINE = InnoDB,
 PARTITION p202201 VALUES LESS THAN ('2022-02-01') ENGINE = InnoDB,
 PARTITION p202202 VALUES LESS THAN ('2022-03-01') ENGINE = InnoDB,
 PARTITION p202203 VALUES LESS THAN ('2022-04-01') ENGINE = InnoDB,
 PARTITION p202204 VALUES LESS THAN ('2022-05-01') ENGINE = InnoDB,
 PARTITION p202205 VALUES LESS THAN ('2022-06-01') ENGINE = InnoDB,
 PARTITION p202206 VALUES LESS THAN ('2022-07-01') ENGINE = InnoDB,
 PARTITION p202207 VALUES LESS THAN ('2022-08-01') ENGINE = InnoDB,
 PARTITION p202208 VALUES LESS THAN ('2022-09-01') ENGINE = InnoDB,
 PARTITION p202209 VALUES LESS THAN ('2022-10-01') ENGINE = InnoDB,
 PARTITION p202210 VALUES LESS THAN ('2022-11-01') ENGINE = InnoDB,
 PARTITION p202211 VALUES LESS THAN ('2022-12-01') ENGINE = InnoDB,
 PARTITION p202212 VALUES LESS THAN ('2023-01-01') ENGINE = InnoDB,
 PARTITION p202301 VALUES LESS THAN ('2023-02-01') ENGINE = InnoDB,
 PARTITION p202302 VALUES LESS THAN ('2023-03-01') ENGINE = InnoDB,
 PARTITION p202303 VALUES LESS THAN ('2023-04-01') ENGINE = InnoDB,
 PARTITION p202304 VALUES LESS THAN ('2023-05-01') ENGINE = InnoDB,
 PARTITION p202305 VALUES LESS THAN ('2023-06-01') ENGINE = InnoDB,
 PARTITION p202306 VALUES LESS THAN ('2023-07-01') ENGINE = InnoDB,
 PARTITION p202307 VALUES LESS THAN ('2023-08-01') ENGINE = InnoDB,
 PARTITION p202308 VALUES LESS THAN ('2023-09-01') ENGINE = InnoDB,
 PARTITION p202309 VALUES LESS THAN ('2023-10-01') ENGINE = InnoDB,
 PARTITION p202310 VALUES LESS THAN ('2023-11-01') ENGINE = InnoDB,
 PARTITION p202311 VALUES LESS THAN ('2023-12-01') ENGINE = InnoDB,
 PARTITION p202312 VALUES LESS THAN ('2024-01-01') ENGINE = InnoDB,
 PARTITION p202401 VALUES LESS THAN ('2024-02-01') ENGINE = InnoDB,
 PARTITION p202402 VALUES LESS THAN ('2024-03-01') ENGINE = InnoDB,
 PARTITION p202403 VALUES LESS THAN ('2024-04-01') ENGINE = InnoDB,
 PARTITION p202404 VALUES LESS THAN ('2024-05-01') ENGINE = InnoDB,
 PARTITION p202405 VALUES LESS THAN ('2024-06-01') ENGINE = InnoDB,
 PARTITION p202406 VALUES LESS THAN ('2024-07-01') ENGINE = InnoDB,
 PARTITION p202407 VALUES LESS THAN ('2024-08-01') ENGINE = InnoDB,
 PARTITION p202408 VALUES LESS THAN ('2024-09-01') ENGINE = InnoDB,
 PARTITION p202409 VALUES LESS THAN ('2024-10-01') ENGINE = InnoDB,
 PARTITION p202410 VALUES LESS THAN ('2024-11-01') ENGINE = InnoDB,
 PARTITION p202411 VALUES LESS THAN ('2024-12-01') ENGINE = InnoDB,
 PARTITION p202412 VALUES LESS THAN ('2025-01-01') ENGINE = InnoDB,
 PARTITION p202501 VALUES LESS THAN ('2025-02-01') ENGINE = InnoDB,
 PARTITION p202502 VALUES LESS THAN ('2025-03-01') ENGINE = InnoDB,
 PARTITION p202503 VALUES LESS THAN ('2025-04-01') ENGINE = InnoDB,
 PARTITION p202504 VALUES LESS THAN ('2025-05-01') ENGINE = InnoDB,
 PARTITION p202505 VALUES LESS THAN ('2025-06-01') ENGINE = InnoDB,
 PARTITION p202506 VALUES LESS THAN ('2025-07-01') ENGINE = InnoDB,
 PARTITION p202507 VALUES LESS THAN ('2025-08-01') ENGINE = InnoDB,
 PARTITION p202508 VALUES LESS THAN ('2025-09-01') ENGINE = InnoDB,
 PARTITION p202509 VALUES LESS THAN ('2025-10-01') ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN ('2025-11-01') ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN ('2025-12-01') ENGINE = InnoDB,
 PARTITION p202512 VALUES LESS THAN ('2026-01-01') ENGINE = InnoDB,
 PARTITION p202601 VALUES LESS THAN ('2026-02-01') ENGINE = InnoDB,
 PARTITION p202602 VALUES LESS THAN ('2026-03-01') ENGINE = InnoDB,
 PARTITION p202603 VALUES LESS THAN ('2026-04-01') ENGINE = InnoDB,
 PARTITION p202604 VALUES LESS THAN ('2026-05-01') ENGINE = InnoDB,
 PARTITION p202605 VALUES LESS THAN ('2026-06-01') ENGINE = InnoDB,
 PARTITION p202606 VALUES LESS THAN ('2026-07-01') ENGINE = InnoDB,
 PARTITION p202607 VALUES LESS THAN ('2026-08-01') ENGINE = InnoDB,
 PARTITION p202608 VALUES LESS THAN ('2026-09-01') ENGINE = InnoDB,
 PARTITION p202609 VALUES LESS THAN ('2026-10-01') ENGINE = InnoDB,
 PARTITION p202610 VALUES LESS THAN ('2026-11-01') ENGINE = InnoDB,
 PARTITION p202611 VALUES LESS THAN ('2026-12-01') ENGINE = InnoDB,
 PARTITION p202612 VALUES LESS THAN ('2027-01-01') ENGINE = InnoDB,
 PARTITION p202701 VALUES LESS THAN ('2027-02-01') ENGINE = InnoDB,
 PARTITION p202702 VALUES LESS THAN ('2027-03-01') ENGINE = InnoDB,
 PARTITION p202703 VALUES LESS THAN ('2027-04-01') ENGINE = InnoDB,
 PARTITION p202704 VALUES LESS THAN ('2027-05-01') ENGINE = InnoDB,
 PARTITION p202705 VALUES LESS THAN ('2027-06-01') ENGINE = InnoDB,
 PARTITION p202706 VALUES LESS THAN ('2027-07-01') ENGINE = InnoDB,
 PARTITION p202707 VALUES LESS THAN ('2027-08-01') ENGINE = InnoDB,
 PARTITION p202708 VALUES LESS THAN ('2027-09-01') ENGINE = InnoDB,
 PARTITION p202709 VALUES LESS THAN ('2027-10-01') ENGINE = InnoDB,
 PARTITION p202710 VALUES LESS THAN ('2027-11-01') ENGINE = InnoDB,
 PARTITION p202711 VALUES LESS THAN ('2027-12-01') ENGINE = InnoDB,
 PARTITION p202712 VALUES LESS THAN ('2028-01-01') ENGINE = InnoDB,
 PARTITION p202801 VALUES LESS THAN ('2028-02-01') ENGINE = InnoDB,
 PARTITION p202802 VALUES LESS THAN ('2028-03-01') ENGINE = InnoDB,
 PARTITION p202803 VALUES LESS THAN ('2028-04-01') ENGINE = InnoDB,
 PARTITION p202804 VALUES LESS THAN ('2028-05-01') ENGINE = InnoDB,
 PARTITION p202805 VALUES LESS THAN ('2028-06-01') ENGINE = InnoDB,
 PARTITION p202806 VALUES LESS THAN ('2028-07-01') ENGINE = InnoDB,
 PARTITION p202807 VALUES LESS THAN ('2028-08-01') ENGINE = InnoDB,
 PARTITION p202808 VALUES LESS THAN ('2028-09-01') ENGINE = InnoDB,
 PARTITION p202809 VALUES LESS THAN ('2028-10-01') ENGINE = InnoDB,
 PARTITION p202810 VALUES LESS THAN ('2028-11-01') ENGINE = InnoDB,
 PARTITION p202811 VALUES LESS THAN ('2028-12-01') ENGINE = InnoDB,
 PARTITION p202812 VALUES LESS THAN ('2029-01-01') ENGINE = InnoDB,
 PARTITION p202901 VALUES LESS THAN ('2029-02-01') ENGINE = InnoDB,
 PARTITION p202902 VALUES LESS THAN ('2029-03-01') ENGINE = InnoDB,
 PARTITION p202903 VALUES LESS THAN ('2029-04-01') ENGINE = InnoDB,
 PARTITION p202904 VALUES LESS THAN ('2029-05-01') ENGINE = InnoDB,
 PARTITION p202905 VALUES LESS THAN ('2029-06-01') ENGINE = InnoDB,
 PARTITION p202906 VALUES LESS THAN ('2029-07-01') ENGINE = InnoDB,
 PARTITION p202907 VALUES LESS THAN ('2029-08-01') ENGINE = InnoDB,
 PARTITION p202908 VALUES LESS THAN ('2029-09-01') ENGINE = InnoDB,
 PARTITION p202909 VALUES LESS THAN ('2029-10-01') ENGINE = InnoDB,
 PARTITION p202910 VALUES LESS THAN ('2029-11-01') ENGINE = InnoDB,
 PARTITION p202911 VALUES LESS THAN ('2029-12-01') ENGINE = InnoDB,
 PARTITION p202912 VALUES LESS THAN ('2030-01-01') ENGINE = InnoDB,
 PARTITION p203001 VALUES LESS THAN ('2030-02-01') ENGINE = InnoDB,
 PARTITION p203002 VALUES LESS THAN ('2030-03-01') ENGINE = InnoDB,
 PARTITION p203003 VALUES LESS THAN ('2030-04-01') ENGINE = InnoDB,
 PARTITION p203004 VALUES LESS THAN ('2030-05-01') ENGINE = InnoDB,
 PARTITION p203005 VALUES LESS THAN ('2030-06-01') ENGINE = InnoDB,
 PARTITION p203006 VALUES LESS THAN ('2030-07-01') ENGINE = InnoDB,
 PARTITION p203007 VALUES LESS THAN ('2030-08-01') ENGINE = InnoDB,
 PARTITION p203008 VALUES LESS THAN ('2030-09-01') ENGINE = InnoDB,
 PARTITION p203009 VALUES LESS THAN ('2030-10-01') ENGINE = InnoDB,
 PARTITION p203010 VALUES LESS THAN ('2030-11-01') ENGINE = InnoDB,
 PARTITION p203011 VALUES LESS THAN ('2030-12-01') ENGINE = InnoDB,
 PARTITION p203012 VALUES LESS THAN ('2031-01-01') ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_dispatches`
--

DROP TABLE IF EXISTS `player_dispatches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_dispatches` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤー派遣情報',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `dispatch_id` int(11) NOT NULL COMMENT '派遣マスタID',
  `is_clear` smallint(6) NOT NULL COMMENT 'クリア済みか',
  `complete_at` datetime DEFAULT NULL COMMENT '完了日時',
  `view_end_at` datetime DEFAULT NULL COMMENT '表示終了日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_dispatches_1` (`spid`,`event_id`,`view_end_at`,`dispatch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤー派遣情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_enquete_nums`
--

DROP TABLE IF EXISTS `player_enquete_nums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_enquete_nums` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーアンケート',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `enquete_id` int(11) NOT NULL COMMENT 'アンケートID',
  `enquete_num` int(11) NOT NULL COMMENT 'アンケート回答数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_enquete_nums_1` (`spid`,`enquete_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーアンケート';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_enquetes`
--

DROP TABLE IF EXISTS `player_enquetes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_enquetes` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーアンケート',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `enquete_id` int(11) NOT NULL COMMENT 'アンケートID',
  `enquete_question_id` int(11) NOT NULL COMMENT '設問ID',
  `enquete_answer_id` int(11) NOT NULL COMMENT 'アンケートID',
  `answer_text` text COMMENT '回答文',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_enquetes_1` (`spid`),
  KEY `idx_player_enquetes_2` (`enquete_id`,`enquete_question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーアンケート';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_event_drop_item_growths`
--

DROP TABLE IF EXISTS `player_event_drop_item_growths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_event_drop_item_growths` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤードロッップアイテム成長',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `drop_item_id` int(11) NOT NULL COMMENT 'ドロップアイテムID',
  `status` smallint(6) NOT NULL COMMENT 'ステータス',
  `growth_point` int(11) NOT NULL COMMENT '成長ポイントmax',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_event_drop_item_growths_1` (`event_id`,`spid`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤードロッップアイテム成長';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_event_drop_item_rarities`
--

DROP TABLE IF EXISTS `player_event_drop_item_rarities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_event_drop_item_rarities` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤードロッップアイテム成長',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `drop_item_id` int(11) NOT NULL COMMENT 'ドロップアイテムID',
  `rarity_id` int(11) NOT NULL COMMENT 'レアリティID',
  `reward_num` smallint(6) NOT NULL COMMENT '獲得数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_event_drop_item_rarities_1` (`event_id`,`spid`,`drop_item_id`,`rarity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤードロッップアイテム成長';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_event_fevers`
--

DROP TABLE IF EXISTS `player_event_fevers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_event_fevers` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーイベントフィーバー',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `fever_id` int(11) NOT NULL COMMENT 'フィーバーID',
  `end_at` datetime NOT NULL COMMENT '終了日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_event_fevers_1` (`spid`,`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーイベントフィーバー';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_event_point_effects`
--

DROP TABLE IF EXISTS `player_event_point_effects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_event_point_effects` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーイベントポイント効果',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `add_rate` int(11) NOT NULL COMMENT '獲得量アップ値',
  `is_read` smallint(6) NOT NULL COMMENT '既読フラグ',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_event_point_effects_1` (`spid`,`event_id`,`point_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーイベントポイント効果';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_event_point_histories`
--

DROP TABLE IF EXISTS `player_event_point_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_event_point_histories` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーイベントポイント獲得履歴',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `product_id` bigint(20) NOT NULL COMMENT '商品ID',
  `event_point` int(11) NOT NULL COMMENT '獲得ポイント(単価)',
  `num` int(11) NOT NULL COMMENT '個数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_event_point_histories_1` (`spid`,`point_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーイベントポイント獲得履歴';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_event_point_rewards`
--

DROP TABLE IF EXISTS `player_event_point_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_event_point_rewards` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーイベントポイント',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `point_reward_id` int(11) NOT NULL COMMENT 'イベントポイント達成報酬ID',
  `num` int(11) NOT NULL DEFAULT '1' COMMENT '付与回数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_event_point_rewards_1` (`spid`,`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーイベントポイント';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_event_points`
--

DROP TABLE IF EXISTS `player_event_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_event_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーイベントポイント',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `target_date` int(11) NOT NULL DEFAULT '-1' COMMENT '獲得日時',
  `org_event_point` int(11) NOT NULL COMMENT '総ポイント',
  `event_point` int(11) NOT NULL DEFAULT '0' COMMENT '所持イベントP',
  `lock_version` int(11) NOT NULL DEFAULT '0' COMMENT 'バージョン番号',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_event_points_1` (`spid`,`point_id`,`target_date`),
  KEY `idx_player_event_points_2` (`point_id`,`target_date`,`org_event_point`,`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーイベントポイント';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_event_powers`
--

DROP TABLE IF EXISTS `player_event_powers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_event_powers` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーイベント用体力',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `power` int(11) NOT NULL COMMENT '体力',
  `rec_at` datetime DEFAULT NULL COMMENT '回復日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_event_powers_1` (`spid`,`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーイベント用体力';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_event_rankings`
--

DROP TABLE IF EXISTS `player_event_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_event_rankings` (
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `ranking_date` int(11) NOT NULL DEFAULT '-1' COMMENT 'ランキング日時',
  `ranking` int(11) NOT NULL COMMENT '順位',
  `count_value` int(11) NOT NULL COMMENT 'カウント値',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  KEY `idx_player_event_rankings_1` (`event_id`,`ranking`,`point_id`),
  KEY `idx_player_event_rankings_2` (`event_id`,`spid`,`point_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーイベントランキング';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_event_rarity_completes`
--

DROP TABLE IF EXISTS `player_event_rarity_completes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_event_rarity_completes` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーイベントレアリティコンプ状況',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `rarity_id` int(11) NOT NULL COMMENT 'レアリティID',
  `complete_num` int(11) NOT NULL COMMENT 'コンプリート回数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_event_rarity_completes_1` (`event_id`,`spid`,`rarity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーイベントレアリティコンプ状況';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_event_shop_caps`
--

DROP TABLE IF EXISTS `player_event_shop_caps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_event_shop_caps` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーイベントショップ上限ID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_shop_id` int(11) NOT NULL COMMENT 'イベントショップID',
  `count_value` int(11) NOT NULL COMMENT '購入回数',
  `lock_version` int(11) NOT NULL DEFAULT '0' COMMENT 'バージョン番号',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_event_shop_caps_1` (`spid`,`event_shop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーイベントショップ上限';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_event_teams`
--

DROP TABLE IF EXISTS `player_event_teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_event_teams` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーイベントチーム',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `event_team_id` int(11) NOT NULL COMMENT 'イベントチームID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_event_teams_1` (`spid`,`event_id`),
  KEY `idx_player_event_teams_2` (`event_id`,`event_team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーイベントチーム';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_events`
--

DROP TABLE IF EXISTS `player_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーイベント',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `event_lv` int(11) NOT NULL DEFAULT '1' COMMENT 'イベントLv',
  `lvup_read` int(11) NOT NULL DEFAULT '1' COMMENT 'LVUP既読フラグ',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_events_1` (`spid`,`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーイベント';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_feed_reads`
--

DROP TABLE IF EXISTS `player_feed_reads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_feed_reads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `read_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_feed_reads_1` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_feeds`
--

DROP TABLE IF EXISTS `player_feeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_feeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `feed_kind_id` int(11) NOT NULL,
  `is_read` tinyint(4) NOT NULL,
  `subject` varchar(10) NOT NULL,
  `body` text NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_feeds_1` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_frozens`
--

DROP TABLE IF EXISTS `player_frozens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_frozens` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'アカウント停止',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `start_at` datetime NOT NULL COMMENT '開始日時',
  `end_at` datetime NOT NULL COMMENT '終了日時',
  `description` text NOT NULL COMMENT '停止理由',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_frozens_1` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='アカウント停止';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_invites`
--

DROP TABLE IF EXISTS `player_invites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_invites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `to_player_id` varchar(9) NOT NULL,
  `invite_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `request_at` datetime NOT NULL,
  `complete_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_invites_1` (`spid`,`invite_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_item_inventories`
--

DROP TABLE IF EXISTS `player_item_inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_item_inventories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `item_id` int(11) NOT NULL,
  `num` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_item_inventories_1` (`spid`,`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_item_invokes`
--

DROP TABLE IF EXISTS `player_item_invokes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_item_invokes` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '発動中のアイテム効果',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `is_active` tinyint(4) NOT NULL DEFAULT '0' COMMENT '効果発動中か',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_item_invokes_1` (`spid`,`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='発動中のアイテム効果';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_like_histories`
--

DROP TABLE IF EXISTS `player_like_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_like_histories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `fr_spid` bigint(20) NOT NULL,
  `to_store_id` int(11) NOT NULL,
  `like_kind_id` int(11) NOT NULL,
  `no` int(11) NOT NULL DEFAULT '0',
  `like_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_like_histories_1` (`spid`,`no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_like_targets`
--

DROP TABLE IF EXISTS `player_like_targets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_like_targets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `to_spid` bigint(20) NOT NULL,
  `update_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_like_targets_1` (`spid`,`to_spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_likes`
--

DROP TABLE IF EXISTS `player_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `num` int(11) NOT NULL,
  `refresh_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_likes_1` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_login_dailies`
--

DROP TABLE IF EXISTS `player_login_dailies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_login_dailies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `login_at` datetime NOT NULL,
  `lock_version` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_login_dailies_1` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_login_daily_nums`
--

DROP TABLE IF EXISTS `player_login_daily_nums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_login_daily_nums` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーログイン情報',
  `spid` bigint(20) NOT NULL,
  `login_daily_id` int(11) NOT NULL COMMENT 'デイリーログインID',
  `login_num` int(11) NOT NULL COMMENT 'ログイン回数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_login_daily_nums_1` (`spid`,`login_daily_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーログイン情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_lot_box_draws`
--

DROP TABLE IF EXISTS `player_lot_box_draws`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_lot_box_draws` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ボックスガチャ抽選データ',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `lot_box_limit_id` int(11) NOT NULL COMMENT 'ボックスガチャ制限リストID',
  `draw_count` int(11) NOT NULL COMMENT '抽選数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_lot_box_draws_1` (`spid`,`lot_box_limit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ボックスガチャ抽選データ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_lot_boxes`
--

DROP TABLE IF EXISTS `player_lot_boxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_lot_boxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ボックスガチャデータ',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `lot_box_id` int(11) NOT NULL COMMENT 'ボックスガチャID',
  `set_count` int(11) NOT NULL COMMENT 'セット数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_lot_boxes_1` (`spid`,`lot_box_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ボックスガチャデータ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_motivations`
--

DROP TABLE IF EXISTS `player_motivations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_motivations` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'やる気ゲージ',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `value` int(11) NOT NULL COMMENT 'やる気値',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_motivations_1` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='やる気ゲージ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_npc_comings`
--

DROP TABLE IF EXISTS `player_npc_comings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_npc_comings` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'NPC来訪者データ',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `npc_method` smallint(6) NOT NULL COMMENT 'NPCメソッド',
  `last_at` datetime NOT NULL COMMENT '最終処理時間',
  `lock_version` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_npc_comings_1` (`spid`,`npc_method`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='NPC来訪者データ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_payment_totals`
--

DROP TABLE IF EXISTS `player_payment_totals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_payment_totals` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤー累計課金額',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `price` int(11) NOT NULL COMMENT '累計課金額',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_payment_totals_1` (`spid`),
  KEY `idx_player_payment_totals_2` (`created_at`,`price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤー累計課金額';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_payments`
--

DROP TABLE IF EXISTS `player_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `trans_id` varchar(40) NOT NULL,
  `payment_id` varchar(100) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `target_id` int(11) NOT NULL,
  `status` smallint(6) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_payments_2` (`spid`,`target_id`,`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_permissions`
--

DROP TABLE IF EXISTS `player_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `player_id` varchar(9) NOT NULL,
  `fake_player_id` varchar(9) DEFAULT NULL COMMENT 'なりすましPlayerId',
  `is_product_debug` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'ポイント効果名',
  `override_at` datetime DEFAULT NULL,
  `is_mainte_pass` tinyint(4) NOT NULL,
  `rand_set_value` int(11) NOT NULL DEFAULT '-1',
  `response_delay_time` tinyint(4) NOT NULL DEFAULT '-1' COMMENT '応答遅延時間（秒）',
  `description` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_permissions_1` (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_persistencies`
--

DROP TABLE IF EXISTS `player_persistencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_persistencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤー継続率',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `regist_date` date NOT NULL COMMENT 'イベントID',
  `login_num` int(11) NOT NULL COMMENT 'ログイン日数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_persistencies_1` (`spid`),
  KEY `idx_player_persistencies_2` (`regist_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤー継続率';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_preregists`
--

DROP TABLE IF EXISTS `player_preregists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_preregists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `player_id` varchar(9) NOT NULL COMMENT 'TOGID',
  `name` varchar(36) NOT NULL COMMENT 'PFの名前',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_preregists_1` (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_present_boxes`
--

DROP TABLE IF EXISTS `player_present_boxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_present_boxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレゼントボックス',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `present_pool_kind_id` int(11) NOT NULL COMMENT '保管種別ID',
  `start_timestamp` bigint(20) NOT NULL COMMENT '登録時のタイムスタンプ',
  `is_complete` tinyint(4) NOT NULL COMMENT '受け取ったかどうかのフラグ',
  `subject` varchar(40) DEFAULT NULL COMMENT '名目',
  `class_id` varchar(40) NOT NULL COMMENT 'CLASSID',
  `arg1` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値1',
  `arg2` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値2',
  `arg3` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値3',
  `arg4` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値4',
  `arg5` varchar(40) DEFAULT NULL COMMENT 'CLASSID引数値5',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_present_boxes_1` (`spid`,`is_complete`,`start_timestamp`,`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレゼントボックス';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_present_distributions`
--

DROP TABLE IF EXISTS `player_present_distributions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_present_distributions` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤープレゼント配信済みデータ',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `present_distribution_id` int(11) NOT NULL COMMENT '運営からの配信ID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤープレゼント配信済みデータ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_product_collections`
--

DROP TABLE IF EXISTS `player_product_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_product_collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_product_collections_1` (`spid`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_product_displays`
--

DROP TABLE IF EXISTS `player_product_displays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_product_displays` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤー商品陳列情報',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `product_inventory_id` int(11) NOT NULL COMMENT '商品在庫ID',
  `price` int(11) NOT NULL COMMENT '販売価格',
  `num` int(11) NOT NULL COMMENT '現在の販売数',
  `lock_version` int(11) NOT NULL DEFAULT '0' COMMENT 'バージョン番号',
  `container_display_id` int(11) NOT NULL COMMENT '陳列対象什器陳列ID',
  `no` int(11) NOT NULL DEFAULT '0' COMMENT '設置箇所',
  `start_at` datetime NOT NULL COMMENT '販売開始日（未使用）',
  `end_at` datetime NOT NULL COMMENT '販売終了日（未使用）',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_product_displays_1` (`spid`,`product_inventory_id`,`start_at`,`end_at`),
  KEY `idx_player_product_displays_2` (`product_inventory_id`,`container_display_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤー商品陳列情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_product_inventories`
--

DROP TABLE IF EXISTS `player_product_inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_product_inventories` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '商品在庫情報',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `product_id` bigint(20) NOT NULL COMMENT '商品ID',
  `num` int(11) NOT NULL COMMENT '在庫個数',
  `org_num` int(11) NOT NULL COMMENT 'もともとの在庫個数',
  `lock_version` int(11) NOT NULL DEFAULT '0' COMMENT 'バージョン番号',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_product_inventories_2` (`spid`,`id`,`product_id`),
  KEY `idx_player_product_inventories_1` (`spid`,`product_id`,`org_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品在庫情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_product_sell_effect_time_rewards`
--

DROP TABLE IF EXISTS `player_product_sell_effect_time_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_product_sell_effect_time_rewards` (
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `time_id` int(11) NOT NULL COMMENT '商品販売時間帯別効果ID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  UNIQUE KEY `idx_player_product_sell_effect_time_rewards_1` (`spid`,`event_id`,`time_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤー商品販売時間帯獲得状況';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_product_sell_rewards`
--

DROP TABLE IF EXISTS `player_product_sell_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_product_sell_rewards` (
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `reward_id` int(11) NOT NULL COMMENT '報酬iD',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  UNIQUE KEY `idx_player_product_sell_rewards_1` (`spid`,`event_id`,`reward_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤー商品販売報酬獲得履歴';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_purchase_configs`
--

DROP TABLE IF EXISTS `player_purchase_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_purchase_configs` (
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `limit_price` bigint(20) NOT NULL COMMENT '制限金額',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='購入制限設定情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_push_quest_drop_items`
--

DROP TABLE IF EXISTS `player_push_quest_drop_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_push_quest_drop_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤープッシュクエストドロップアイテム所持情報',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `push_quest_id` int(11) NOT NULL COMMENT 'プッシュクエストID',
  `push_quest_list_id` int(11) NOT NULL COMMENT 'プッシュクエストリストID',
  `drop_item_id` int(11) NOT NULL COMMENT 'ドロップアイテムID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_push_quest_drop_items_1` (`spid`,`push_quest_id`,`push_quest_list_id`),
  KEY `idx_player_push_quest_drop_items_2` (`spid`,`drop_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤープッシュクエストドロップアイテム所持情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_push_quest_lot_list_rewards`
--

DROP TABLE IF EXISTS `player_push_quest_lot_list_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_push_quest_lot_list_rewards` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤープッシュクエスト報酬受け取り',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `push_quest_id` int(11) NOT NULL DEFAULT '-1' COMMENT 'プッシュクエストID',
  `push_quest_list_id` int(11) NOT NULL COMMENT 'プッシュクエストリストID',
  `num` int(11) NOT NULL DEFAULT '1' COMMENT '回数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_push_quest_lot_list_rewards_1` (`spid`,`event_id`,`push_quest_id`,`push_quest_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤープッシュクエスト報酬受け取り';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_push_quest_lot_lists`
--

DROP TABLE IF EXISTS `player_push_quest_lot_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_push_quest_lot_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤープッシュクエスト獲得リスト',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `push_quest_list_id` int(11) NOT NULL COMMENT 'プッシュクエストリストID',
  `lot_list_id` int(11) NOT NULL COMMENT '抽選ID',
  `lot_num` int(11) NOT NULL COMMENT '抽選回数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_push_quest_lot_lists_1` (`spid`,`event_id`,`push_quest_list_id`,`lot_list_id`),
  KEY `idx_player_push_quest_lot_lists_2` (`event_id`,`lot_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤープッシュクエスト獲得リスト';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_push_quest_treasures`
--

DROP TABLE IF EXISTS `player_push_quest_treasures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_push_quest_treasures` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤープッシュクエスト宝箱',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `push_quest_id` int(11) NOT NULL COMMENT 'プッシュクエストID',
  `push_quest_list_id` int(11) NOT NULL COMMENT 'プッシュクエストリストID',
  `treasure_id` int(11) NOT NULL COMMENT '宝箱ID',
  `get_num` smallint(6) NOT NULL DEFAULT '0' COMMENT '獲得数',
  `open_num` smallint(6) NOT NULL DEFAULT '0' COMMENT '開錠数',
  `free_num` smallint(6) NOT NULL DEFAULT '0' COMMENT '鍵なしで開けられる数',
  `is_active` tinyint(4) NOT NULL COMMENT 'アクティブ状況',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_push_quest_treasures_1` (`spid`,`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤープッシュクエスト宝箱';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_push_quests`
--

DROP TABLE IF EXISTS `player_push_quests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_push_quests` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤープッシュクエスト',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `push_quest_id` int(11) NOT NULL COMMENT 'プッシュクエストID',
  `push_quest_list_id` int(11) NOT NULL COMMENT 'プッシュクエストリストID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `progress` int(11) NOT NULL COMMENT '実行回数',
  `clear_num` int(11) NOT NULL COMMENT 'クリア回数',
  `is_active` smallint(6) NOT NULL COMMENT 'アクティブ状況',
  `is_latest` smallint(6) NOT NULL COMMENT '最新フラグ',
  `status` int(11) NOT NULL COMMENT 'ステータス',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_push_quests_1` (`spid`,`event_id`,`push_quest_id`,`push_quest_list_id`),
  KEY `idx_player_push_quests_2` (`event_id`,`push_quest_id`),
  KEY `idx_player_push_quests_3` (`event_id`,`push_quest_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤープッシュクエスト';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_quest_counters`
--

DROP TABLE IF EXISTS `player_quest_counters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_quest_counters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `target_id` bigint(20) NOT NULL,
  `counter_kind_id` int(11) NOT NULL,
  `counter_period_id` int(11) NOT NULL,
  `start_at` datetime NOT NULL,
  `count_value` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_quest_counters_1` (`spid`,`target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_quests`
--

DROP TABLE IF EXISTS `player_quests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_quests` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'クエストデータ',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `quest_list_id` int(11) NOT NULL COMMENT 'クエスト一覧ID',
  `status` smallint(6) NOT NULL DEFAULT '0' COMMENT 'ステータス',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_quests_1` (`spid`,`quest_list_id`),
  KEY `idx_player_quests_2` (`quest_list_id`),
  KEY `idx_player_quests_3` (`spid`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='クエストデータ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_raid_levels`
--

DROP TABLE IF EXISTS `player_raid_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_raid_levels` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーレイドレベル',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `raid_level_id` bigint(20) NOT NULL COMMENT 'レイドレベルID',
  `is_valid` tinyint(4) NOT NULL DEFAULT '1' COMMENT '有効/無効',
  `status` tinyint(4) NOT NULL COMMENT 'ステータス',
  `base_trg_point` int(11) NOT NULL DEFAULT '0' COMMENT '基準ポイント',
  `is_checked` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'チェックの有無',
  `expires_at` datetime DEFAULT NULL COMMENT '出現有効期限',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_raid_levels_1` (`spid`,`raid_level_id`,`is_valid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーレイドレベル';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_raid_rewards`
--

DROP TABLE IF EXISTS `player_raid_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_raid_rewards` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーレイド報酬プール',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `raid_id` int(11) NOT NULL COMMENT 'レイドID',
  `received` tinyint(4) NOT NULL DEFAULT '0' COMMENT '受け取り済みフラグ',
  `context_id` int(11) NOT NULL COMMENT '対象のレイドコンテキストID',
  `reward_raid_level_id` int(11) NOT NULL COMMENT '報酬のレイドレベルID',
  `reward_rank` smallint(6) NOT NULL COMMENT '報酬付与対象のランク',
  `reward_type` tinyint(4) NOT NULL COMMENT '報酬種別',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_raid_rewards_1` (`spid`,`raid_id`,`received`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーレイド報酬プール';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_raids`
--

DROP TABLE IF EXISTS `player_raids`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_raids` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーレイド',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `raid_id` int(11) NOT NULL COMMENT 'レイドID',
  `current_ap` tinyint(4) NOT NULL COMMENT '現在の体力',
  `max_ap` tinyint(4) NOT NULL COMMENT '最大の体力',
  `last_refresh_at` datetime NOT NULL COMMENT '最終回復時間',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_raids_1` (`spid`,`raid_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーレイド';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_ranking_beautifuls`
--

DROP TABLE IF EXISTS `player_ranking_beautifuls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_ranking_beautifuls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `ranking` int(11) NOT NULL COMMENT '順位',
  `count_value` int(11) NOT NULL COMMENT 'カウント値',
  `ranking_date` date NOT NULL COMMENT '日付',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_ranking_beautifuls_2` (`spid`,`ranking_date`),
  KEY `idx_player_ranking_beautifuls_3` (`ranking_date`,`ranking`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_ranking_collections`
--

DROP TABLE IF EXISTS `player_ranking_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_ranking_collections` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤー図鑑ランキング',
  `spid` int(11) NOT NULL COMMENT 'SPID',
  `ranking` int(11) NOT NULL COMMENT '順位',
  `count_value` int(11) NOT NULL COMMENT 'カウント値',
  `ranking_date` date NOT NULL COMMENT '日付',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_ranking_collections_1` (`spid`,`ranking_date`),
  KEY `idx_player_ranking_collections_2` (`ranking_date`,`ranking`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤー図鑑ランキング';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_ranking_cools`
--

DROP TABLE IF EXISTS `player_ranking_cools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_ranking_cools` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `ranking` int(11) NOT NULL COMMENT '順位',
  `count_value` int(11) NOT NULL COMMENT 'カウント値',
  `ranking_date` date NOT NULL COMMENT '日付',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_ranking_cools_2` (`spid`,`ranking_date`),
  KEY `idx_player_ranking_cools_3` (`ranking_date`,`ranking`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_ranking_cutes`
--

DROP TABLE IF EXISTS `player_ranking_cutes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_ranking_cutes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `ranking` int(11) NOT NULL COMMENT '順位',
  `count_value` int(11) NOT NULL COMMENT 'カウント値',
  `ranking_date` date NOT NULL COMMENT '日付',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_ranking_cutes_2` (`spid`,`ranking_date`),
  KEY `idx_player_ranking_cutes_3` (`ranking_date`,`ranking`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_ranking_favorites`
--

DROP TABLE IF EXISTS `player_ranking_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_ranking_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `ranking` int(11) NOT NULL COMMENT '順位',
  `count_value` int(11) NOT NULL COMMENT 'カウント値',
  `ranking_date` date NOT NULL COMMENT '日付',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_ranking_favorites_2` (`spid`,`ranking_date`),
  KEY `idx_player_ranking_favorites_3` (`ranking_date`,`ranking`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_ranking_fulls`
--

DROP TABLE IF EXISTS `player_ranking_fulls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_ranking_fulls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `ranking` int(11) NOT NULL COMMENT '順位',
  `count_value` int(11) NOT NULL COMMENT 'カウント値',
  `ranking_date` date NOT NULL COMMENT '日付',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_ranking_fulls_2` (`spid`,`ranking_date`),
  KEY `idx_player_ranking_fulls_3` (`ranking_date`,`ranking`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_ranking_funs`
--

DROP TABLE IF EXISTS `player_ranking_funs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_ranking_funs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `ranking` int(11) NOT NULL COMMENT '順位',
  `count_value` int(11) NOT NULL COMMENT 'カウント値',
  `ranking_date` date NOT NULL COMMENT '日付',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_ranking_funs_2` (`spid`,`ranking_date`),
  KEY `idx_player_ranking_funs_3` (`ranking_date`,`ranking`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_ranking_likes`
--

DROP TABLE IF EXISTS `player_ranking_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_ranking_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `ranking` int(11) NOT NULL COMMENT '順位',
  `count_value` int(11) NOT NULL COMMENT 'カウント値',
  `ranking_date` date NOT NULL COMMENT '日付',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_ranking_likes_2` (`spid`,`ranking_date`),
  KEY `idx_player_ranking_likes_3` (`ranking_date`,`ranking`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_ranking_products`
--

DROP TABLE IF EXISTS `player_ranking_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_ranking_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `ranking` int(11) NOT NULL COMMENT '順位',
  `count_value` int(11) NOT NULL COMMENT 'カウント値',
  `ranking_date` date NOT NULL COMMENT '日付',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_ranking_products_2` (`spid`,`ranking_date`),
  KEY `idx_player_ranking_products_3` (`ranking_date`,`ranking`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_ranking_storepoints`
--

DROP TABLE IF EXISTS `player_ranking_storepoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_ranking_storepoints` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `ranking` int(11) NOT NULL COMMENT '順位',
  `count_value` int(11) NOT NULL COMMENT 'カウント値',
  `ranking_date` date NOT NULL COMMENT '日付',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_ranking_storepoints_2` (`spid`,`ranking_date`),
  KEY `idx_player_ranking_storepoints_3` (`ranking_date`,`ranking`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_ranking_stylishes`
--

DROP TABLE IF EXISTS `player_ranking_stylishes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_ranking_stylishes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `ranking` int(11) NOT NULL COMMENT '順位',
  `count_value` int(11) NOT NULL COMMENT 'カウント値',
  `ranking_date` date NOT NULL COMMENT '日付',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_ranking_stylishes_2` (`spid`,`ranking_date`),
  KEY `idx_player_ranking_stylishes_3` (`ranking_date`,`ranking`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_rotates`
--

DROP TABLE IF EXISTS `player_rotates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_rotates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `no` int(11) NOT NULL,
  `round` int(11) NOT NULL,
  `table_name` varchar(80) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_rotates_1` (`spid`,`table_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_shop_limits`
--

DROP TABLE IF EXISTS `player_shop_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_shop_limits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `shop_id` int(11) NOT NULL COMMENT 'ショップID',
  `num` int(11) NOT NULL COMMENT '購入数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_shop_limits_1` (`spid`,`shop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_stamp_rewards`
--

DROP TABLE IF EXISTS `player_stamp_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_stamp_rewards` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤースタンプ報酬履歴',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `stamp_id` int(11) NOT NULL COMMENT 'スタンプID',
  `stamp_reward_id` int(11) NOT NULL COMMENT '報酬ID',
  `num` int(11) NOT NULL COMMENT '付与回数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_stamp_rewards_1` (`spid`,`stamp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤースタンプ報酬履歴';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_stamps`
--

DROP TABLE IF EXISTS `player_stamps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_stamps` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤースタンプ',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `stamp_id` int(11) NOT NULL COMMENT 'スタンプID',
  `count_value` int(11) NOT NULL COMMENT '獲得数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_stamps_1` (`event_id`,`stamp_id`,`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤースタンプ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_store_favorites`
--

DROP TABLE IF EXISTS `player_store_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_store_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `to_spid` bigint(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_store_favorites_1` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_store_friends`
--

DROP TABLE IF EXISTS `player_store_friends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_store_friends` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `to_spid` bigint(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_store_friends_1` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_store_image_rankings`
--

DROP TABLE IF EXISTS `player_store_image_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_store_image_rankings` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '店舗画像ランキング',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `ranking` int(11) NOT NULL COMMENT 'ランキング',
  `count_value` int(11) NOT NULL COMMENT '投票数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_store_image_rankings_1` (`event_id`,`ranking`),
  KEY `idx_player_store_image_rankings_2` (`event_id`,`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='店舗画像ランキング';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_store_parameters`
--

DROP TABLE IF EXISTS `player_store_parameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_store_parameters` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ストアパラメータ',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `cat_point` int(11) NOT NULL DEFAULT '0' COMMENT '所持ねこP',
  `store_point` bigint(20) NOT NULL DEFAULT '0' COMMENT '所持ストアP',
  `guest_point` int(11) NOT NULL DEFAULT '0' COMMENT '所持ゲストP',
  `limit_containers` int(11) NOT NULL COMMENT '什器所持上限',
  `limit_products` int(11) NOT NULL COMMENT '商品所持上限',
  `limit_deal_wait` int(11) NOT NULL COMMENT '仕入れ待ちリスト上限',
  `limit_container_synth_wait` int(11) NOT NULL COMMENT '什器合成待ちリスト上限',
  `lock_version` int(11) NOT NULL DEFAULT '0' COMMENT 'バージョン番号',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_stores_parameters_1` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ストアパラメータ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_store_point_pools`
--

DROP TABLE IF EXISTS `player_store_point_pools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_store_point_pools` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ストアポイントプール',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `store_id` int(11) NOT NULL COMMENT 'StoreID',
  `value` bigint(20) NOT NULL COMMENT 'プール値',
  `lock_version` int(11) NOT NULL DEFAULT '0' COMMENT 'ロックID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_store_point_pools_1` (`spid`,`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ストアポイントプール';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_store_point_queues`
--

DROP TABLE IF EXISTS `player_store_point_queues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_store_point_queues` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ストアポイントプールキュー',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `store_id` int(11) NOT NULL COMMENT 'StoreID',
  `value` int(11) NOT NULL COMMENT 'プール値',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_store_point_queues_1` (`spid`,`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ストアポイントプールキュー';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_store_visitors`
--

DROP TABLE IF EXISTS `player_store_visitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_store_visitors` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ストア来訪者',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `store_id` int(11) NOT NULL COMMENT 'StoreID',
  `is_complete` tinyint(4) NOT NULL DEFAULT '0' COMMENT '処理終了の有無',
  `is_realtime` tinyint(4) NOT NULL DEFAULT '0' COMMENT '処理種別',
  `is_buyact` tinyint(4) DEFAULT '0' COMMENT '購入アクションを行うか',
  `player_kind_id` int(11) NOT NULL COMMENT 'プレイヤー種別ID',
  `visit_id` varchar(8) NOT NULL COMMENT '訪問ID',
  `visit_at` datetime NOT NULL COMMENT '来店時間',
  `target_id` bigint(20) NOT NULL COMMENT '対象ID(NPC-ID/SPID)',
  `avatar_coordinate_id` int(11) NOT NULL DEFAULT '-1' COMMENT 'コーディネートID',
  `product_category_id` int(11) NOT NULL COMMENT '商品カテゴリID',
  `product_display_id` int(11) NOT NULL DEFAULT '-1' COMMENT '購入しようとした商品陳列ID',
  `product_id` bigint(20) NOT NULL DEFAULT '-1' COMMENT '購入しようとした商品ID',
  `buy_num` int(11) NOT NULL DEFAULT '-1' COMMENT '購入しようとした数',
  `buy_price` int(11) NOT NULL DEFAULT '-1' COMMENT '購入しようとした価格',
  `add_beginner_price` int(11) NOT NULL COMMENT '初心者ボーナス',
  `add_quality_price` int(11) NOT NULL COMMENT '什器クオリティボーナス',
  `container_grid_x` smallint(6) NOT NULL DEFAULT '-1' COMMENT '購入什器の座標X',
  `container_grid_y` smallint(6) NOT NULL DEFAULT '-1' COMMENT '購入什器の座標Y',
  `stop_grid_x` smallint(6) NOT NULL DEFAULT '-1' COMMENT '購入什器付近の座標X',
  `stop_grid_y` smallint(6) NOT NULL DEFAULT '-1' COMMENT '購入什器付近の座標Y',
  `review_id` int(11) NOT NULL DEFAULT '-1' COMMENT 'レビュー記事ID',
  `guest_point` int(11) NOT NULL DEFAULT '0' COMMENT '入手ゲストポイント',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_store_visitors_1` (`spid`,`store_id`,`visit_id`,`is_complete`,`is_realtime`,`player_kind_id`,`visit_at`),
  KEY `idx_player_store_visitors_2` (`target_id`,`player_kind_id`,`buy_num`,`visit_at`),
  KEY `idx_player_store_visitors_3` (`spid`,`store_id`,`is_complete`,`is_realtime`,`visit_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ストア来訪者';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_stores`
--

DROP TABLE IF EXISTS `player_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_stores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `store_genre_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_stores_1` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_titles`
--

DROP TABLE IF EXISTS `player_titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_titles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `title_id` int(11) NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT '0',
  `is_complete` int(11) NOT NULL DEFAULT '0' COMMENT '演出表示済み',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_titles_2` (`spid`,`title_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_tpoint_histories`
--

DROP TABLE IF EXISTS `player_tpoint_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_tpoint_histories` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーTポイント履歴ID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `tpoint_kind_id` int(11) NOT NULL COMMENT 'Tポイント種別ID',
  `tpoint_period_id` int(11) NOT NULL COMMENT 'Tポイント期間ID',
  `use_item_id` int(11) NOT NULL DEFAULT '-1' COMMENT '使用アイテムID',
  `num` int(11) NOT NULL COMMENT 'Tポイント数',
  `subject` varchar(40) NOT NULL COMMENT '件名',
  `lot_at` datetime NOT NULL COMMENT '抽選日時',
  `add_at_str` varchar(40) NOT NULL COMMENT 'Tポイント付与日文言',
  `admin_comment` varchar(40) NOT NULL COMMENT '運営内部管理用コメント',
  `add_status` int(11) NOT NULL COMMENT '付与ステータス',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_tpoint_histories_1` (`spid`,`tpoint_kind_id`,`lot_at`),
  KEY `idx_player_tpoint_histories_2` (`tpoint_period_id`,`add_status`),
  KEY `idx_player_tpoint_histories_3` (`tpoint_kind_id`,`tpoint_period_id`,`use_item_id`,`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーTポイント履歴';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_tpoint_summaries`
--

DROP TABLE IF EXISTS `player_tpoint_summaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_tpoint_summaries` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーTポイントサマリーID',
  `tpoint_kind_id` int(11) NOT NULL COMMENT 'Tポイント種別ID',
  `tpoint_period_id` int(11) NOT NULL COMMENT 'Tポイント期間ID',
  `use_item_id` int(11) NOT NULL DEFAULT '-1' COMMENT '使用アイテムID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `num` int(11) NOT NULL COMMENT '合計Tポイント数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_tpoint_summaries_1` (`tpoint_kind_id`,`tpoint_period_id`,`use_item_id`,`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーTポイントサマリー';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_tutorial_ondemands`
--

DROP TABLE IF EXISTS `player_tutorial_ondemands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_tutorial_ondemands` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '都度チュートリアル管理データ',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `bits` bigint(20) NOT NULL COMMENT 'ビットデータ',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_tutorial_ondemands_1` (`spid`),
  KEY `idx_player_tutorial_ondemands_2` (`bits`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='都度チュートリアル管理データ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_tutorials`
--

DROP TABLE IF EXISTS `player_tutorials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_tutorials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL,
  `tutorial_id` int(11) NOT NULL DEFAULT '0',
  `update_num` int(11) NOT NULL DEFAULT '0' COMMENT '更新回数',
  `is_complete` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_tutorials_1` (`spid`,`tutorial_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_update_info_reads`
--

DROP TABLE IF EXISTS `player_update_info_reads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_update_info_reads` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーアップデート情報閲覧情報',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `read_at` datetime NOT NULL COMMENT '閲覧日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_player_update_info_reads_1` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーアップデート情報閲覧情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `player_useragents`
--

DROP TABLE IF EXISTS `player_useragents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_useragents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーUserAgentID',
  `player_id` varchar(9) NOT NULL COMMENT 'TOGID',
  `useragent` varchar(512) NOT NULL COMMENT 'UserAgent',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_player_useragents_1` (`player_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='プレイヤーUserAgent';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `players`
--

DROP TABLE IF EXISTS `players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `players` (
  `spid` bigint(20) NOT NULL,
  `player_id` varchar(9) NOT NULL,
  `gender_id` int(11) NOT NULL DEFAULT '0' COMMENT '性別',
  `code` varchar(12) NOT NULL,
  `name` varchar(36) NOT NULL,
  `description` text COMMENT '一言コメント',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`spid`),
  KEY `idx_players_1` (`player_id`),
  KEY `idx_players_2` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_migrations` (
  `version` varchar(255) NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_agent_paths`
--

DROP TABLE IF EXISTS `t_agent_paths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_agent_paths` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'UserAgent',
  `path` varchar(40) NOT NULL COMMENT 'パス',
  `category` varchar(40) NOT NULL COMMENT 'カテゴリ',
  `name` varchar(40) NOT NULL COMMENT 'ブラウザ名',
  `version` varchar(40) NOT NULL COMMENT 'ブラウザバージョン',
  `os` varchar(40) NOT NULL COMMENT 'OS',
  `vendor` varchar(40) NOT NULL COMMENT 'vendor',
  `os_version` varchar(40) NOT NULL COMMENT 'OSバージョン',
  `counter_value` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_t_agent_paths_1` (`path`,`category`,`name`,`version`,`os`,`vendor`,`os_version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='UserAgent';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_dealer_container_histories`
--

DROP TABLE IF EXISTS `t_dealer_container_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_dealer_container_histories` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '問屋什器仕入れ履歴',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `buy_at` datetime NOT NULL COMMENT '購入日時',
  `dealer_id` int(11) NOT NULL COMMENT '問屋ID',
  `container_id` bigint(20) NOT NULL COMMENT '什器ID',
  `dealer_container_id` bigint(20) NOT NULL COMMENT '問屋什器ID',
  `point_id` int(11) DEFAULT '1' COMMENT 'ポイントID',
  `price` int(11) NOT NULL COMMENT '価格',
  `num` int(11) NOT NULL COMMENT '個数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_t_dealer_container_histories_1` (`spid`,`buy_at`,`dealer_id`,`container_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='問屋什器仕入れ履歴';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_dealer_product_histories`
--

DROP TABLE IF EXISTS `t_dealer_product_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_dealer_product_histories` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '問屋商品仕入れ履歴',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `buy_at` datetime NOT NULL COMMENT '購入日時',
  `dealer_id` int(11) NOT NULL COMMENT '問屋ID',
  `product_id` bigint(20) NOT NULL COMMENT '商品ID',
  `dealer_product_id` bigint(20) NOT NULL COMMENT '問屋商品ID',
  `point_id` int(11) DEFAULT '1' COMMENT 'ポイントID',
  `price` int(11) NOT NULL COMMENT '価格',
  `num` int(11) NOT NULL COMMENT '個数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_t_dealer_product_histories_1` (`spid`,`buy_at`,`dealer_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='問屋商品仕入れ履歴';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_event_point_rewards`
--

DROP TABLE IF EXISTS `t_event_point_rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_event_point_rewards` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '全体達成報酬付与履歴',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `point_reward_id` int(11) NOT NULL COMMENT 'イベントポイント達成報酬ID',
  `num` int(11) NOT NULL COMMENT '付与回数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_t_event_point_rewards_1` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='全体達成報酬付与履歴';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_event_points`
--

DROP TABLE IF EXISTS `t_event_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_event_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'イベントポイント',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `event_point` bigint(20) NOT NULL COMMENT 'ポイント数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_t_event_points_1` (`event_id`,`point_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベントポイント';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_event_team_points`
--

DROP TABLE IF EXISTS `t_event_team_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_event_team_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'イベントチームポイント',
  `event_id` int(11) NOT NULL COMMENT 'イベントID',
  `event_team_id` int(11) NOT NULL COMMENT 'イベントチームID',
  `point_id` int(11) NOT NULL COMMENT 'ポイントID',
  `event_point` bigint(20) NOT NULL COMMENT 'ポイント数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_t_event_team_points_1` (`event_id`,`event_team_id`,`point_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='イベントチームポイント';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_guild_avatar_inventories`
--

DROP TABLE IF EXISTS `t_guild_avatar_inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_guild_avatar_inventories` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '組合アバターデータ',
  `guild_id` int(11) NOT NULL COMMENT '組合ID',
  `avatar_id` bigint(20) NOT NULL COMMENT 'アバターID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_t_guild_avatar_inventories_1` (`guild_id`,`avatar_id`),
  KEY `idx_t_guild_avatar_inventories_2` (`avatar_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合アバターデータ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_guild_budge_inventories`
--

DROP TABLE IF EXISTS `t_guild_budge_inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_guild_budge_inventories` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '組合バッジ在庫データ',
  `guild_id` int(11) NOT NULL COMMENT '組合ID',
  `budge_id` int(11) NOT NULL COMMENT 'バッジID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_t_guild_budge_inventories_1` (`guild_id`),
  KEY `idx_t_guild_budge_inventories_2` (`budge_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合バッジ在庫データ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_guild_budges`
--

DROP TABLE IF EXISTS `t_guild_budges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_guild_budges` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ギルドバッジ設定情報',
  `guild_id` int(11) NOT NULL COMMENT 'ギルドID',
  `budge_inventory_id` int(11) NOT NULL COMMENT 'バッジインベントリID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_t_guild_budges_2` (`budge_inventory_id`),
  KEY `idx_t_guild_budges_1` (`guild_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ギルドバッジ設定情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_guild_members`
--

DROP TABLE IF EXISTS `t_guild_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_guild_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '組合メンバー',
  `guild_id` int(11) NOT NULL COMMENT '組合ID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `position` smallint(6) NOT NULL COMMENT '役職ID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_t_guild_members_2` (`spid`),
  KEY `idx_t_guild_members_1` (`guild_id`,`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合メンバー';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_guild_quests`
--

DROP TABLE IF EXISTS `t_guild_quests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_guild_quests` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '組合クエストデータ',
  `guild_id` int(11) NOT NULL COMMENT '組合ID',
  `guild_quest_list_id` int(11) NOT NULL COMMENT '組合クエストリストID',
  `expire_at` datetime NOT NULL COMMENT 'クエストの有効期限',
  `status` smallint(6) NOT NULL COMMENT 'ステータス',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_t_guild_quests_1` (`guild_id`,`guild_quest_list_id`),
  KEY `idx_t_guild_quests_2` (`guild_quest_list_id`),
  KEY `idx_t_guild_quests_3` (`guild_id`,`expire_at`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合クエストデータ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_guild_searches`
--

DROP TABLE IF EXISTS `t_guild_searches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_guild_searches` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '組合検索テーブル',
  `guild_id` int(11) NOT NULL COMMENT '組合ID',
  `join_valid` tinyint(4) NOT NULL COMMENT '参加可能か',
  `join_type` smallint(6) NOT NULL COMMENT '参加タイプ',
  `store_point_100k` int(11) NOT NULL COMMENT 'ストアポイント条件 x10万',
  `members` smallint(6) NOT NULL COMMENT 'メンバー数',
  `score` bigint(20) NOT NULL COMMENT '組合スコア',
  `name` varchar(80) NOT NULL COMMENT '組合名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_t_guild_searches_1` (`guild_id`),
  KEY `idx_t_guild_searches_2` (`join_valid`,`join_type`,`store_point_100k`,`members`,`score`),
  KEY `idx_t_guild_searches_3` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合検索テーブル';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_guild_shops`
--

DROP TABLE IF EXISTS `t_guild_shops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_guild_shops` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '組合商店情報',
  `guild_id` int(11) NOT NULL COMMENT '組合ID',
  `spid` int(11) NOT NULL COMMENT '購入者SPID',
  `guild_shop_id` int(11) NOT NULL COMMENT '組合商店ID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_t_guild_shops_1` (`guild_id`,`guild_shop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合商店情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_guilds`
--

DROP TABLE IF EXISTS `t_guilds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_guilds` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '組合データ',
  `tag` varchar(8) NOT NULL COMMENT '組合タグ',
  `exp` int(11) NOT NULL DEFAULT '0' COMMENT '組合経験値',
  `lv` tinyint(4) NOT NULL DEFAULT '1' COMMENT '組合レベル',
  `max_lv` tinyint(4) NOT NULL COMMENT '組合レベル上限',
  `donate_num` int(11) NOT NULL DEFAULT '0' COMMENT '寄付総数',
  `member_limits` tinyint(4) NOT NULL COMMENT '組合メンバー上限',
  `name` varchar(80) NOT NULL COMMENT '組合名',
  `description` text COMMENT '組合説明',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_t_guilds_1` (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='組合データ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_log_last_positions`
--

DROP TABLE IF EXISTS `t_log_last_positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_log_last_positions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ログ最終位置ID',
  `table_name` varchar(80) NOT NULL COMMENT 'テーブル名',
  `counter_period_id` int(11) NOT NULL COMMENT 'カウンター期間種別ID',
  `start_at` datetime NOT NULL COMMENT '期間開始日時',
  `last_id` bigint(20) unsigned DEFAULT NULL COMMENT '最終ID',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_t_log_last_positions_1` (`table_name`,`counter_period_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ログ最終位置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_maintes`
--

DROP TABLE IF EXISTS `t_maintes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_maintes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kind` int(11) NOT NULL,
  `start_at` datetime NOT NULL,
  `end_at` datetime NOT NULL,
  `description` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_t_maintes_1` (`start_at`,`end_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_present_tasks`
--

DROP TABLE IF EXISTS `t_present_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_present_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレゼント付与管理',
  `filter_id` bigint(20) NOT NULL COMMENT '対象指定種別',
  `filter_value1` varchar(20) DEFAULT NULL COMMENT '対象指定値1',
  `filter_value2` varchar(20) DEFAULT NULL COMMENT '対象指定値2',
  `filter_value3` varchar(20) DEFAULT NULL COMMENT '対象指定値3',
  `present_pool_kind_id` varchar(40) NOT NULL COMMENT 'プレゼント種別',
  `subject` varchar(40) NOT NULL COMMENT 'プレゼント題目',
  `class_id` varchar(20) NOT NULL COMMENT '付与種別',
  `arg1` varchar(20) DEFAULT NULL COMMENT '値1',
  `arg2` varchar(20) DEFAULT NULL COMMENT '値2',
  `arg3` varchar(20) DEFAULT NULL COMMENT '値3',
  `arg4` varchar(20) DEFAULT NULL COMMENT '値4',
  `arg5` varchar(20) DEFAULT NULL COMMENT '値5',
  `task_start_date` datetime NOT NULL COMMENT '付与開始日時',
  `task_proc_start_date` datetime DEFAULT NULL COMMENT '処理開始日時',
  `task_proc_end_date` datetime DEFAULT NULL COMMENT '処理終了日時',
  `task_status` smallint(6) NOT NULL COMMENT '処理ステータス',
  `task_send_num` bigint(20) NOT NULL DEFAULT '0' COMMENT '処理成功数',
  `task_error_num` bigint(20) NOT NULL DEFAULT '0' COMMENT '処理失敗数',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレゼント付与管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_product_stats`
--

DROP TABLE IF EXISTS `t_product_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_product_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `target_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_quote_values`
--

DROP TABLE IF EXISTS `t_quote_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_quote_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '気配一時データ',
  `target_kind` int(11) NOT NULL COMMENT '対象種別',
  `target_id` bigint(20) NOT NULL COMMENT '対象ID',
  `start_at` datetime NOT NULL COMMENT '開始日時',
  `quote_value` int(11) NOT NULL COMMENT '気配値',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_t_quote_values_1` (`target_kind`,`target_id`,`start_at`),
  KEY `idx_t_quote_values_2` (`target_kind`,`start_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='気配一時データ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_raid_join_players`
--

DROP TABLE IF EXISTS `t_raid_join_players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_raid_join_players` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'レイドプレイコンテキスト',
  `player_raid_level_id` int(11) NOT NULL COMMENT 'レイドプレイID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `total_damaged` int(11) NOT NULL COMMENT '累積ダメージ',
  `total_points` int(11) NOT NULL COMMENT '累積ポイント',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_t_raid_join_players_1` (`player_raid_level_id`,`spid`),
  KEY `idx_t_raid_join_players_2` (`spid`),
  KEY `idx_t_raid_join_players_3` (`player_raid_level_id`,`total_damaged`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='レイドプレイコンテキスト';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_raid_play_contexts`
--

DROP TABLE IF EXISTS `t_raid_play_contexts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_raid_play_contexts` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'レイドプレイコンテキスト',
  `player_raid_level_id` int(11) NOT NULL COMMENT 'レイドプレイID',
  `lv` smallint(6) NOT NULL COMMENT 'レベル',
  `hp` mediumint(9) NOT NULL COMMENT 'HP',
  `is_valid` tinyint(4) NOT NULL COMMENT '有効無効',
  `lock_version` int(11) NOT NULL DEFAULT '0' COMMENT 'ロックバージョン',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_t_raid_play_contexts_1` (`player_raid_level_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='レイドプレイコンテキスト';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_rankings`
--

DROP TABLE IF EXISTS `t_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_rankings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ranking_kind` int(11) NOT NULL COMMENT 'ランキング種別',
  `ranking_date` date NOT NULL COMMENT '最終更新日付',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_search_logins`
--

DROP TABLE IF EXISTS `t_search_logins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_search_logins` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'プレイヤーログイン検索用テーブル',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `login_at` datetime NOT NULL COMMENT 'ログイン日時',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_t_search_logins_1` (`spid`),
  KEY `idx_t_search_logins_2` (`login_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='プレイヤーログイン検索用テーブル';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_search_players`
--

DROP TABLE IF EXISTS `t_search_players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_search_players` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `is_purchase_limit` smallint(6) NOT NULL DEFAULT '1' COMMENT '購入可能なプレイヤーか',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_t_search_players_1` (`spid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_search_stores`
--

DROP TABLE IF EXISTS `t_search_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_search_stores` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `store_id` int(11) NOT NULL COMMENT 'ストアID',
  `product_category_id` smallint(5) unsigned NOT NULL COMMENT '商品カテゴリID',
  `rarity_id` tinyint(3) unsigned NOT NULL COMMENT 'レアリティID',
  PRIMARY KEY (`id`),
  KEY `idx_t_search_stores_1` (`spid`,`store_id`),
  KEY `idx_t_search_stores_2` (`product_category_id`,`rarity_id`),
  KEY `idx_t_search_stores_3` (`rarity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_search_tutorials`
--

DROP TABLE IF EXISTS `t_search_tutorials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_search_tutorials` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'チュートリアル突破ユーザー検索用テーブル',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `complete_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_t_search_tutorials_1` (`spid`),
  KEY `idx_t_search_tutorials_2` (`complete_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='チュートリアル突破ユーザー検索用テーブル';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_shard_bases`
--

DROP TABLE IF EXISTS `t_shard_bases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_shard_bases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `db_node_id` smallint(6) NOT NULL,
  `shard_group` varchar(10) NOT NULL,
  `capacity` int(11) NOT NULL DEFAULT '0',
  `max_capacity` int(11) NOT NULL,
  `weight` int(11) NOT NULL DEFAULT '1',
  `description` varchar(80) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_t_shard_bases_1` (`shard_group`,`db_node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_shard_players`
--

DROP TABLE IF EXISTS `t_shard_players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_shard_players` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `db_node_id` smallint(6) NOT NULL,
  `player_id` varchar(64) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_t_shard_players_2` (`player_id`),
  KEY `idx_t_shard_players_1` (`db_node_id`,`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_system_counters`
--

DROP TABLE IF EXISTS `t_system_counters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_system_counters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `target_id` bigint(20) NOT NULL,
  `counter_kind_id` int(11) NOT NULL,
  `counter_period_id` int(11) NOT NULL,
  `start_at` datetime NOT NULL,
  `count_value` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx__system_counters_1` (`counter_kind_id`,`counter_period_id`,`start_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_tpoint_accesses`
--

DROP TABLE IF EXISTS `t_tpoint_accesses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_tpoint_accesses` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'TポイントAPIアクセス履歴ID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `request_unixtime` int(11) NOT NULL COMMENT 'APIリクエストUNIXTIME',
  `hsyukei_from` varchar(14) NOT NULL COMMENT '集計日時from',
  `hsyukei_to` varchar(14) NOT NULL COMMENT '集計日時to',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_t_tpoint_accesses_1` (`spid`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='TポイントAPIアクセス履歴';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_tpoint_alliance_gyotais`
--

DROP TABLE IF EXISTS `t_tpoint_alliance_gyotais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_tpoint_alliance_gyotais` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Tポイントアライアンス業態',
  `hkigyoCd` varchar(32) NOT NULL COMMENT '履歴アライアンス企業コード',
  `hgyotaiCd` varchar(32) NOT NULL COMMENT '履歴業態コード',
  `hgyotaiNm` varchar(128) NOT NULL COMMENT '履歴業態名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_t_tpoint_alliance_gyotais_1` (`hkigyoCd`,`hgyotaiCd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tポイントアライアンス業態';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_tpoint_alliance_kigyos`
--

DROP TABLE IF EXISTS `t_tpoint_alliance_kigyos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_tpoint_alliance_kigyos` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Tポイントアライアンス企業',
  `hkigyoCd` varchar(32) NOT NULL COMMENT '履歴アライアンス企業コード',
  `hkigyoNm` varchar(128) NOT NULL COMMENT '履歴アライアンス企業名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_t_tpoint_alliance_kigyos_1` (`hkigyoCd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tポイントアライアンス企業';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_tpoint_alliance_tenpos`
--

DROP TABLE IF EXISTS `t_tpoint_alliance_tenpos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_tpoint_alliance_tenpos` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Tポイントアライアンス店舗',
  `hkigyoCd` varchar(32) NOT NULL COMMENT '履歴アライアンス企業コード',
  `hgyotaiCd` varchar(32) NOT NULL COMMENT '履歴業態コード',
  `htenpoCd` varchar(32) NOT NULL COMMENT '履歴店舗コード',
  `htenpoNm` varchar(128) NOT NULL COMMENT '履歴店舗名',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_t_tpoint_alliance_tenpos_1` (`hkigyoCd`,`hgyotaiCd`,`htenpoCd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tポイントアライアンス店舗';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_tpoint_cap_counters`
--

DROP TABLE IF EXISTS `t_tpoint_cap_counters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_tpoint_cap_counters` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Tポイント上限カウンターID',
  `tpoint_cap_id` int(11) NOT NULL COMMENT 'Tポイント上限ID',
  `tpoint_period_id` int(11) NOT NULL COMMENT 'Tポイント期間ID',
  `count_value` int(11) NOT NULL COMMENT '付与回数',
  `lock_version` int(11) NOT NULL DEFAULT '0' COMMENT 'バージョン番号',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_t_tpoint_cap_counters_1` (`tpoint_cap_id`,`tpoint_period_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tポイント上限カウンター';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `t_tpoint_histories`
--

DROP TABLE IF EXISTS `t_tpoint_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_tpoint_histories` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Tポイント利用履歴ID',
  `spid` bigint(20) NOT NULL COMMENT 'SPID',
  `hhaneiDate` date DEFAULT NULL COMMENT 'ポイント反映年月日',
  `huseDate` date DEFAULT NULL COMMENT '履歴受付年月日',
  `hsyukeiTime` datetime DEFAULT NULL COMMENT '集計日時',
  `hkigyoCd` varchar(32) DEFAULT NULL COMMENT '履歴アライアンス企業コード',
  `hgyotaiCd` varchar(32) DEFAULT NULL COMMENT '履歴業態コード',
  `htenpoCd` varchar(32) DEFAULT NULL COMMENT '履歴店舗コード',
  `hcontent` varchar(32) DEFAULT NULL COMMENT '内容',
  `hpt` int(11) DEFAULT NULL COMMENT '利用ポイント数',
  `hpresentCnt` int(11) DEFAULT NULL COMMENT '提示回数',
  `request_unixtime` int(11) NOT NULL COMMENT 'APIリクエストUNIXTIME',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_t_tpoint_histories_1` (`spid`,`huseDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tポイント利用履歴';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-11 17:28:50
